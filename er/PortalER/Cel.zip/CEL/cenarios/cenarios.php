<?php
	$xsltproc = xslt_create();
	$html = xslt_process($xsltproc, 'cenarios.xml', 'cenarios.xsl');
	if (!($html)) die ("Erro ao processar o arquivo XML: " . xslt_error($xsltproc));
	xslt_free($xsltproc);
//	echo $html;
?>
