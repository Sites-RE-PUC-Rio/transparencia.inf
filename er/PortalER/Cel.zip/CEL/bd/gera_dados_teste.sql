-- Projetos

INSERT INTO projeto (nome) VALUES ('projeto 1');
INSERT INTO projeto (nome) VALUES ('projeto 2');
INSERT INTO projeto (nome) VALUES ('projeto 3');

-- Cenarios projeto 1

INSERT INTO cenario (id_projeto, titulo) VALUES (1, 'p1 titulo 1');
INSERT INTO cenario (id_projeto, titulo) VALUES (1, 'p1 titulo 2');
INSERT INTO cenario (id_projeto, titulo) VALUES (1, 'p1 titulo 3');

-- Lexico projeto 1

INSERT INTO lexico (id_projeto, nome) VALUES (1, 'p1 nome 1');
INSERT INTO lexico (id_projeto, nome) VALUES (1, 'p1 nome 2');
INSERT INTO lexico (id_projeto, nome) VALUES (1, 'p1 nome 3');

-- centocen projeto 1

-- INSERT INTO centocen VALUES (1, 2);
-- INSERT INTO centocen VALUES (1, 3);
-- INSERT INTO centocen VALUES (2, 1);
-- INSERT INTO centocen VALUES (3, 2);

-- centolex projeto 1

-- INSERT INTO centolex VALUES (1, 1);
-- INSERT INTO centolex VALUES (1, 2);
-- INSERT INTO centolex VALUES (1, 3);

-- lextolex projeto 1

-- INSERT INTO lextolex VALUES (1, 2);
-- INSERT INTO lextolex VALUES (2, 3);
-- INSERT INTO lextolex VALUES (3, 1);

-- Cenarios projeto 2

INSERT INTO cenario (id_projeto, titulo) VALUES (2, 'p2 titulo 1');
INSERT INTO cenario (id_projeto, titulo) VALUES (2, 'p2 titulo 2');
INSERT INTO cenario (id_projeto, titulo) VALUES (2, 'p2 titulo 3');
INSERT INTO cenario (id_projeto, titulo) VALUES (2, 'p2 titulo 4');

-- Lexico projeto 2

INSERT INTO lexico (id_projeto, nome) VALUES (2, 'p2 nome 1');
INSERT INTO lexico (id_projeto, nome) VALUES (2, 'p2 nome 2');
INSERT INTO lexico (id_projeto, nome) VALUES (2, 'p2 nome 3');
INSERT INTO lexico (id_projeto, nome) VALUES (2, 'p2 nome 4');

-- centocen projeto 2

-- INSERT INTO centocen VALUES (4, 5);
-- INSERT INTO centocen VALUES (4, 6);
-- INSERT INTO centocen VALUES (5, 4);
-- INSERT INTO centocen VALUES (6, 5);

-- centolex projeto 2

-- INSERT INTO centolex VALUES (4, 4);
-- INSERT INTO centolex VALUES (4, 5);
-- INSERT INTO centolex VALUES (4, 6);

-- lextolex projeto 2

-- INSERT INTO lextolex VALUES (4, 5);
-- INSERT INTO lextolex VALUES (4, 7);
-- INSERT INTO lextolex VALUES (6, 4);

-- usuarios

INSERT INTO usuario (login, senha) VALUES ('aflorio', 'minhasenha');

