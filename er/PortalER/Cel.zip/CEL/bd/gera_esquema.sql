-- #########################################################
-- # Script gerador do esquema relacional da base de dados #
-- # da aplicacao "Gerenciador de Lexicos e Cenarios".     #
-- #########################################################

DROP SEQUENCE cenario_id_cenario_seq;
DROP SEQUENCE lexico_id_lexico_seq;
DROP SEQUENCE projeto_id_projeto_seq;
DROP SEQUENCE usuario_id_usuario_seq;
DROP SEQUENCE pedidocen_id_pedido_seq;
DROP SEQUENCE pedidolex_id_pedido_seq;
DROP TABLE projeto;
DROP TABLE cenario;
DROP TABLE lexico;
DROP TABLE centocen;
DROP TABLE centolex;
DROP TABLE lextolex;
DROP TABLE usuario;
DROP TABLE participa;
DROP TABLE pedidocen;
DROP TABLE pedidolex;

CREATE TABLE projeto (
    id_projeto SERIAL,
    nome VARCHAR(128),
    data_criacao DATE,
    descricao TEXT,
    PRIMARY KEY (id_projeto),
	UNIQUE (nome)
);

CREATE TABLE cenario (
    id_cenario SERIAL,
    id_projeto INTEGER,
    data date,
    titulo TEXT,
    objetivo TEXT,
    contexto TEXT,
    atores TEXT,
    recursos TEXT,
    episodios TEXT,
    PRIMARY KEY (id_cenario,data),
    UNIQUE (id_projeto, titulo)
);

CREATE TABLE lexico (
    id_lexico SERIAL,
    id_projeto INTEGER,
    data date,
    nome VARCHAR(64),
    nocao TEXT,
    impacto TEXT,
    PRIMARY KEY (id_lexico,data),
    UNIQUE (id_projeto, nome)
);

CREATE TABLE centocen (
    id_cenario_from INTEGER,
    id_cenario_to INTEGER,
    PRIMARY KEY (id_cenario_from, id_cenario_to)
);

CREATE TABLE centolex (
    id_cenario INTEGER,
    id_lexico INTEGER,
    PRIMARY KEY (id_cenario, id_lexico)
);

CREATE TABLE lextolex (
    id_lexico_from INTEGER,
    id_lexico_to INTEGER,
    PRIMARY KEY (id_lexico_from, id_lexico_to)
);

CREATE TABLE usuario (
    id_usuario SERIAL,
    nome VARCHAR(255),
    email VARCHAR(64),
    login VARCHAR(32),
    senha VARCHAR(32),
    PRIMARY KEY (id_usuario),
    UNIQUE (login)
);

CREATE TABLE participa (
    id_usuario INTEGER,
    id_projeto INTEGER,
    gerente BOOLEAN,
    PRIMARY KEY (id_usuario, id_projeto)
);

CREATE TABLE pedidocen (
    id_pedido SERIAL,
    id_usuario INTEGER,
    id_projeto INTEGER,
    tipo_pedido VARCHAR(7),
    aprovado BOOLEAN,
    id_cenario INTEGER,
    titulo TEXT,
    objetivo TEXT,
    contexto TEXT,
    atores TEXT,
    recursos TEXT,
    episodios TEXT,
    justificativa TEXT,
    PRIMARY KEY (id_pedido)
);

CREATE TABLE pedidolex (
    id_pedido SERIAL,
    id_usuario INTEGER,
    id_projeto INTEGER,
    tipo_pedido VARCHAR(7),
    aprovado BOOLEAN,
    id_lexico INTEGER,
    nome VARCHAR(64),
    nocao TEXT,
    impacto TEXT,
    justificativa TEXT,
    PRIMARY KEY (id_pedido)
);
