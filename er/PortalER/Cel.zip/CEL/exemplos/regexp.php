<!-- tabstop = 2 -->

<html>
	<head>
		<title>Exemplo de uso de Regular Expressions</title>
	</head>
	<body>
		<h3>Exemplo de uso de Regular Expressions:</h3>
		<br/>
		<p><a href="regexp.phps">Codigo-fonte</a></p>
		<br/>
		<p>Regular expressions serao uteis para fazer o 'search and replace' nas descricoes do lexico e dos cenarios.</p>
		<br/>
		<br/>
		<p><b>Texto para ser modificado: (texto qualquer)</b></p>
		<br/>

<?php

	$text = "The MTA's job is to pass the mail to an MTA on Bob's machine.  It
  determines Bob's machine by analyzing the To header and seeing the
  dobbs.com on the right-hand side of Bob's address.  It uses that
  address to open an Internet connection to Bob's machine.  The
  mechanics of making that connection are a whole other topic; for this
  explanation, it's enough to know that that connection is a way for
  Alice's MTA to send text commands to Bob's machine and receive replies
  to those commands.

  The MTA's commands don't go to a shell.  Instead they go to a service
  port on Alice's machine.  A service port is a sort of rendezvous, a
  known place where Internet service programs listen for incoming
  requests.  Service ports are numbered, and Alice's MTA knows that it
  needs to talk to port 25 on Bob's machine to pass mail.

  On port 25, Bob's machine has its own MTA listening for commands
  (probably another copy of sendmail).  Alice's MTA will go through a
  dialogue with Bob's using Simple Mail Transfer Protocol (or SMTP).
  Here is what an SMTP dialogue looks like.  Lines sent by Alice's
  machine are shown with S:, responses from Bob's machine are shown with
  R:.";

	echo $text;

?>

		<br/>
		<br/>
		<p><u>O 'search and replace' vai procurar por palavras 'to' e substitui-las por links 'to' para o site da Disney...</u></p>
		<br/>
		<p><b>Texto resultante: (com os links)</b></p>

<?php

	$regexp = "/\ (to)\ /";
	$replace = " <a href=\"http://www.disney.com/\">$1</a> ";

	$text_m = preg_replace($regexp, $replace, $text);

	echo $text_m;

?>

		<br/>
		<br/>
		<p>Quem vai precisar mexer com isso, veja a pagina <a href="http://www.php.net/manual/en/function.preg-replace.php">http://www.php.net/manual/en/function.preg-replace.php</a> para mais informacoes.</p>
	</body>
</html>

