<!-- tabstop = 2 -->

<html>
	<head>
		<title>Exemplo de uso de PHP e PostgreSQL</title>
	</head>
	<body>
		<h3>Exemplo de uso de PHP e PostgreSQL:</h3>
		<br/>
		<p>Clique <a href="exemplo.phps">aqui</a> para ver o codigo-fonte.</p>
		<br/>
		<p>Primeiramente conectamos ao SGBD usando a funcao pg_connect().</p>
		<p>Conectamos na base de dados 'testdb', com o usuario 'postgres' e senha 'SuperBonder'...</p>

<?php

	$r = pg_connect("dbname=testdb user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");
	
?>

		<p>Agora mandamos uma query que cria uma tabela 'blah' com dois atributos do tipo VARCHAR (atr1 e atr2)...</p>

<?php

	$q = "create table blah (atr1 varchar(32), atr2 varchar(32))";

	pg_query($r, $q) or die("Erro ao enviar a query");
	// o parametro $r eh opcional, mas eh boa pratica colocar

?>

		<p>Agora inserimos 20 linhas de valores aleatorios na tabela que acabamos de criar...</p>

<?php

	for ($i=0; $i<20; $i++) {
		$rnd_str = md5(time());				// string mais ou menos aleatoria
		$rts_dnr = strrev($rnd_str);	// string aleatoria inversa
		$q = "insert into blah values ('$rnd_str', '$rts_dnr')";
		pg_query($r, $q) or die("Erro ao enviar a query de insercao");
	}

?>

		<p>Agora selecionamos todos os valores da tabela (os valores que inserimos) e colocamos ele em uma tabela...</p>

		<table border="1">
			<tr>
				<th>Atr1</th>
				<th>Atr2</th>
			</tr>

<?php

	$q = "select * from blah";
	$qrr = pg_query($r, $q) or die("Erro ao enviar a query de selecao");

	while($row=pg_fetch_row($qrr)) {			// enquanto houver linhas
?>

			<tr>
				<td><?=$row[0]?></td>
				<td><?=$row[1]?></td>
			</tr>

<?php
	}

?>
	
		</table>
		<p>Para terminar dropamos a tabela 'blah' da base de dados...</p>

<?php

	$q = "drop table blah";
	pg_query($q) or die("Erro ao dropar a tabela");

?>

	</body>
</html>
