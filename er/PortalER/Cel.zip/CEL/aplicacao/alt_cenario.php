<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

// alt_cenario.php: Este script faz um pedido de alteracao de um cenario do projeto.
// 								O usuario recebe um form com o cenario corrente (ou seja com seus campos preenchidos)
//								e podera fazer	alteracoes em todos os campos menos no titulo.Ao final a tela principal
//								retorna para a tela de inicio e a arvore e fechada.O form de alteracao tb e fechado.
// Arquivo chamador: main.php
session_start();

include("funcoes_genericas.php");

chkUser("index.php");// Checa se o usuario foi autenticado

// Conecta ao SGBD
$r = pg_connect("dbname=trabalho user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");

if (isset($submit)) {       // Script chamado atraves do submit do formulario
    inserirPedidoAlterarCenario($_SESSION['id_projeto_corrente'],
                                $id_cenario,
                                $titulo,
                                $objetivo,
                                $contexto,
                                $atores,
                                $recursos,
                                $episodios,
                                $justificativa,
                                $_SESSION['id_usuario_corrente']);
?>

<script language="javascript1.3">

opener.parent.frames['code'].location.reload();
opener.parent.frames['text'].location.replace('main.php?id_projeto=<?=$_SESSION['id_projeto_corrente']?>');

</script>

<h4>Opera��o efetuada com sucesso!</h4>

<script language="javascript1.3">

self.close();

</script>

<?php
} else { // Script chamado atraves do link no cenario corrente

    $nome_projeto = simple_query("nome", "projeto", "id_projeto = " . $_SESSION['id_projeto_corrente']);

    $q = "SELECT * FROM cenario WHERE id_cenario = $id_cenario";
    $qrr = pg_query($r, $q) or die("Erro ao executar a query");
    $result = pg_fetch_array($qrr);
?>

<html>
    <head>
        <title>Alterar Cen�rio</title>
    </head>
    <body>
        <h4>Alterar Cen�rio</h4>
        <br>
        <form action="<?=$PHP_SELF?>?id_projeto=<?=$id_projeto?>" method="post">
        <table>
				<tr>
                <td>Projeto:</td>
                <td><input disabled size="48" type="text" value="<?=$nome_projeto?>"></td>
            </tr>
								 <input type="hidden" name="id_cenario" value="<?=$result['id_cenario']?>">
                <td>T�tulo:</td>
								<? $result['titulo'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['titulo']); ?>
                <input type="hidden" name="titulo" value="<?=$result['titulo']?>">
								<td><input disabled maxlength="128" name="titulo2" size="48" type="text" value="<?=$result['titulo']?>"></td>
            <tr>
                <td>Objetivo:</td>
								<? $result['objetivo'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['objetivo']); ?>
  
                <td><input  maxlength="255" name="objetivo" size="48" type="text" value="<?=$result['objetivo']?>"></td>
            </tr>
            <tr>
                <td>Contexto:</td>
								<? $result['contexto'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['contexto']); ?>
                <td><input  maxlength="255" name="contexto" size="48" type="text" value="<?=$result['contexto']?>"></td>
            </tr>
            <tr>
                <td>Atores:</td>
								<? $result['atores'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['atores']); ?>
  
                <td><input  maxlength="255" name="atores" size="48" type="text" value="<?=$result['atores']?>"></td>
            </tr>
            <tr>
                <td>Recursos:</td>
								<? $result['recursos'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['recursos']); ?>
  
                <td><input  maxlength="255" name="recursos" size="48" type="text" value="<?=$result['recursos']?>"></td>
            </tr>
            <tr>
                <td>Epis�dios:</td>
								<? $result['episodios'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['episodios']); ?>
                <td><textarea  cols="48" name="episodios" rows="16"><?=$result['episodios']?></textarea></td>
            </tr>
            <tr>
                <td>Justificativa:</td>
                <td><textarea name="justificativa" cols="48" rows="6"></textarea></td>
            </tr>
            <tr>
                <td align="center" colspan="2" height="60"><input name="submit" type="submit" value="Alterar Cen�rio" onClick="updateOpener()"></td>
            </tr>
        </table>
        </form>
    </body>
</html>

<?php
}
?>
