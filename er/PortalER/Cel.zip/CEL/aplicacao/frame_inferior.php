<?php

	session_start();

	include("funcoes_genericas.php");

	chkUser("index.php");		// Cenario: controle de acesso

// frame_inferior.php
// Dada a base, o tipo "c" ou "l" e o
// id do respectivo, mostra os dados necess�rios
// no frame.

	function frame_inferior( $bd, $tipo, $id  )
	{
		$search = "'<[\/\!]*?[^<>]*?>'si";
		$replace = "";
		if ( $tipo == "c" )			// Se for cenario
		{
			// Seleciona os cen�rios que referenciam o cen�rio 
			// com o id passado.
			$qry_cenario = "SELECT id_cenario, titulo
			                FROM   cenario, centocen
			                WHERE  id_cenario = id_cenario_from
			                AND    id_cenario_to = " . $id ;
			
			$tb_cenario = pg_query( $bd , $qry_cenario ) or 
			              die( "Erro ao enviar a query de selecao." ) ;
?>

			<table>
			<tr>
			  <th>Cen�rios</th>
			</tr>

<?php
			while ( $row = pg_fetch_row( $tb_cenario ) )
			{
				// Retira as tags HTML de dentro do titulo do cenario
				$row[1] = preg_replace($search, $replace, $row[1]);
				$link = "<a href=javascript:reCarrega" .
				        "('main.php?id=$row[0]&t=c');><span style=\"font-variant: small-caps\">$row[1]</span></a>" ;
?>

				<td><?=$link?></td>

<?php
			} // while
		} // if
		else if ( $tipo = "l" )
		{
			// Seleciona os cen�rios que referenciam o l�xico
			// com o id passado.
			$qry_cenario = "SELECT c.id_cenario, c.titulo
			                FROM   cenario c, centolex cl
			                WHERE  c.id_cenario = cl.id_cenario
			                AND    cl.id_lexico = " . $id ;
			
			$tb_cenario = pg_query( $bd , $qry_cenario ) or 
			              die( "Erro ao enviar a query de selecao." ) ;

			// Seleciona os lexicos que referenciam o lexico
			// com o id passado.
			$qry_lexico = "SELECT id_lexico, nome
			               FROM   lexico, lextolex
			               WHERE  id_lexico  = id_lexico_from
			               AND    id_lexico_to = " . $id ;
			
			$tb_lexico = pg_query( $bd , $qry_lexico ) or 
			             die( "Erro ao enviar a query de selecao." ) ;
?>

			<table>
			<tr>
				<th>Cen�rios</th>
				<th>L�xicos</th>
			</tr>

<?php
			while ( 1 )
			{
?>

				<tr>

<?php
				if ( $rowc = pg_fetch_row( $tb_cenario ) )
				{
					$rowc[1] = preg_replace($search, $replace, $rowc[1]);
					$link = "<a href=javascript:reCarrega" . 
					        "('main.php?id=$rowc[0]&t=c');><span style=\"font-variant: small-caps\">$rowc[1]</span></a>" ;
				} // if
				else
				{
					$link = "" ;
				} // else
?>

				<td><?=$link?></td>

<?php
				if ( $rowl = pg_fetch_row( $tb_lexico ) )
				{
					$link = "<a href=javascript:reCarrega" .
					        "('main.php?id=$rowl[0]&t=l');>$rowl[1]</a>" ;
				} // if
				else
				{
					$link = "" ;
				} // else
?>

				<td><?=$link?></td>
				</tr>

<?php
				if ( !( $rowc ) && !( $rowl ) )
				{
					break ;
				} // if
			} // while
		}
?>

</table>

<?php
	} // procura_ref
?>
