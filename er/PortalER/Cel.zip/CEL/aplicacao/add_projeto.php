<?php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Cenario: controle de acesso

// Este script eh chamado quando ocorre uma solicitacao de inclusao
// de novo projeto, ou quando um novo usuario se cadastra no sistema

if (isset($submit)) {    // chamado atraves do botao de submit

    $id_projeto_incluido = inclui_projeto($nome, $descricao);
    // Inserir na tabela participa
    $r = pg_connect("dbname=trabalho user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");
    $q = "INSERT INTO participa (id_usuario, id_projeto, gerente)
          VALUES ($id_usuario_corrente, $id_projeto_incluido, TRUE)";
    pg_query($r, $q) or die("Erro ao inserir na tabela participa");
?>

<script language="javascript1.3">

self.close();

</script>

<?php
} else {        // Chamado normalmente
?>

<html>
    <head>
        <title>Adicionar Projeto</title>
        <script language="javascript1.3">

        function chkFrmVals() {
            if (document.forms[0].nome.value == "") {
                alert('Preencha o campo "Nome"');
                return false;
            }
            return true;
        }

        </script>
    </head>
    <body>
        <h4>Adicionar Projeto:</h4>
        <br>
        <form action="<?=$PHP_SELF?>" method="post" onSubmit="return chkFrmVals();">
        <table>
            <tr>
                <td>Nome:</td>
                <td><input maxlength="128" name="nome" size="48" type="text"></td>
            </tr>
            <tr>
                <td>Descri��o:</td>
                <td><textarea cols="48" name="descricao" rows="4"></textarea></td>
            <tr>
                <td align="center" colspan="2" height="60"><input name="submit" type="submit" value="Adicionar Projeto"></td>
            </tr>
        </table>
        </form>
    </body>
</html>

<?php
}
?>
