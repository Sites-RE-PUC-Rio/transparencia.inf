<?php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Checa se o usuario foi autenticado

?>

<?php

// gerador_xml.php

// Dada a base e o id do projeto, gera-se o xml

// dos cen�rios e l�xicos.



	function gerar_xml( $bd, $id_projeto, $data_pesquisa, $flag_formatado)

	{

		$xml_resultante = "<?xml version='1.0' encoding='utf-8' ?>\n" ;

		if ($flag_formatado == "ON")
		{

                     $xml_resultante = $xml_resultante . "<?xml-stylesheet type='text/xsl' href='projeto.xsl'?>\n" ;

		}

		$xml_resultante = $xml_resultante . "<root>\n" ;



                // Seleciona o nome do projeto

                $qry_nome = "SELECT nome

                             FROM projeto

                             WHERE id_projeto = " . $id_projeto ;



                $tb_nome = pg_query ( $bd, $qry_nome ) or

                           die ( "Erro ao enviar a query de selecao." ) ;





                $xml_resultante = $xml_resultante . "<Projeto>" . pg_result ( $tb_nome, 0 ) . "</Projeto>\n" ;





		// Seleciona os cen�rios de um projeto.

		$qry_cenario = "SELECT id_cenario ,

		                       titulo ,

		                       objetivo ,

		                       contexto ,

		                       atores ,

		                       recursos ,

		                       episodios

						FROM   cenario

						WHERE  (id_projeto = " . $id_projeto

						. ") AND (data <=" . " '" . $data_pesquisa . "'". ")

						ORDER BY id_cenario,data DESC";

		

		$tb_cenario = pg_query( $bd , $qry_cenario ) or 

		              die( "Erro ao enviar a query de selecao." ) ;



		$primeiro = true;

		$id_temp = "";

		while ( $row = pg_fetch_row( $tb_cenario ) )

		{

			$id_cenario = "<ID>" . $row[ 0 ] . "</ID>" ;

		

		    	if (($id_temp != $id_cenario) or (primeiro))

		    	{

			        $titulo = "<Titulo>" . strip_tags ( $row[ 1 ] ) . "</Titulo>" ;

        	                $objetivo = "<Objetivo>" . strip_tags ( $row[ 2 ] ) . "</Objetivo>" ;

                	        $contexto = "<Contexto>" . strip_tags ( $row[ 3 ] ) . "</Contexto>" ;

                        	$atores = "<Atores>" . strip_tags ( $row[ 4 ] ) . "</Atores>" ;

	                        $recursos = "<Recursos>" . strip_tags ( $row[ 5 ] ) . "</Recursos>" ;

        	                $episodios = "<Episodios>" . strip_tags ( $row[ 6 ] ) . "</Episodios>" ;

	

				$xml_resultante = $xml_resultante . "<Cenario>\n" ;

				$xml_resultante = $xml_resultante . "$id_cenario\n" ;

				$xml_resultante = $xml_resultante . "$titulo\n" ;

				$xml_resultante = $xml_resultante . "$objetivo\n" ;

				$xml_resultante = $xml_resultante . "$contexto\n" ;

                	        $xml_resultante = $xml_resultante . "$atores\n" ;

				$xml_resultante = $xml_resultante . "$recursos\n" ;

				$xml_resultante = $xml_resultante . "$episodios\n" ;

				$xml_resultante = $xml_resultante . "</Cenario>\n" ;

				$primeiro = false;

				$id_temp = id_cenario;

		   	}

			

		} // while





                // Seleciona os lexicos de um projeto.

                $qry_lexico = "SELECT id_lexico ,

                                       nome ,

                                       nocao ,

                                       impacto

                                                FROM   lexico

						WHERE  (id_projeto = " . $id_projeto . 
						
						") AND (data <=" . " '" . $data_pesquisa . "'". ")

						ORDER BY id_lexico,data DESC";

		

                $tb_lexico = pg_query( $bd , $qry_lexico ) or 

		              die( "Erro ao enviar a query de selecao." ) ;



		$primeiro = true;

		$id_temp = "";

                while ( $row = pg_fetch_row( $tb_lexico ) )

		{

                        $id_lexico = "<ID>" . $row[ 0 ] . "</ID>" ;

			if (($id_temp != $id_lexico) or (primeiro))

		    	{

	                        $nome = "<Nome>" . strip_tags ( $row[ 1 ] ) . "</Nome>" ;

	                        $nocao = "<Nocao>" . strip_tags ( $row[ 2 ] ) . "</Nocao>" ;

	                        $impacto = "<Impacto>" . strip_tags ( $row[ 3 ] ) . "</Impacto>" ;



	                        $xml_resultante = $xml_resultante . "<Lexico>\n" ;

	                        $xml_resultante = $xml_resultante . "$id_lexico\n" ;

	                        $xml_resultante = $xml_resultante . "$nome\n" ;

	                        $xml_resultante = $xml_resultante . "$nocao\n" ;

	                        $xml_resultante = $xml_resultante . "$impacto\n" ;

	                        $xml_resultante = $xml_resultante . "</Lexico>\n" ;

				$primeiro = false;

				$id_temp = id_lexico;

			}			

		} // while
	




                $xml_resultante = $xml_resultante . "</root>\n" ;



		return $xml_resultante ;



	} // gerar_xml

?>

<?php

	$id_projeto = $_SESSION['id_projeto_corrente'];
	$data_pesquisa = $data_ano . "-" . $data_mes . "-" . $data_dia;
	$flag_formatado = $flag;

	// Abre base de dados.
  	$bd_trabalho = pg_connect( "dbname=trabalho user=postgres password=SuperBonder" ) 
	               or die( "Erro ao conectar ao SGBD" ) ;

        $str_xml = gerar_xml( $bd_trabalho , $id_projeto,  $data_pesquisa, $flag_formatado ) ;
	
	if ($flag_formatado == "ON"){

		$xh = xslt_create() ;
	
		$args	= array ( '/_xml' => $str_xml ) ;
	
	        $html = @xslt_process( $xh , 'arg:/_xml' , 'projeto.xsl' , NULL , $args ) ;
		if ( !( $html ) ) die ( "Erro ao processar o arquivo XML: " . xslt_error( $xh ) ) ;
		xslt_free( $xh ) ;
		echo $html ;
	}
	else
	{
	$str_xml = str_replace ( "<", "<font color=\"red\">&lt;", $str_xml ) ;
	$str_xml = str_replace ( ">", "&gt;</font>", $str_xml ) ;
	$str_xml = str_replace ( "\n", "<br>", $str_xml ) ;
?>
	<html><head><title>Projeto</title></head><body bgcolor="#FFFFFF"><?= $str_xml ?></body></html>
<?php
	}
?>