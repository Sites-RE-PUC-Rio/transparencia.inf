<?php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Cenario: controle de acesso

?>

<script language="javascript1.3">

function getIDPrj() {
    var select = document.forms[0].id_projeto; // combo-box de projeto
    var indice = select.selectedIndex; // indice selecionado
    var id_projeto = select.options[indice].value; // id_projeto correspondente ao indice
    return id_projeto;
}

function atualizaMenu() {   // carrega o menu correspondente ao projeto
    // Para nao fazer nada se selecionarem o "-- Selecione um Projeto --"
    if (!(document.forms[0].id_projeto.options[0].selected)) {
        top.frames['code'].location.replace('code.php?id_projeto=' + getIDPrj());
        top.frames['text'].location.replace('main.php?id_projeto=' + getIDPrj());
        location.replace('heading.php?id_projeto=' + getIDPrj());
    } else {
        location.reload();
    }
    return false;
}

<?php
if (isset($id_projeto)) {   // $id_projeto soh nao estara setada caso seja a primeira
                            // vez que o usuario esteja acessando o sistema

    // Checagem de seguranca, pois $id_projeto eh passado atraves de JavaScript (cliente)
    check_proj_perm($_SESSION['id_usuario_corrente'], $id_projeto) or die("Permissao negada");
?>

function setPrjSelected() {
    var select = document.forms[0].id_projeto;
    for (var i = 0; i < select.length; i++) {
        if (select.options[i].value == <?=$id_projeto?>) {
            select.options[i].selected = true;
            i = select.length;
        }
    }
}

<?php
}
?>

function novoCenario() {
    var url = 'add_cenario.php?id_projeto=' + '<?=$id_projeto?>';
    var where = '_blank';
    var window_spec = 'dependent,height=300,width=550,resizable,scrollbars,titlebar';
    open(url, where, window_spec);
}

function novoLexico() {
    var url = 'add_lexico.php?id_projeto=' + '<?=$id_projeto?>';
    var where = '_blank';
    var window_spec = 'dependent,height=300,width=550,resizable,scrollbars,titlebar';
    open(url, where, window_spec);
}

function prjInfo(idprojeto) {
    top.frames['text'].location.replace('main.php?id_projeto=' + idprojeto);
}

</script>

<html>
    <style>
    a
    {
        font-weight: bolder;
        color: aqua;
        font-family: Verdana, Arial;
        text-decoration: none
    }
    a:hover
    {
        font-weight: bolder;
        color: orange;
        font-family: Verdana, Arial;
        text-decoration: none
    }
    </style>
    <body bgcolor="#ffffff" text="#ffffff" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" <?=(isset($id_projeto)) ? "onLoad=\"setPrjSelected();\"" : ""?>>
        <form onSubmit="return atualizaMenu();">
            <table width="100%" cellspacing="0" cellpadding="0">
                <tr bgcolor="#00359F">
                    <td width="294" height="79"><img src="Images/Logo.jpg"></td>
                    <td align="right" valign="top">
                        <table>
                            <tr>
                                <td align="right" valign="top">Projeto:&nbsp;&nbsp;
                                    <select name="id_projeto" size="1" onChange="atualizaMenu();">
                                        <option>-- Selecione um Projeto --</option>

<?php

// ** Cenario "Login" **
// O sistema d� ao usu�rio a op��o de cadastrar um novo projeto
// ou utilizar um projeto em que ele fa�a parte.

// conecta ao SGBD
$r = pg_connect("dbname=trabalho user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");

// define a consulta
$q = "SELECT p.id_projeto, p.nome, pa.gerente
      FROM usuario u, participa pa, projeto p
      WHERE u.id_usuario = pa.id_usuario
      AND pa.id_projeto = p.id_projeto
      AND pa.id_usuario = " . $_SESSION["id_usuario_corrente"] . "
      ORDER BY p.nome";

// executa a consulta
$qrr = pg_query($r, $q) or die("Erro ao executar query");
            
while ($result = pg_fetch_array($qrr)) {    // enquanto houver projetos
?>

<option value="<?=$result['id_projeto']?>"><?=($result['gerente'] == "t") ? "*" : ""?>  <?=$result['nome']?></option>
            
<?php
}
?>
            
                                    </select>&nbsp;&nbsp;
                                    <input type="submit" value="Atualizar">
                                </td>
                            </tr>
                            <tr bgcolor="#00359F" height="15">
                                <td>*: voce � administrador</td>
                            </tr>
                            <tr bgcolor="#00359F" height="30">
                                <td align="right" valign=MIDDLE>

<?php
if (isset($id_projeto)) {    // Se o usuario ja tiver escolhido um projeto,
                             // entao podemos mostrar os links de adicionar cen/lex
                             // e de informacoes (pagina principal) do projeto
?>

                                    <a href="#" onClick="novoCenario();">Adicionar Cen�rio</a>&nbsp;&nbsp;
                                    <a href="#" onClick="novoLexico();">Adicionar L�xico</a>&nbsp;&nbsp;
                                    <a href="#" title="Informa��es sobre o Projeto" onClick="prjInfo(<?=$id_projeto?>);">Info</a>&nbsp;&nbsp;

<?php
}
?>

                                    <a href="#" onClick="window.open('add_projeto.php', '_blank', 'dependent,height=300,width=550,resizable,scrollbars,titlebar');">Adicionar Projeto</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr height="33" bgcolor="#00359F" background="Images/FrameTop.gif">
                    <td background="Images/TopLeft.gif" width="294" valign="baseline"></td>
                    <td background="Images/FrameTop.gif" valign="baseline"></td>
                </tr>
            </table>
        </form>
    </body>
</html>
