<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

// alt_lexico.php: Este script faz um pedido de alteracao de um lexico do projeto.
//                 O usuario recebe um form com o lexico corrente (ou seja, com seus campos preenchidos)
//                 e podera fazer alteracoes em todos os campos menos no nome. Ao final a tela principal
//                 retorna para a tela de inicio e a arvore e fechada. O form de alteracao tb e fechado.
// Arquivo chamador: main.php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Checa se o usuario foi autenticado

// Conecta ao SGBD
$r = pg_connect("dbname=trabalho user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");

if (isset($submit)) {       // Script chamado atraves do submit do formulario

    inserirPedidoAlterarLexico($id_projeto, $id_lexico, $nome, $nocao, $impacto, $justificativa, $id_usuario_corrente);
?>

<script language="javascript1.3">

opener.parent.frames['code'].location.reload();
opener.parent.frames['text'].location.replace('main.php?id_projeto=<?=$_SESSION['id_projeto_corrente']?>');

</script>

<h4>Opera��o efetuada com sucesso!</h4>

<script language="javascript1.3">

self.close();

</script>

<?php

} else {        // Script chamado atraves do link do lexico corrente
    $nome_projeto = simple_query("nome", "projeto", "id_projeto = " . $_SESSION['id_projeto_corrente']);
    $q = "SELECT * FROM lexico WHERE id_lexico = $id_lexico";
    $qrr = pg_query($r, $q) or die("Erro ao executar a query");
    $result = pg_fetch_array($qrr);
?>

<html>
    <head>
        <title>Alterar L�xico</title>
    </head>
    <body>
        <h4>Alterar L�xico</h4>
        <br>
        <form action="<?=$PHP_SELF?>?id_projeto=<?=$id_projeto?>" method="post">
        <table>
                <input type="hidden" name="id_lexico" value="<?=$result['id_lexico']?>">
              
            <tr>
                <td>Projeto:</td>
                <td><input disabled size="48" type="text" value="<?=$nome_projeto?>"></td>
            </tr>
                <td>Nome:</td>
                                <? $result['nome'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['nome']); ?>
                <input type="hidden" name="nome" value="<?=$result['nome']?>">
                                <td><input disabled maxlength="64" name="nome" size="48" type="text" value="<?=$result['nome'];?>"></td>
            <tr>
                <td>No��o:</td>
                                <? $result['nocao'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['nocao']); ?>
                <td><input maxlength="255" name="nocao" size="48" type="text" value="<?=$result['nocao'];?>"></td>
            </tr>
            <tr>
                <td>Impacto:</td>
                                <? $result['impacto'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['impacto']); ?>
                <td><input maxlength="255" name="impacto" size="48" type="text" value="<?=$result['impacto'];?>"></td>
            </tr>
            <tr>
                <td>Justificativa:</td>
                <td><textarea name="justificativa" cols="48" rows="6"></textarea></td>
            </tr>
            <tr>
                <td align="center" colspan="2" height="60"><input name="submit" type="submit" value="Alterar L�xico"></td>
            </tr>
        </table>
        </form>
    </body>
</html>

<?php
}
?>
