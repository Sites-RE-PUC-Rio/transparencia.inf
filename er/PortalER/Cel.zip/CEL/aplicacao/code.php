<?php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Checa se o usuario foi autenticado

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<?php

// conecta ao SGBD
$r = pg_connect("dbname=trabalho user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");

// A variavel $id_projeto, se estiver setada, corresponde ao id do projeto que
// devera ser mostrado. Se ela nao estiver setada entao, por default,
// nao mostraremos projeto algum (esperaremos o usuario escolher um projeto).
// Como a passagem eh feita usando JavaScript (no heading.php), devemos checar
// se este id realmente corresponde a um projeto que o usuario tenha acesso
// (seguranca).

if (isset($id_projeto)) {
    check_proj_perm($_SESSION['id_usuario_corrente'], $id_projeto) or die("Permissao negada");
    $q = "SELECT nome FROM projeto WHERE id_projeto = $id_projeto";
    $qrr = pg_query($r, $q) or die("Erro ao enviar a query");
    $result = pg_fetch_array($qrr);
    $nome_projeto = $result['nome'];
} else {

?>

<script language="javascript1.3">

top.frames['menu'].document.writeln('<font color="red">Nenhum projeto selecionado</font>');

</script>

<?php

    exit();
}

?>

<html>
<head>

<script type="text/javascript">
// Framebuster script to relocate browser when MSIE bookmarks this
// page instead of the parent frameset.  Set variable relocateURL to
// the index document of your website (relative URLs are ok):
var relocateURL = "/";

if (parent.frames.length == 0) {
    if(document.images) {
        location.replace(relocateURL);
    } else {
        location = relocateURL;
    }
}
</script>

<script type="text/javascript" src="mtmcode.js">
</script>

<script type="text/javascript">
// Morten's JavaScript Tree Menu
// version 2.3.2, dated 2002-02-24
// http://www.treemenu.com/

// Copyright (c) 2001-2002, Morten Wang & contributors
// All rights reserved.

// This software is released under the BSD License which should accompany
// it in the file "COPYING".  If you do not have this file you can access
// the license through the WWW at http://www.treemenu.com/license.txt

// Nearly all user-configurable options are set to their default values.
// Have a look at the section "Setting options" in the installation guide
// for description of each option and their possible values.

MTMDefaultTarget = "text";
MTMenuText = "<?=$nome_projeto?>";

/******************************************************************************
* User-configurable list of icons.                                            *
******************************************************************************/

var MTMIconList = null;
MTMIconList = new IconList();
MTMIconList.addIcon(new MTMIcon("menu_link_external.gif", "http://", "pre"));
MTMIconList.addIcon(new MTMIcon("menu_link_pdf.gif", ".pdf", "post"));

/******************************************************************************
* User-configurable menu.                                                     *
******************************************************************************/

var menu = null;
menu = new MTMenu();
menu.addItem("Cen�rios");
// + submenu
var mc = null;
mc = new MTMenu();

<?php
    $q = "SELECT id_cenario, titulo
          FROM cenario
          WHERE id_projeto = $id_projeto
          ORDER BY titulo";

    $qrr = pg_query($r, $q) or die("Erro ao enviar a query de selecao");
	// Devemos retirar todas as tags HTML do titulo do cenario. Possivelmente
	// havera tags de links (<a> </a>). Caso nao tiremos, havera erro ao
	// mostra-lo no menu. Este search & replace retira qualquer coisa que
	// seja da forma <qualquer_coisa_aqui>. Pode, inclusive, retirar trechos
	// que nao sao tags HTML.
	$search = "'<[\/\!]*?[^<>]*?>'si";
	$replace = "";
    while ($row = pg_fetch_row($qrr)) {    // para cada cenario do projeto
		$row[1] = preg_replace($search, $replace, $row[1]);
?>

mc.addItem("<?=$row[1]?>", "main.php?id=<?=$row[0]?>&t=c");
// + submenu
var mcs_<?=$row[0]?> = null;
mcs_<?=$row[0]?> = new MTMenu();
mcs_<?=$row[0]?>.addItem("Sub-cen�rios", "", null, "Cen�rios que este cen�rio referencia");
// + submenu
var mcsrc_<?=$row[0]?> = null;
mcsrc_<?=$row[0]?> = new MTMenu();

<?php
    $q = "SELECT c.id_cenario_to, cen.titulo FROM centocen c, cenario cen WHERE c.id_cenario_from = " . $row[0];
    $q = $q . "AND c.id_cenario_to = cen.id_cenario";
    $qrr_2 = pg_query($r, $q) or die("Erro ao enviar a query de selecao");
    while ($row_2=pg_fetch_row($qrr_2)) {
		$row_2[1] = preg_replace($search, $replace, $row_2[1]);
?>

mcsrc_<?=$row[0]?>.addItem("<?=$row_2[1]?>", "main.php?id=<?=$row_2[0]?>&t=c&cc=<?=$row[0]?>");

<?php
    }
?>

// - submenu
mcs_<?=$row[0]?>.makeLastSubmenu(mcsrc_<?=$row[0]?>);
mcs_<?=$row[0]?>.addItem("Sub-l�xico", "", null, "Termos do l�xico que este cen�rio referencia");
// + submenu
var mcsrl_<?=$row[0]?> = null;
mcsrl_<?=$row[0]?> = new MTMenu();

<?php
    $q = "SELECT c.id_lexico, l.nome FROM centolex c, lexico l ";
    $q = $q . "WHERE c.id_lexico = l.id_lexico AND c.id_cenario = " . $row[0];
    $qrr_2 = pg_query($r, $q) or die("Erro ao enviar a query de selecao");
    while ($row_2=pg_fetch_row($qrr_2)) {
?>

mcsrl_<?=$row[0]?>.addItem("<?=$row_2[1]?>", "main.php?id=<?=$row_2[0]?>&t=l&cl=<?=$row[0]?>");

<?php
    }
?>

// - submenu
mcs_<?=$row[0]?>.makeLastSubmenu(mcsrl_<?=$row[0]?>);
// - submenu
mc.makeLastSubmenu(mcs_<?=$row[0]?>);

<?php
    }
?>

// - submenu
menu.makeLastSubmenu(mc);
menu.addItem("L�xico");
// + submenu
var ml = null;
ml = new MTMenu();

<?php
    $q = "SELECT id_lexico, nome
          FROM lexico
          WHERE id_projeto = $id_projeto
          ORDER BY nome";

    $qrr = pg_query($r, $q) or die("Erro ao enviar a query de selecao");
    while ($row=pg_fetch_row($qrr)) {   // para cada lexico do projeto
?>

ml.addItem("<?=$row[1]?>", "main.php?id=<?=$row[0]?>&t=l");
// + submenu
var mls_<?=$row[0]?> = null;
mls_<?=$row[0]?> = new MTMenu();
// mls_<?=$row[0]?>.addItem("L�xico", "", null, "Termos do l�xico que este termo referencia");
// + submenu
// var mlsrl_<?=$row[0]?> = null;
// mlsrl_<?=$row[0]?> = new MTMenu();

<?php
    $q = "SELECT l.id_lexico_to, lex.nome FROM lextolex l, lexico lex WHERE l.id_lexico_from = " . $row[0];
    $q = $q . "AND l.id_lexico_to = lex.id_lexico";
    $qrr_2 = pg_query($r, $q) or die("Erro ao enviar a query de selecao");
    while ($row_2=pg_fetch_row($qrr_2)) {
?>

// mlsrl_<?=$row[0]?>.addItem("<?=$row_2[1]?>", "main.php?id=<?=$row_2[0]?>&t=l&ll=<?=$row[0]?>");
mls_<?=$row[0]?>.addItem("<?=$row_2[1]?>", "main.php?id=<?=$row_2[0]?>&t=l&ll=<?=$row[0]?>");

<?php
    }
?>

// - submenu
// mls_<?=$row[0]?>.makeLastSubmenu(mlsrl_<?=$row[0]?>);
// - submenu
ml.makeLastSubmenu(mls_<?=$row[0]?>);

<?php
    }
?>

// -submenu
menu.makeLastSubmenu(ml);

</script>
</head>
<body onload="MTMStartMenu(true)" bgcolor="#000033" text="#ffffcc" link="yellow" vlink="lime" alink="red">
</body>
</html>
