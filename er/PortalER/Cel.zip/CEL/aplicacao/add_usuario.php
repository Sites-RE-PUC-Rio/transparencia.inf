<?php
    session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<?php

include("funcoes_genericas.php");

$primeira_vez = "true";

if (isset($submit)) {   // Se chamado pelo botao de submit

     $primeira_vez = "false";
    // ** Cenario "Inclusao de Usuario Independente" **
    // O sistema checa se todos os campos estao preenchidos. Se algum nao estiver, o
    // sistema avisa pro usuario que todos os campos devem ser preenchidos.
    if ($nome == "" || $email == "" || $login == "" || $senha == "" || $senha_conf == "") {
        $p_style = "color: red; font-weight: bold";
        $p_text = "Por favor, preencha todos os campos.";
        recarrega("$PHP_SELF?p_style=$p_style&p_text=$p_text&nome=$nome&email=$email&login=$login&senha=$senha&senha_conf=$senha_conf&novo=$novo");
    } else {

        // Testa se as senhas fornecidas pelo usuario sao iguais.
        if ($senha != $senha_conf) {
            $p_style = "color: red; font-weight: bold";
            $p_text = "Senhas diferentes. Favor preencher novamente as senhas.";
            recarrega("$PHP_SELF?p_style=$p_style&p_text=$p_text&nome=$nome&email=$email&login=$login&novo=$novo");
        } else {

            // ** Cenario "Inclusao de Usuario Independente" **
            // Todos os campos estao preenchidos. O sistema deve agora verificar
            // se ja nao existe alguem cadastrado com o mesmo login informado pelo usuario.
            $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
            $q = "SELECT id_usuario FROM usuario WHERE login = '$login'";
            $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
            if (mysql_num_rows($qrr)) {        // Se ja existe algum usuario com este login
                $p_style = "color: red; font-weight: bold";
                $p_text = "Login j� existente no sistema. Favor escolher outro login.";
                recarrega("$PHP_SELF?p_style=$p_style&p_text=$p_text&nome=$nome&email=$email&senha=$senha&senha_conf=$senha_conf&novo=$novo");
            } else {    // Cadastro passou por todos os testes -- ja pode ser incluido na BD
                $q = "INSERT INTO usuario (nome, login, email, senha) VALUES ('$nome', '$login', '$email', '$senha')";
                mysql_query($r, $q) or die("Erro ao enviar a query");
                recarrega("$PHP_SELF?cadastrado=&novo=$novo&login=$login");
            }
        }   // else
    }   // else
} elseif (isset($cadastrado)) {

    // Cadastro concluido. Dependendo de onde o usuario veio,
    // devemos manda-lo para um lugar diferente.

    if ($novo == "true") {      // Veio da tela inicial de login

        // ** Cenario "Inclusao de Usuario Independente" **
        // O usuario acabou de cadastrar-se no sistema, devemos
        // redireciona-lo para a parte de inclusao de projetos

        // Registra que o usuario esta logado com o login recem-cadastrado
        $id_usuario_corrente = simple_query("id_usuario", "usuario", "login = '$login'");
        session_register("id_usuario_corrente");
?>

<script language="javascript1.3">

// Redireciona o usuario para a parte de inclusao de projetos
opener.location.replace('index.php');
open('add_projeto.php', '', 'dependent,height=300,width=550,resizable,scrollbars,titlebar');
self.close();

</script>

<?php
    } else {

    // ** Cenario "Edicao de Usuario" **
    // O administrador do projeto acabou de incluir o usuario.
    // Devemos agora adicionar o usuario incluido no projeto
    // do administrador.

    // Conexao com a base de dados
    $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
    // $login eh o login do usuario incluido, passado na URL
    $id_usuario_incluido = simple_query("id_usuario", "usuario", "login = '$login'");
    $q = "INSERT INTO participa (id_usuario, id_projeto)
          VALUES ($id_usuario_incluido, " . $_SESSION['id_projeto_corrente'] . ")";
    mysql_query($r, $q) or die("Erro ao inserir na tabela participa");

    $nome_usuario = simple_query("nome", "usuario", "id_usuario = $id_usuario_incluido");
    $nome_projeto = simple_query("nome", "projeto", "id_projeto = " . $_SESSION['id_projeto_corrente']);
?>

<script language="javascript1.3">

document.writeln('<p align="center">Usu�rio <b><?=$nome_usuario?></b> cadastrado e inclu�do no projeto <b><?=$nome_projeto?></b></p>');
document.writeln('<p align="center"><a href="javascript:self.close();">Fechar</a></p>');

</script>

<?php
    }
} else {    // Script chamado normalmente
    if (empty($p_style)) {
        $p_style = "color: green; font-weight: bold";
        $p_text = "Favor preencher os dados abaixo:";
    }

    if ($primeira_vez)
    {
         $email ="";
	     $login ="";
	     $nome  ="";
	     $senha = "";
         $senha_conf = "";

    }
?>

<html>
    <head>
        <title>Cadastro de Usu�rio</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head>
    <body>
        <p style="<?=$p_style?>"><?=$p_text?></p>
        <form action="<?=$PHP_SELF?>?novo=<?=$novo?>" method="post">
        <table>
            <tr>
                <td>Nome:</td><td colspan="3"><input name="nome" maxlength="255" size="48" type="text" value="<?=$nome?>"></td>
            </tr>
            <tr>
                <td>E-mail:</td><td colspan="3"><input name="email" maxlength="64" size="48" type="text" value="<?=$email?>"></td>
            </tr>
            <tr>
                <td>Login:</td><td><input name="login" maxlength="32" size="24" type="text" value="<?=$login?>"></td>
            </tr>
            <tr>
                <td>Senha:</td><td><input name="senha" maxlength="32" size="16" type="password" value="<?=$senha?>"></td>
                <td>Senha (confirma��o):</td><td><input name="senha_conf" maxlength="32" size="16" type="password" value="<?=$senha_conf?>"></td>
            </tr>
            <tr>
                <td align="center" colspan="4" height="40" valign="bottom"><input name="submit" type="submit" value="Cadastrar"></td>
            </tr>
        </table>
        </form>
    </body>
</html>

<?php
}
?>
