<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */
// ver_pedido_lexico.php: Esse script exibe os varios pedidos referentes
// 												ao lexico.O gerente tem a opcao de ver os pedidos 
//												jah validados. O gerente tb podera validar e processar pedidos.
//												O gerente tera uma terceira opcao que eh a de remover o pedido
//												validado ou nao da lista de pedidos.O gerente podera responder
//												a um pedido via e-mail direto desta pagina.
// Arquivo chamador: heading.php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");// Checa se o usuario foi autenticado
if (isset($submit)) {
		$DB = new PGDB () ;
		$select = new QUERY ($DB) ;
		$update = new QUERY ($DB) ;
		$delete = new QUERY ($DB) ;
		for($count = 0; $count < sizeof($pedidos); $count++)
		{
 		 		$update->execute("update pedidolex set aprovado='true' where id_pedido = $pedidos[$count]") ;
   			tratarPedidoLexico($pedidos[$count]) ;
		}
  	for($count = 0; $count < sizeof($remover); $count++)
 		{
 		 		$delete->execute("delete from pedidolex where id_pedido = $remover[$count]") ;
 		}
?>
<script language="javascript1.2">
opener.parent.frames['code'].location.reload();
opener.parent.frames['text'].location.replace("main.php") ;
</script>
<h4>Opera��o efetuada com sucesso!</h4>
<script language="javascript1.2">
self.close();
</script>
<?php
} else {
?>
<html>
  <head>
     <title>Pedido L�xico</title>
  </head>
<body>
<form action="<?=$PHP_SELF?>?id_projeto=<?=$id_projeto?>" method="post">
<?php   
				$DB = new PGDB () ;
				$select = new QUERY ($DB) ;
				$select2 = new QUERY ($DB) ;
				$select->execute("SELECT * FROM PEDIDOLEX where id_projeto = $id_projeto") ;
				if ($select->getntuples() == 0){
			 		 echo "<BR>Nenhum pedido.<BR>" ;
			 }else{
			 		$i = 0 ;
					$record = $select->gofirst () ;
					while($record != 'LAST_RECORD_REACHED'){
						$id_usuario = $record['id_usuario'] ;
						$id_pedido = $record['id_pedido'] ;
						$tipo_pedido = $record['tipo_pedido'] ;
						$aprovado = $record['aprovado'] ;
						$select2->execute("SELECT * FROM USUARIO WHERE id_usuario = $id_usuario") ;
						$usuario = $select2->gofirst () ;
						if(strcasecmp($tipo_pedido,'remover')){?>
						<h3>O usu�rio <a  href="mailto:<?=$usuario['email']?>" ><?=$usuario['nome']?></a> pede para <?=$tipo_pedido?> o l�xico <font color="#ff0000"><?=$record['nome']?></font> <?  if(!strcasecmp($tipo_pedido,'alterar')){echo"para l�xico abaixo:</h3>" ;}else{echo"</h3>" ;}?>
				<table>
                <td><b>Nome:</b></td>
                <td><?=$record['nome']?></td>
            <tr>
                <td><b>No��o:</b></td>
                <td><?=$record['nocao']?></td>
            </tr>
            <tr>
                <td><b>Impacto:</b></td>
                <td><?=$record['impacto']?></td>
            </tr>
            <tr>
                <td><b>Justificativa:</b></td>
                <td><textarea name="justificativa" cols="48" rows="6"><?=$record['justificativa']?></textarea></td>
            </tr>
        </table>
					<?php	
					}else{?>
							<h3>O usu�rio <a  href="mailto:<?=$usuario['email']?>" ><?=$usuario['nome']?></a> pede para <?=$tipo_pedido?> o l�xico <font color="#ff0000"><?=$record['nome']?></font></h3>
		<?php }
					if($aprovado == 't'){
								echo "<font color=\"#ff0000\">Aprovado</font> ";
					}else{
								echo "Aprovar<input type=\"checkbox\" name=\"pedidos[]\" value=\"$id_pedido\">" ;
					}
					echo "Remover<input type=\"checkbox\" name=\"remover[]\" value=\"$id_pedido\"><br><hr color=\"#000000\"><br>" ;
					$record = $select->gonext () ;
				}
		}?>
			 	 <input name="submit" type="submit" value="Processar">
</form>
</body>
</html>
		
<?php		
}
?>


