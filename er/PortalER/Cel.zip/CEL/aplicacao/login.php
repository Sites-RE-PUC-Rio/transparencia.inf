<?php

session_start();

// ** Cenario "Login" **
// Permitir ao usuario entrar no sistema e escolher um
// projeto em que ele esteja trabalhando
$wrong = "false";

// Conecta ao SGBD
$r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");

if (isset($submit)) {        /* se chamado pelo formul�rio */
// ** Cenario "Login" **
// Usu�rio deseja entrar no sistema com seu perfil
// O usu�rio fornece para o sistema um login e uma senha

    $q = "SELECT id_usuario FROM usuario WHERE login='$login' AND senha='$senha'";
    $qrr = mysql_query($r, $q) or die("Erro ao executar a query");
    if ( !mysql_num_rows($qrr) ) {        /* se login/senha errados */

// ** Cenario "Login" **
// O sistema autentica a senha do usuario

?>

<script language="javascript1.3">

document.location.replace('login.php?wrong=true&url=<?=$url?>');


</script>

<?php
$wrong = $_get["wrong"];
    } else {

        $row = mysql_fetch_row($qrr);
        $id_usuario_corrente = $row[0];

        session_register("id_usuario_corrente");
?>

<script language="javascript1.3">

opener.document.location.replace('<?=$url?>');
self.close();

</script>

<?php
    }
} else {    // Usuario entrando no sistema - deve mostrar a tela de login
?>

<html>
    <head>
        <title>Entre com seu Login e Senha</title>
    </head>
    <body>
        <h3 style="text-align: center">Gerenciador de L�xicos e Cen�rios</h3>

<?php
if ($wrong=="true") {
?>

<p style="color: red; font-weight: bold; text-align: center">Login ou Senha Incorreto</p>

<?php
} else {
?>

<p style="color: green; font-weight: bold; text-align: center">Entre com seu Login e Senha</p>

<?php
}
?>

        <form action="<?=$PHP_SELF?>?url=<?=$url?>" method="post">
        <div align="center">
            <table cellpadding="5">
                <tr><td>Login:</td><td><input maxlength="12" name="login" size="24" type="text"></td></tr>
                <tr><td>Senha:</td><td><input maxlength="24" name="senha" size="24" type="password"></td></tr>
                <tr><td height="10"></td></tr>
                <tr><td align="center" colspan="2"><input name="submit" type="submit" value="Entrar"></td></tr>
            </table>

<!-- Cenario "Inclusao de Usuario Independente". O usuario entrou no sistema. -->

            <p><a href="add_usuario.php?novo=true">Cadastrar-se</a></p>
        </div>
        </form>
    </body>
</html>

<?php
}
?>
