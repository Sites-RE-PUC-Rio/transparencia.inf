<?php
// rmv_lexico.php: Este script faz um pedido de remover um lexico do projeto.
//                 Remove o lexico corrente.
// Arquivo chamador: main.php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Checa se o usuario foi autenticado

inserirPedidoRemoverLexico($id_projeto, $id_lexico, $id_usuario_corrente);

?>  

<script language="javascript1.3">

opener.parent.frames['code'].location.reload();
opener.parent.frames['text'].location.replace('main.php?id_projeto=<?=$_SESSION['id_projeto_corrente']?>');

</script>

<h4>Opera��o efetuada com sucesso!</h4>

<script language="javascript1.3">

self.close();

</script>
