<?php

if (!(class_exists("PGDB"))) {
    include("bd_class.php");
}

/* chkUser(): checa se o usu�rio acessando foi autenticado (presen�a da vari�vel de sess�o
              $id_usuario_corrente). Caso ele j� tenha sido autenticado, continua-se com a execu��o do
              script. Caso contr�rio, abre-se uma janela de logon. */
if (!(function_exists("chkUser"))) {
    function chkUser($url)
    {
        if (!(session_is_registered("id_usuario_corrente"))) {
?>

<script language="javascript1.3">

open('login.php?url=<?=$url?>', 'login', 'dependent,height=270,width=490,resizable,scrollbars,titlebar');

</script>

<?php
            exit();
        }
    }
}

if (!(function_exists("inclui_cenario"))) {
    function inclui_cenario($id_projeto, $titulo, $objetivo, $contexto, $atores, $recursos, $episodios)
    {
        //global $r;      // Conexao com a base de dados
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");

        $q = "INSERT INTO cenario (id_projeto,data, titulo, objetivo, contexto, atores, recursos, episodios)
              VALUES ($id_projeto,'now', '" . strtolower($titulo) . "', '$objetivo', '$contexto', '$atores', '$recursos', '$episodios')";
        mysql_query($r, $q) or die("Erro ao enviar a query");
        $q = "SELECT max(id_cenario) FROM cenario";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        $result = mysql_fetch_row($qrr);
        return $result[0];
    }
}

if (!(function_exists("inclui_lexico"))) {
    function inclui_lexico($id_projeto, $nome, $nocao, $impacto)
    {
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
        $q = "INSERT INTO lexico (id_projeto, data, nome, nocao, impacto)
              VALUES ($id_projeto,'now', '" . strtolower($nome) . "', '$nocao', '$impacto')";
        mysql_query($r, $q) or die("Erro ao enviar a query");
        $q = "SELECT max(id_lexico) FROM lexico";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        $result = mysql_fetch_row($qrr);
        return $result[0];
    }
}

if (!(function_exists("inclui_projeto"))) {
    function inclui_projeto($nome, $descricao)
    {
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
        $q = "INSERT INTO projeto (nome, data_criacao, descricao)
              VALUES ('$nome', 'NOW', '$descricao')";
        mysql_query($r, $q) or die("Erro ao enviar a query");
        $q = "SELECT MAX(id_projeto) FROM projeto";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        $result = mysql_fetch_row($qrr);
        return $result[0];
    }
}

if (!(function_exists("replace_skip_tags"))) {
    function replace_skip_tags($search, $subject, $t_lnk, $id_lnk) {
        $title = ($t_lnk == "c") ? "Cen�rio" : "L�xico";
        $subject_tmp = preg_replace("/>(.*)(" . $search . ")(.*)</Ui", ">$1$2abcdef$3<", $subject);
        if ($t_lnk == "l") {
            $subject_tmp2 = preg_replace("/([^[:alpha:]]|^)(" . $search . ")([^[:alpha:]]|$)/i", '$1<a title="' . $title . '" href="main.php?t=' . $t_lnk . '&id=' . $id_lnk . '">$2</a>$3', $subject_tmp);
        } else {
            $subject_tmp2 = preg_replace("/([^[:alpha:]]|^)(" . $search . ")([^[:alpha:]]|$)/i", '$1<a title="' . $title . '" href="main.php?t=' . $t_lnk . '&id=' . $id_lnk . '"><span style="font-variant: small-caps">$2</span></a>$3', $subject_tmp);
        }
        return preg_replace("/>(.*)(" . $search . ")abcdef(.*)</Ui", ">$1$2$3<", $subject_tmp2);
    }
}

if (!(function_exists("recarrega"))) {
    function recarrega($url) {
?>

<script language="javascript1.3">

location.replace('<?=$url?>');

</script>

<?php
    }
}

if (!(function_exists("breakpoint"))) {
    function breakpoint($num) {
?>

<script language="javascript1.3">

alert('<?=$num?>');

</script>

<?php
    }
}

if (!(function_exists("simple_query"))) {
    function simple_query($field, $table, $where) {
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
        $q = "SELECT $field FROM $table WHERE $where";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        $result = mysql_fetch_row($qrr);
        return $result[0];
    }
}

// Para a correta inclusao de um cenario, uma serie de procedimentos
// precisam ser tomados (relativos ao requisito 'navegacao circular'):
//
// 1. Incluir o novo cenario na base de dados;
// 2. Para todos os cenarios daquele projeto:
//      2.1. Procurar em contexto, episodios
//           por ocorrencias do titulo do cenario incluido;
//      2.2. Para os campos em que forem encontradas ocorrencias:
//          2.2.1. Transformar a ocorrencia (titulo do cenario) em link;
//      2.3. Se algum campo sofreu alteracao:
//          2.3.1. Incluir entrada na tabela 'centocen';
//      2.4. Procurar em contexto, episodios do cenario incluido
//           por ocorrencias de titulos de outros cenarios do mesmo projeto;
//      2.5. Se achar alguma ocorrencia:
//          2.5.1. Transformar ocorrencia em link;
//          2.5.2. Incluir entrada na tabela 'centocen';
// 3. Para todos os nomes de termos do lexico daquele projeto:
//      3.1. Procurar ocorrencias desses nomes no titulo, objetivo, contexto,
//           recursos, atores, episodios do cenario incluido;
//      3.2. Para os campos em que forem encontradas ocorrencias:
//          3.2.1. Transformar as ocorrencias (nomes de termos) em link;
//      3.3. Se algum campo sofreu alteracao:
//          3.3.1. Incluir entrada na tabela 'centolex';

if (!(function_exists("adicionar_cenario"))) {
    function adicionar_cenario($id_projeto, $titulo, $objetivo, $contexto, $atores, $recursos, $episodios)
    {
        // Conecta ao SGBD
        mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
        // Inclui o cenario na base de dados (sem transformar os campos
        // em links e sem criar os relacionamentos)
        $id_incluido = inclui_cenario($id_projeto, $titulo, $objetivo, $contexto, $atores, $recursos, $episodios);

        $q = "SELECT id_cenario, titulo, contexto, episodios
              FROM cenario
              WHERE id_projeto = $id_projeto
              AND id_cenario != $id_incluido
              ORDER BY CHAR_LENGTH(titulo) DESC";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        while ($result = mysql_fetch_array($qrr)) {    // (2) Para todos os cenarios

            $result_m = replace_skip_tags($titulo, $result, "c", $id_incluido);

            if ($result['contexto'] != $result_m['contexto'] ||
                $result['episodios'] != $result_m['episodios']) {   // (2.3)

                $q = "UPDATE cenario SET
                      contexto = '" . $result_m['contexto'] . "',
                      episodios = '" . $result_m['episodios'] . "'
                      WHERE id_cenario = " . $result['id_cenario'];
                mysql_query($r, $q) or die("Erro ao enviar a query");  // (2.2.1 tbm)
                $q = "INSERT INTO centocen (id_cenario_from, id_cenario_to)
                      VALUES (" . $result['id_cenario'] . ", $id_incluido)";
                mysql_query($r, $q) or die("Erro ao enviar a query");  // (2.3.1)
            }

            // Para podermos executar (2.4), devemos retirar os links (possivelmente presentes)
            // dos titulos dos outros cenarios do mesmo projeto. Esta regexp remove tags HTML.
            $result['titulo'] = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $result['titulo']);

            $contexto_m = replace_skip_tags($result['titulo'], $contexto, "c", $result['id_cenario']);
            $episodios_m = replace_skip_tags($result['titulo'], $episodios, "c", $result['id_cenario']);

            if ($contexto != $contexto_m ||
                $episodios != $episodios_m) {   // (2.5)
                $q = "UPDATE cenario SET
                      contexto = '$contexto_m',
                      episodios = '$episodios_m'
                      WHERE id_cenario = $id_incluido";
                mysql_query($r, $q) or die("Erro ao enviar a query");  // (2.5.1)
                $q = "INSERT INTO centocen (id_cenario_from, id_cenario_to) VALUES ($id_incluido, " . $result['id_cenario'] . ")";
                mysql_query($r, $q) or die("Erro ao enviar a query");  // (2.5.2)
                // Atualiza definicao de $objetivo, $contexto, $atores, $recursos, $episodios
                $contexto = $contexto_m;
                $episodios = $episodios_m;
            }   // if
        }   // while

        $q = "SELECT id_lexico, nome FROM lexico WHERE id_projeto = $id_projeto";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        while ($result = mysql_fetch_array($qrr)) {    // (3)
            $titulo_m = replace_skip_tags($result['nome'], $titulo, "l", $result['id_lexico']);
            $objetivo_m = replace_skip_tags($result['nome'], $objetivo, "l", $result['id_lexico']);
            $contexto_m = replace_skip_tags($result['nome'], $contexto, "l", $result['id_lexico']);
            $atores_m = replace_skip_tags($result['nome'], $atores, "l", $result['id_lexico']);
            $recursos_m = replace_skip_tags($result['nome'], $recursos, "l", $result['id_lexico']);
            $episodios_m = replace_skip_tags($result['nome'], $episodios, "l", $result['id_lexico']);
            if ($titulo != $titulo_m ||
                $objetivo != $objetivo_m ||
                $contexto != $contexto_m ||
                $atores != $atores_m ||
                $recursos != $recursos_m ||
                $episodios != $episodios_m) {   // (3.3)
                $q = "UPDATE cenario SET
                      titulo = '$titulo_m',
                      objetivo = '$objetivo_m',
                      contexto = '$contexto_m',
                      atores = '$atores_m',
                      recursos = '$recursos_m',
                      episodios = '$episodios_m'
                      WHERE id_cenario = $id_incluido";
                mysql_query($r, $q) or die("Erro ao enviar a query");  // (3.2.1)
                $q = "INSERT INTO centolex (id_cenario, id_lexico) VALUES ($id_incluido, " . $result['id_lexico'] . ")";
                mysql_query($r, $q) or die("Erro ao enviar a query");  // (3.3.1)
                // Atualiza definicao de $titulo, $objetivo, $contexto, $atores, $recursos, $episodios
                $titulo = $titulo_m;
                $objetivo = $objetivo_m;
                $contexto = $contexto_m;
                $atores = $atores_m;
                $recursos = $recursos_m;
                $episodios = $episodios_m;
            }   // if
        }   // while
    }
}

 // Para a correta inclusao de um termo no lexico, uma serie de procedimentos
 // precisam ser tomados (relativos ao requisito 'navegacao circular'):
 //
 // 1. Incluir o novo termo na base de dados;
 // 2. Para todos os cenarios daquele projeto:
 //      2.1. Procurar em titulo, objetivo, contexto, recursos, atores, episodios
 //           por ocorrencias do termo incluido;
 //      2.2. Para os campos em que forem encontradas ocorrencias:
 //              2.2.1. Transformar a ocorrencia (nome do lexico) em link;
 //      2.3. Se algum campo sofreu alteracao:
 //              2.3.1. Incluir entrada na tabela 'centolex';
 // 3. Para todos termos do lexico daquele projeto (menos o recem-inserido):
 //      3.1. Procurar em nocao, impacto por ocorrencias do termo inserido;
 //      3.2. Para os campos em que forem encontradas ocorrencias:
 //              3.2.1. Transformar a ocorrencia (nome do lexico) em link;
 //      3.3. Se algum campo sofreu alteracao:
 //              3.3.1. Incluir entrada na tabela 'lextolex';
 //      3.4. Procurar em nocao, impacto do termo inserido por
 //           ocorrencias de termos do lexico do mesmo projeto;
 //      3.5. Se achar alguma ocorrencia:
 //          3.5.1. Transformar ocorrencia em link;
 //          3.5.2. Incluir entrada na table 'lextolex';

 if (!(function_exists("adicionar_lexico"))) {
    function adicionar_lexico($id_projeto, $nome, $nocao, $impacto){

        // Conecta ao SGBD
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");

    $id_incluido = inclui_lexico($id_projeto, $nome, $nocao, $impacto); // (1)
    // $nome, $nocao e $impacto campos do formulario

    $q = "SELECT id_cenario, titulo, objetivo, contexto, atores, recursos, episodios
          FROM cenario
          WHERE id_projeto = $id_projeto";
    $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");

    while ($result = mysql_fetch_array($qrr)) {    // (2) Para todos os cenarios
        $result_m = replace_skip_tags($nome, $result, "l", $id_incluido);

        if ($result['titulo'] != $result_m['titulo'] ||
            $result['objetivo'] != $result_m['objetivo'] ||
            $result['contexto'] != $result_m['contexto'] ||
            $result['atores'] != $result_m['atores'] ||
            $result['recursos'] != $result_m['recursos'] ||
            $result['episodios'] != $result_m['episodios']) {   // (2.3)

            $q = "UPDATE cenario SET
                  titulo = '" . $result_m['titulo'] . "',
                  objetivo = '" . $result_m['objetivo'] . "',
                  contexto = '" . $result_m['contexto'] . "',
                  atores = '" . $result_m['atores'] . "',
                  recursos = '" . $result_m['recursos'] . "',
                  episodios = '" . $result_m['episodios'] . "'
                  WHERE id_cenario = " . $result['id_cenario'];
            mysql_query($r, $q) or die("Erro ao enviar a query");  // (2.2.1 tbm)
            $q = "INSERT INTO centolex (id_cenario, id_lexico)
                  VALUES (" . $result['id_cenario'] . ", $id_incluido)";
            mysql_query($r, $q) or die("Erro ao enviar a query");  // (2.3.1)
        }
    }

    $q = "SELECT id_lexico, nome, nocao, impacto
          FROM lexico
          WHERE id_projeto = $id_projeto
          AND id_lexico != $id_incluido";
    $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");

    while ($result = mysql_fetch_array($qrr)) {    // (3)
        $result_m = replace_skip_tags($nome, $result, "l", $id_incluido);

        if ($result['nocao'] != $result_m['nocao'] ||
            $result['impacto'] != $result_m['impacto']) {   // (3.3)
            $q = "UPDATE lexico SET
                  nocao = '" . $result_m['nocao'] . "',
                  impacto = '" . $result_m['impacto'] . "'
                  WHERE id_lexico = " . $result['id_lexico'];
            mysql_query($r, $q) or die("Erro ao enviar a query");  // (3.2.1 tbm)
            $q = "INSERT INTO lextolex (id_lexico_from, id_lexico_to)
                  VALUES (" . $result['id_lexico'] . ", $id_incluido)";
            mysql_query($r, $q) or die("Erro ao enviar a query");  // (3.3.1)
        }
        $nocao_m = replace_skip_tags($result['nome'], $nocao, "l", $result['id_lexico']);
        $impacto_m = replace_skip_tags($result['nome'], $impacto, "l", $result['id_lexico']);
        if ($nocao_m != $nocao || $impacto_m != $impacto) {     // (3.5)
            $q = "UPDATE lexico SET nocao = '$nocao_m', impacto = '$impacto_m' WHERE id_lexico = $id_incluido";
            mysql_query($r, $q) or die("Erro ao executar query");      // (3.5.1)
            $q = "INSERT INTO lextolex (id_lexico_from, id_lexico_to) VALUES ($id_incluido, " . $result['id_lexico'] . ")";
            mysql_query($r, $q) or die("Erro ao executar query");      // (3.5.2)
            // Atualiza a definicao de $nocao e $impacto
            $nocao = $nocao_m;
            $impacto = $impacto_m;
        }   // if
    }   // while
    }
}


 ###################################################################
 # Essa funcao recebe um id de cenario e remove todos os seus
 # links e relacionamentos existentes.
 ###################################################################
 if (!(function_exists("removeCenario"))) {
         function removeCenario($id_projeto,$id_cenario){
                 $DB = new PGDB () ;
                $sql = new QUERY ($DB) ;
                $sql2 = new QUERY ($DB) ;
                $sql3 = new QUERY ($DB) ;
                $sql4 = new QUERY ($DB) ;
                $sql5 = new QUERY ($DB) ;
                $sql6 = new QUERY ($DB) ;
                $sql7 = new QUERY ($DB) ;
                # Este select procura o cenario a ser removido
                # dentro do projeto
                $sql2->execute ("SELECT * FROM cenario WHERE id_projeto = $id_projeto and id_cenario = $id_cenario") ;
                if ($sql2->getntuples() == 0){
                     echo "<BR> Cenario nao existe para esse projeto." ;
                }else{
                    $record = $sql2->gofirst ();
                    $tituloCenario = $record['titulo'] ;
                    # tituloCenario = Nome do cenario com id = $id_cenario
                }
                # [ATENCAO] Essa query pode ser melhorada com um join
                $sql->execute ("SELECT * FROM cenario WHERE id_projeto = $id_projeto");
                if ($sql->getntuples() == 0){
                     echo "<BR> Projeto n�o possui cenarios." ;
                }else{
                # Percorre todos os cenarios tirando as tag do cenario
                # a ser removido
                $record = $sql->gofirst ();
                while($record !='LAST_RECORD_REACHED'){
                    $idCenarioRef = $record['id_cenario'] ;
                    $tituloAnterior = $record['titulo'] ;
                    $objetivoAnterior = $record['objetivo'] ;
                    $contextoAnterior = $record['contexto'] ;
                    $atoresAnterior = $record['atores'] ;
                    $recursosAnterior = $record['recursos'] ;
                    $episodiosAnterior = $record['episodios'] ;
                    #echo        "/<a title=\"Cen�rio\" href=\"main.php?t='c'&id=$id_cenario>($tituloCenario)<\/a>/mi"  ;
                    #$episodiosAnterior = "<a title=\"Cen�rio\" href=\"main.php?t=c&id=38\">robin</a>" ;
                    /*"'<a title=\"Cen�rio\" href=\"main.php?t=c&id=38\">robin<\/a>'si" ; */
                    $tiratag = "'<[\/\!]*?[^<>]*?>'si" ;
                    $tiratagreplace = "";
                    $tituloCenario = preg_replace($tiratag,$tiratagreplace,$tituloCenario);
                    $regexp = "/<a[^>]*?>($tituloCenario)<\/a>/mi" ;
                    $replace = "$1";
                    $tituloAtual = $tituloAnterior ;
                    /*$tituloAtual = preg_replace($regexp,$replace,$tituloAnterior);*/
                    $objetivoAtual = preg_replace($regexp,$replace,$objetivoAnterior);
                    $contextoAtual = preg_replace($regexp,$replace,$contextoAnterior);
                    $atoresAtual = preg_replace($regexp,$replace,$atoresAnterior);
                    $recursosAtual = preg_replace($regexp,$replace,$recursosAnterior);
                    $episodiosAtual = preg_replace($regexp,$replace,$episodiosAnterior);
                    /*echo "ant:".$episodiosAtual ;
                    echo "<br>" ;
                    echo "dep:".$episodiosAnterior ;*/
                    $sql7->execute ("update cenario set objetivo = '$objetivoAtual',contexto = '$contextoAtual',atores = '$atoresAtual',recursos = '$recursosAtual',episodios = '$episodiosAtual' where id_cenario = $idCenarioRef ");
                    $record = $sql->gonext() ;
                }
                # Remove o relacionamento entre o cenario a ser removido
                # e outros cenarios que o referenciam
                $sql3->execute ("DELETE FROM centocen WHERE id_cenario_from = $id_cenario") ;
                $sql4->execute ("DELETE FROM centocen WHERE id_cenario_to = $id_cenario") ;
                # Remove o relacionamento entre o cenario a ser removido
                # e o seu lexico
                $sql5->execute ("DELETE FROM centolex WHERE id_cenario = $id_cenario") ;
                # Remove o cenario escolhido
                $sql6->execute ("DELETE FROM cenario WHERE id_cenario = $id_cenario") ;
            }
         }
 }

 ###################################################################
 # Essa funcao recebe um id de lexico e remove todos os seus
 # links e relacionamentos existentes.
 ###################################################################
 if (!(function_exists("removeLexico"))) {
         function removeLexico($id_projeto,$id_lexico){
                $DB = new PGDB () ;
                $sql = new QUERY ($DB) ;
                $update = new QUERY ($DB) ;
                $delete = new QUERY ($DB) ;
                # Este select procura o lexico a ser removido
                # dentro do projeto
                $sql->execute ("SELECT * FROM lexico WHERE id_projeto = $id_projeto and id_lexico = $id_lexico ") ;
                if ($sql->getntuples() == 0){
                     echo "<BR> Lexico nao existe para esse projeto." ;
                }else{
                    $record = $sql->gofirst ();
                    $nomeLexico = $record['nome'] ;
                    # nomeLexico = Nome do lexico com id = $id_lexico
                }
                # [ATENCAO] Essa query pode ser melhorada com um join
                $sql->execute ("SELECT * FROM lexico WHERE id_projeto = $id_projeto ");
                if ($sql->getntuples() == 0){
                     echo "<BR> Projeto n�o possui lexicos." ;
                }else{
                        # Percorre todos os lexicos tirando as tag do cenario
                        # a ser removido
                        $record = $sql->gofirst ();
                        while($record !='LAST_RECORD_REACHED'){
                                $idLexicoRef = $record['id_lexico'] ;
                                $nocaoAnterior = $record['nocao'] ;
                                $impactoAnterior = $record['impacto'] ;
                                $regexp = "/<a[^>]*?>($nomeLexico)<\/a>/mi" ;
                                $replace = "$1";
                                $nocaoAtual = preg_replace($regexp,$replace,$nocaoAnterior);
                                $impactoAtual = preg_replace($regexp,$replace,$impactoAnterior);
                                $update->execute ("update lexico set nocao = '$nocaoAtual',impacto = '$impactoAtual' where id_lexico = $idLexicoRef ");
                                $record = $sql->gonext() ;
                        }
                }
                # Procura pelo possivel cenario que ele define
                # remove sua tag e relacionamento
                $sql->execute ("SELECT * FROM cenario WHERE titulo = '<a title=\"L�xico\" href=\"main.php?t=l&id=$id_lexico\">$nomeLexico</a>'");
                if ($sql->getntuples() != 0){
                     $record = $sql->gofirst ();
                     $idCenarioRef = $record['id_cenario'] ;
                     $tituloAnterior = $record['titulo'] ;
                     $objetivoAnterior = $record['objetivo'] ;
                     $atoresAnterior = $record['atores'] ;
                     $recursosAnterior = $record['recursos'] ;
                     $tiratag = "'<[\/\!]*?[^<>]*?>'si" ;
                     $tiratagreplace = "";
                     $tituloAtual = preg_replace($tiratag,$tiratagreplace,$tituloAnterior);
                     $objetivoAtual = preg_replace($tiratag,$tiratagreplace,$objetivoAnterior);
                     $atoresAtual = preg_replace($tiratag,$tiratagreplace,$atoresAnterior);
                     $recursosAtual = preg_replace($tiratag,$tiratagreplace,$recursosAnterior);
                     $update->execute ("update cenario set titulo = '$tituloAtual',objetivo = '$objetivoAtual',atores = '$atoresAtual',recursos = '$recursosAtual' where id_cenario = $idCenarioRef ") ;
                     $delete->execute ("DELETE FROM centolex WHERE id_cenario = $idCenarioRef") ;
                }
                # Remove o relacionamento entre o lexico a ser removido
                # e outros lexicos que o referenciam
                $delete->execute ("DELETE FROM lextolex WHERE id_lexico_from = $id_lexico") ;
                $delete->execute ("DELETE FROM lextolex WHERE id_lexico_to = $id_lexico") ;
                # Remove o lexico escolhido
                $delete->execute ("DELETE FROM lexico WHERE id_lexico = $id_lexico") ;
        }
 }

###################################################################
# Funcao faz um insert na tabela de pedido.
# Para inserir um novo cenario ela deve receber os campos do novo
# cenario.
# Ao final ela manda um e-mail para todos os gerentes do projeto
# referente a este cenario.
# Arquivos que utilizam essa funcao:
# add_cenario.php
###################################################################
if (!(function_exists("inserirPedidoAdicionarCenario"))) {
    function inserirPedidoAdicionarCenario($id_projeto, $titulo, $objetivo, $contexto, $atores, $recursos, $episodios, $id_usuario)
    {
        $DB = new PGDB();
        $insere = new QUERY($DB);
        $select = new QUERY($DB);
        $select2 = new QUERY($DB);
        $insere->execute("INSERT INTO pedidocen (id_projeto, titulo, objetivo, contexto, atores, recursos, episodios, id_usuario, tipo_pedido, aprovado) VALUES ($id_projeto, '$titulo', '$objetivo', '$contexto', '$atores', '$recursos', '$episodios', $id_usuario, 'inserir', false)");
        $select->execute("SELECT * FROM usuario WHERE id_usuario = $id_usuario");
        $select2->execute("SELECT * FROM participa WHERE gerente = 't' AND id_projeto = $id_projeto");
        $record = $select->gofirst();
        $nome = $record['nome'];
        $email = $record['email'];
        $record2 = $select2->gofirst();
        while($record2 != 'LAST_RECORD_REACHED') {
            $id = $record2['id_usuario'];
            $select->execute("SELECT * FROM usuario WHERE id_usuario = $id");
            $record = $select->gofirst();
            $mailGerente = $record['email'];
            mail("$mailGerente", "Pedido de Inclus�o Cen�rio", "O usuario do sistema $nome\nPede para inserir o cenario $titulo \nObrigado!","From: $nome\r\n"."Reply-To: $email\r\n");
            $record2 = $select2->gonext();
        }
    }
}

###################################################################
# Funcao faz um insert na tabela de pedido.
# Para alterar um cenario ela deve receber os campos do cenario
# jah modificados.(1.1)
# Ao final ela manda um e-mail para todos os gerentes do projeto
# referente a este cenario.(2.1)
# Arquivos que utilizam essa funcao:
# alt_cenario.php
###################################################################
if (!(function_exists("inserirPedidoAlterarCenario"))) {
    function inserirPedidoAlterarCenario($id_projeto, $id_cenario, $titulo, $objetivo, $contexto, $atores, $recursos, $episodios, $justificativa, $id_usuario) {
        $DB = new PGDB();
        $insere = new QUERY($DB);
        $select = new QUERY($DB);
        $select2 = new QUERY($DB);
        $insere->execute("INSERT INTO pedidocen (id_projeto, id_cenario, titulo, objetivo, contexto, atores, recursos, episodios, id_usuario, tipo_pedido, aprovado, justificativa) VALUES ($id_projeto, $id_cenario, '$titulo', '$objetivo', '$contexto', '$atores', '$recursos', '$episodios', $id_usuario, 'alterar', false, '$justificativa')");
        $select->execute("SELECT * FROM usuario WHERE id_usuario = $id_usuario");
        $select2->execute("SELECT * FROM participa WHERE gerente = 't' AND id_projeto = $id_projeto");
        $record = $select->gofirst();
        $nome = $record['nome'];
        $email = $record['email'];
        $record2 = $select2->gofirst();
        while($record2 != 'LAST_RECORD_REACHED') {
            $id = $record2['id_usuario'];
            $select->execute("SELECT * FROM usuario WHERE id_usuario = $id");
            $record = $select->gofirst();
            $mailGerente = $record['email'];
            mail("$mailGerente", "Pedido de Altera��o Cen�rio", "O usuario do sistema $nome\nPede para alterar o cenario $titulo \nObrigado!","From: $nome\r\n"."Reply-To: $email\r\n");
            $record2 = $select2->gonext();
        }
    }
}

###################################################################
# Funcao faz um insert na tabela de pedido.
# Para remover um cenario ela deve receber
# o id do cenario e id projeto.(1.1)
# Ao final ela manda um e-mail para todos os gerentes do projeto
# referente a este lexico.(2.1)
# Arquivos que utilizam essa funcao:
# rmv_cenario.php
###################################################################
if (!(function_exists("inserirPedidoRemoverCenario"))) {
    function inserirPedidoRemoverCenario($id_projeto, $id_cenario, $id_usuario) {
        $DB = new PGDB();
        $insere = new QUERY($DB);
        $select = new QUERY($DB);
        $select2 = new QUERY($DB);
        $select->execute("SELECT * FROM cenario WHERE id_cenario = $id_cenario");
        $cenario = $select->gofirst();
        $titulo = $cenario['titulo'];
        $insere->execute("INSERT INTO pedidocen (id_projeto, id_cenario, titulo, id_usuario, tipo_pedido, aprovado) VALUES ($id_projeto, $id_cenario, '$titulo', $id_usuario, 'remover', false)");
        $select->execute("SELECT * FROM usuario WHERE id_usuario = $id_usuario");
        $select2->execute("SELECT * FROM participa WHERE gerente = 't' AND id_projeto = $id_projeto");
        $record = $select->gofirst();
        $nome = $record['nome'];
        $email = $record['email'];
        $record2 = $select2->gofirst();
        while($record2 != 'LAST_RECORD_REACHED') {
            $id = $record2['id_usuario'];
            $select->execute("SELECT * FROM usuario WHERE id_usuario = $id");
            $record = $select->gofirst();
            $mailGerente = $record['email'];
            mail("$mailGerente", "Pedido de Remover Cen�rio", "O usuario do sistema $nome\nPede para remover o cenario $id_cenario \nObrigado!", "From: $nome\r\n" . "Reply-To: $email\r\n");
            $record2 = $select2->gonext();
        }
    }
}

 ###################################################################
 # Funcao faz um insert na tabela de pedido.
 # Para inserir um novo lexico ela deve receber os campos do novo
 # lexicos.
 # Ao final ela manda um e-mail para todos os gerentes do projeto
 # referente a este lexico.
 # Arquivos que utilizam essa funcao:
 # add_lexico.php
 ###################################################################
 if (!(function_exists("inserirPedidoAdicionarLexico"))) {
     function inserirPedidoAdicionarLexico($id_projeto,$nome,$nocao,$impacto,$id_usuario){
        $DB = new PGDB () ;
        $insere = new QUERY ($DB) ;
        $select = new QUERY ($DB) ;
        $select2 = new QUERY ($DB) ;
        $insere->execute("INSERT INTO pedidolex (id_projeto,nome,nocao,impacto,id_usuario,tipo_pedido,aprovado) VALUES ($id_projeto,'$nome','$nocao','$impacto',$id_usuario,'inserir',false)") ;
        $select->execute("SELECT * FROM USUARIO WHERE id_usuario = '$id_usuario'") ;
        $select2->execute("SELECT * FROM PARTICIPA WHERE gerente = 't' and id_projeto = $id_projeto") ;

        if ($select->getntuples() == 0&&$select2->getntuples() == 0){
                 echo "<BR> [ERRO]Pedido nao foi comunicado por e-mail." ;
        }else{
                $record = $select->gofirst ();
            $nome2 = $record['nome'] ;
            $email = $record['email'] ;
            $record2 = $select2->gofirst ();
            while($record2 != 'LAST_RECORD_REACHED'){
                $id = $record2['id_usuario'] ;
                $select->execute("SELECT * FROM USUARIO WHERE id_usuario = $id") ;
                $record = $select->gofirst ();
                $mailGerente = $record['email'] ;
                mail("$mailGerente", "Pedido de Inclus�o de L�xico", "O usuario do sistema $nome2\nPede para inserir o lexico $nome \nObrigado!","From: $nome2\r\n"."Reply-To: $email\r\n");
        $record2 = $select2->gonext();
        }
        }
    }
 }

 ###################################################################
 # Funcao faz um insert na tabela de pedido.
 # Para alterar um lexico ela deve receber os campos do lexicos
 # jah modificados.(1.1)
 # Ao final ela manda um e-mail para todos os gerentes do projeto
 # referente a este lexico.(2.1)
 # Arquivos que utilizam essa funcao:
 # alt_lexico.php
 ###################################################################
 if (!(function_exists("inserirPedidoAlterarLexico"))) {
     function inserirPedidoAlterarLexico($id_projeto,$id_lexico,$nome,$nocao,$impacto,$justificativa,$id_usuario){
        $DB = new PGDB () ;
        $insere = new QUERY ($DB) ;
        $select = new QUERY ($DB) ;
        $select2 = new QUERY ($DB) ;
        $insere->execute("INSERT INTO pedidolex (id_projeto,id_lexico,nome,nocao,impacto,id_usuario,tipo_pedido,aprovado,justificativa) VALUES ($id_projeto,$id_lexico,'$nome','$nocao','$impacto',$id_usuario,'alterar',false,'$justificativa')") ;
        $select->execute("SELECT * FROM USUARIO WHERE id_usuario = '$id_usuario'") ;
        $select2->execute("SELECT * FROM PARTICIPA WHERE gerente = 't' and id_projeto = $id_projeto") ;

        if ($select->getntuples() == 0&&$select2->getntuples() == 0){
                 echo "<BR> [ERRO]Pedido nao foi comunicado por e-mail." ;
        }else{
                $record = $select->gofirst ();
            $nome2 = $record['nome'] ;
            $email = $record['email'] ;
            $record2 = $select2->gofirst ();
            while($record2 != 'LAST_RECORD_REACHED'){
                $id = $record2['id_usuario'] ;
                $select->execute("SELECT * FROM USUARIO WHERE id_usuario = $id") ;
                $record = $select->gofirst ();
                $mailGerente = $record['email'] ;
                mail("$mailGerente", "Pedido de Alterar L�xico", "O usuario do sistema $nome2\nPede para alterar o lexico $nome \nObrigado!","From: $nome2\r\n"."Reply-To: $email\r\n");
        $record2 = $select2->gonext();
        }
        }
    }
 }
 ###################################################################
 # Funcao faz um insert na tabela de pedido.
 # Para remover um lexico ela deve receber
 # o id do lexico e id projeto.(1.1)
 # Ao final ela manda um e-mail para todos os gerentes do projeto
 # referente a este lexico.(2.1)
 # Arquivos que utilizam essa funcao:
 # rmv_lexico.php
 ###################################################################
 if (!(function_exists("inserirPedidoRemoverLexico"))) {
    function inserirPedidoRemoverLexico($id_projeto,$id_lexico,$id_usuario){
        $DB = new PGDB () ;
        $insere = new QUERY ($DB) ;
        $select = new QUERY ($DB) ;
        $select2 = new QUERY ($DB) ;
        $select->execute("SELECT * FROM LEXICO WHERE id_lexico = $id_lexico") ;
        $lexico = $select->gofirst ();
      $nome = $lexico['nome'] ;
        $insere->execute("INSERT INTO pedidolex (id_projeto,id_lexico,nome,id_usuario,tipo_pedido,aprovado) VALUES ($id_projeto,$id_lexico,'$nome',$id_usuario,'remover',false)") ;
        $select->execute("SELECT * FROM USUARIO WHERE id_usuario = $id_usuario") ;
        $select2->execute("SELECT * FROM PARTICIPA WHERE gerente = 't' and id_projeto = $id_projeto") ;

        if ($select->getntuples() == 0&&$select2->getntuples() == 0){
             echo "<BR> [ERRO]Pedido nao foi comunicado por e-mail." ;
        }else{
        $record = $select->gofirst ();
            $nome = $record['nome'] ;
            $email = $record['email'] ;
        $record2 = $select2->gofirst ();
                while($record2 != 'LAST_RECORD_REACHED'){
                $id = $record2['id_usuario'] ;
                $select->execute("SELECT * FROM USUARIO WHERE id_usuario = $id") ;
                $record = $select->gofirst ();
                $mailGerente = $record['email'] ;
                mail("$mailGerente", "Pedido de Remover L�xico", "O usuario do sistema $nome2\nPede para remover o lexico $id_lexico \nObrigado!","From: $nome\r\n"."Reply-To: $email\r\n");
                $record2 = $select2->gonext();
                }
        }
    }
}
 ###################################################################
 # Processa um pedido identificado pelo seu id.
 # Recebe o id do pedido.(1.1)
 # Faz um select para pegar o pedido usando o id recebido.(1.2)
 # Pega o campo tipo_pedido.(1.3)
 # Se for para remover: Chamamos a funcao remove();(1.4)
 # Se for para alterar: Devemos (re)mover o cenario e inserir o novo.
 # Se for para inserir: chamamos a funcao insert();
 ###################################################################
if (!(function_exists("tratarPedidoCenario"))) {
    function tratarPedidoCenario($id_pedido){
        $DB = new PGDB () ;
        $select = new QUERY ($DB) ;
        $delete = new QUERY ($DB) ;
        $select->execute("SELECT * FROM PEDIDOCEN WHERE id_pedido = $id_pedido") ;
        if ($select->getntuples() == 0){
             echo "<BR> [ERRO]Pedido invalido." ;
        }else{
                $record = $select->gofirst () ;
                $tipoPedido = $record['tipo_pedido'] ;
                if(!strcasecmp($tipoPedido,'remover')){
                        $id_cenario = $record['id_cenario'] ;
                        $id_projeto = $record['id_projeto'] ;
                        removeCenario($id_projeto,$id_cenario) ;
                        //$delete->execute ("DELETE FROM PEDIDOCEN WHERE id_cenario = $id_cenario") ;
                }else{

                        $id_projeto = $record['id_projeto'] ;
                        $titulo = $record['titulo'] ;
                        $objetivo = $record['objetivo'] ;
                        $contexto = $record['contexto'] ;
                        $atores = $record['atores'] ;
                        $recursos = $record['recursos'] ;
                        $episodios = $record['episodios'] ;
                        if(!strcasecmp($tipoPedido,'alterar')){
                            $id_cenario = $record['id_cenario'] ;
                            removeCenario($id_projeto,$id_cenario) ;
                            //$delete->execute ("DELETE FROM PEDIDOCEN WHERE id_cenario = $id_cenario") ;
                        }
                        adicionar_cenario($id_projeto, $titulo, $objetivo, $contexto, $atores, $recursos, $episodios) ;
                }
                //$delete->execute ("DELETE FROM PEDIDOCEN WHERE id_pedido = $id_pedido") ;
        }
    }
}
 ###################################################################
 # Processa um pedido identificado pelo seu id.
 # Recebe o id do pedido.(1.1)
 # Faz um select para pegar o pedido usando o id recebido.(1.2)
 # Pega o campo tipo_pedido.(1.3)
 # Se for para remover: Chamamos a funcao remove();(1.4)
 # Se for para alterar: Devemos (re)mover o lexico e inserir o novo.
 # Se for para inserir: chamamos a funcao insert();
 ###################################################################
if (!(function_exists("tratarPedidoLexico"))) {
    function tratarPedidoLexico($id_pedido){
        $DB = new PGDB () ;
        $select = new QUERY ($DB) ;
        $delete = new QUERY ($DB) ;
        $select->execute("SELECT * FROM PEDIDOLEX WHERE id_pedido = $id_pedido") ;
        if ($select->getntuples() == 0){
             echo "<BR> [ERRO]Pedido invalido." ;
        }else{
                $record = $select->gofirst () ;
                $tipoPedido = $record['tipo_pedido'] ;
                if(!strcasecmp($tipoPedido,'remover')){
                        $id_lexico = $record['id_lexico'] ;
                        $id_projeto = $record['id_projeto'] ;
                        removeLexico($id_projeto,$id_lexico) ;
                        //$delete->execute ("DELETE FROM PEDIDOLEX WHERE id_lexico = $id_lexico") ;
                }else{

                        $id_projeto = $record['id_projeto'] ;
                        $nome = $record['nome'] ;
                        $nocao = $record['nocao'] ;
                        $impacto = $record['impacto'] ;
                        if(!strcasecmp($tipoPedido,'alterar')){
                            $id_lexico = $record['id_lexico'] ;
                            removeLexico($id_projeto,$id_lexico) ;
                            //$delete->execute ("DELETE FROM PEDIDOLEX WHERE id_lexico = $id_lexico") ;
                        }
                        adicionar_lexico($id_projeto, $nome, $nocao, $impacto) ;
                }
                //$delete->execute ("DELETE FROM PEDIDOLEX WHERE id_pedido = $id_pedido") ;
        }
    }
}
#############################################
#Deprecated by the author:
#Essa funcao deveria receber um id_projeto
#de forma a verificar se o gerente pertence
#a esse projeto.Ela so verifica atualmente
#se a pessoa e um gerente.
#############################################
if (!(function_exists("verificaGerente"))) {
    function verificaGerente($id_usuario){
        $DB = new PGDB () ;
        $select = new QUERY ($DB) ;
        $select->execute("SELECT * FROM PARTICIPA WHERE gerente = 't' AND id_usuario = $id_usuario") ;
        if ($select->getntuples() == 0){
             return 0 ;
        }else{
            return 1 ;
        }
    }
}

// Retorna TRUE ssse $id_usuario eh admin de $id_projeto
if (!(function_exists("is_admin"))) {
    function is_admin($id_usuario, $id_projeto)
    {
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
        $q = "SELECT *
              FROM participa
              WHERE id_usuario = $id_usuario
              AND id_projeto = $id_projeto
              AND gerente = 't'";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        return (1 == mysql_num_rows($qrr));
    }
}

// Retorna TRUE ssse $id_usuario tem permissao sobre $id_projeto
if (!(function_exists("check_proj_perm"))) {
    function check_proj_perm($id_usuario, $id_projeto)
    {
        $r = mysql_pconnect("139.82.35.67","root","") or die("Erro ao conectar ao SGBD");
        $q = "SELECT *
              FROM participa
              WHERE id_usuario = $id_usuario
              AND id_projeto = $id_projeto";
        $qrr = mysql_query($r, $q) or die("Erro ao enviar a query");
        return (1 == mysql_num_rows($qrr));
    }
}

?>

