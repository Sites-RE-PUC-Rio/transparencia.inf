<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */

// add_lexico.php: Este script cadastra um novo termo no lexico do projeto. E
//                 passada, atraves da URL, uma variavel $id_projeto, que
//                 indica em que projeto deve ser inserido o novo termo.

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Checa se o usuario foi autenticado

// Conecta ao SGBD
$r = pg_connect("dbname=trabalho user=postgres password=SuperBonder") or die("Erro ao conectar ao SGBD");

if (isset($submit)) {        // Script chamado atraves do submit do formulario
inserirPedidoAdicionarLexico($id_projeto,$nome,$nocao,$impacto,$id_usuario_corrente) ;
?>

<script language="javascript1.2">

opener.parent.frames['code'].location.reload();
opener.parent.frames['text'].location.replace('main.php?id_projeto=<?=$_SESSION['id_projeto_corrente']?>');
self.close();

</script>

<?php
} else {        // Script chamado atraves do menu superior
    $q = "SELECT nome FROM projeto WHERE id_projeto = $id_projeto";
    $qrr = pg_query($r, $q) or die("Erro ao executar a query");
    $result = pg_fetch_array($qrr);
    $nome_projeto = $result['nome'];
?>

<html>
    <head>
        <title>Adicionar L�xico</title>
    </head>
    <body>
        <h4>Adicionar L�xico</h4>
        <br>
        <form action="<?=$PHP_SELF?>?id_projeto=<?=$id_projeto?>" method="post">
        <table>
            <tr>
                <td>Projeto:</td>
                <td><input disabled size="48" type="text" value="<?=$nome_projeto?>"></td>
            </tr>
                <td>Nome:</td>
                <td><textarea cols="32" name="nome" rows="2" WRAP="SOFT"></textarea></td>
            <tr>
                <td>No��o:</td>
                <td><textarea cols="51" name="nocao" rows="5" WRAP="SOFT"></textarea></td>
            </tr>
            <tr>
                <td>Impacto:</td>
                <td><textarea  cols="51" name="impacto" rows="5" WRAP="SOFT"></textarea></td>
            </tr>
            <tr>
                <td align="center" colspan="2" height="60"><input name="submit" type="submit" value="Adicionar L�xico"></td>
            </tr>
        </table>
        </form>
    </body>
</html>

<?php
}
?>
