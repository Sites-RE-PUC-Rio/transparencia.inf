<?php

session_start();

include("funcoes_genericas.php");

chkUser("index.php");        // Checa se o usuario foi autenticado

?>

<html>

<body>

    <head>
        <title>Gerar XML</title>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    </head><form action="gerador_xml.php" method="post">

    Propriedades do Relat�rio a ser Gerado: <br>

    &nbsp;<p>Data da Vers�o (dd / mm / aaaa):</p>
    <p>&nbsp;<input type="text" name="data_dia" size="3"> / 
    <input type="text" name="data_mes" size="3"> / 
    <input type="text" name="data_ano" size="6"><br>

    &nbsp;</p>
    <p>Exibir

    Formatado: <input type="checkbox" name="flag" value="ON"><br><br>

    <input type="submit" value="Gerar"> </p>

</form>

</body>

</html>