<HTML>
   <head>
      <title>Tarefas</title>
      <style>
BODY
{
    MARGIN: 10px 0px;
    COLOR: black;
    FONT-FAMILY: Verdana;
    BACKGROUND-COLOR: white
}
A
{
    FONT-WEIGHT: bolder;
    COLOR: RED;
    FONT-FAMILY: Verdana;
    TEXT-DECORATION: none
}
A:hover
{
    FONT-WEIGHT: bolder;
    COLOR: YELLOW;
    FONT-FAMILY: Verdana
}
H3
{
    BORDER-TOP: #f0d800 1px solid;
    PADDING-LEFT: 4px;
    MARGIN-BOTTOM: 0.5em;
    MARGIN-LEFT: 1em;
    BORDER-LEFT: #f0d800 8px solid
}
TH
{
    FONT-WEIGHT: bolder;
    COLOR: WHITE;
    BACKGROUND-COLOR: #d7c11f;
}
TD
{
    COLOR: black;
    BACKGROUND-COLOR: #dde068;
}

TABLE
{
MARGIN-LEFT: 1.2em;
MARGIN-RIGHT: 1.2em;
}

P
{
    PADDING-LEFT: 4px;
    MARGIN-BOTTOM: 0.5em;
    MARGIN-LEFT: 1.5em
}
         </style>
      </head>
   <BODY>
Escolha a forma de ordena��o: 
<INPUT TYPE="BUTTON" VALUE="Data" onclick="self.document.location.replace ('<?=$PHP_SELF?>?ordena=data');"/>
<INPUT TYPE="BUTTON" VALUE="T�tulo" onclick="self.document.location.replace('<?=$PHP_SELF?>?ordena=titulo');"/>
<INPUT TYPE="BUTTON" VALUE="Autores" onclick="self.document.location.replace('<?=$PHP_SELF?>?ordena=autores');"/>

<DIV id="conteudo">
<?php
   if ( isset ( $ordena ) )
   {
      if ( $ordena == "data" )
         $xsl = "tarefasData.xsl";
      if ( $ordena == "titulo" )
         $xsl = "tarefasTitulo.xsl";
      if ( $ordena == "autores" )
         $xsl = "tarefasAutores.xsl";
      if ( isset ( $xsl ) )
      {
         $xsltproc = xslt_create();
         $html = xslt_process($xsltproc, 'historico.xml', $xsl );
         if ( !$html ) 
            die ( "Erro ao processar o arquivo XML: " . xslt_error ( $xsltproc ) );
         xslt_free($xsltproc);
      }
   }
   echo $html;
?>
</DIV>
</BODY>
</HTML>