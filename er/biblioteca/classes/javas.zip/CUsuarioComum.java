/**
 * Classe que representa um usuario comum.
 */
public class CUsuarioComum
{
	private String CPF;
	private String nome;
	private String senha;

	static int maxExemplaresEmprestados = 5;

	/**
     * Inicializa um usuario comum.
     *
     * @param str_nome Nome do usuario.
     * @param str_CPF CPF do usuario.
     * @param str_senha Senha do usuario.
     */
	public CUsuarioComum(String str_nome, String str_CPF, String str_senha)
	{
		CPF = str_CPF;
		nome = str_nome;
		senha = str_senha;
	}

	/**
     * Busca no BD o usuario comum com o CPF especificado.
     *
     * @param CPFUsuarioComum CPF do usuario.
     * @param facadeBD Facade de BD da aplicacao.
     * @return Usuario comum com o CPF especificado.
     */
    static public CUsuarioComum obterUsuarioComum(String CPFUsuarioComum, CFacadeBD facadeBD)
	{
		return facadeBD.obterUsuarioComum(CPFUsuarioComum);
	}

	/**
     * Obtem o numero de exemplares emprestados com um usuario comum.
     *
     * @param facadeBD Facade de BD da aplicacao.
     * @return Numero de exemplares emprestados com um usuario comum.
     */
    public int obterNumExemplaresEmprestados(CFacadeBD facadeBD)
	{
		return facadeBD.obterNumExemplaresEmprestados(this);
	}

	/**
     * Adiciona o usuario comum no BD.
     *
     * @param facadeBD Facade de BD da aplicacao.
     */
	public void adicionar(CFacadeBD facadeBD)
	{
		facadeBD.salvarUsuarioComum (this);
	}

	/**
     * Remove o usuario comum do BD.
     *
     * @param facadeBD Facade de BD da aplicacao.
     */
	public void remover(CFacadeBD facadeBD)
	{
		facadeBD.removerUsuarioComum (this);
	}

	/**
     * Obtem o CPF do usuario.
     *
     * @return CPF do usuario.
     */
    public String obterCPF ()
	{
		return CPF;
	}

	/**
     * Obtem o nome do usuario.
     *
     * @return Nome do usuario.
     */
	public String obterNome()
	{
		return nome;
	}

	/**
     * Obtem a senha do usuario.
     *
     * @return Senha do usuario.
     */
	public String obterSenha()
	{
		return senha;
	}
}
