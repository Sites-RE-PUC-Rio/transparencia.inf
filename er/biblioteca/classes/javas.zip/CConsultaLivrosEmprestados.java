import java.util.* ;

/**
 * Classe que gerencia consultas que dizem os livros emprestados a um usuario.
 */
public class CConsultaLivrosEmprestados
{
	Vector resultado;  // vetor de CExemplar
	CUsuarioComum usu;
	CFacadeBD facadeBD;

        /**
         * Construtor que recebe um vetor de resultado de uma pesquisa.
         *
         * @param exemplares Vetor de exemplares emprestados a um usuario.
         */
	public CConsultaLivrosEmprestados (Vector exemplares)
	{
		resultado = exemplares;
	}

        /**
         * Construtor que recebe um usuario para consulta.
         *
         * @param p_usu Usuario da biblioteca
         * @param p_facadeBD Facade de banco de dados da aplicacao.
         */
	public CConsultaLivrosEmprestados( CUsuarioComum p_usu, CFacadeBD p_facadeBD){
		facadeBD = p_facadeBD;
		usu = p_usu;
	}

        /**
         * Obtem a quantidade de livros retornados na consulta.
         *
         * @return Quantidade de exemplares obtidos em uma consulta.
         */
	public int obterQtdeLivros ()
	{
		return resultado.size();
	}

        /**
         * Obtem um determinado livro da consulta.
         *
         * @param i Indice do exemplar
         * @return Exemplar que ocupa a posicao especificada pelo indice i.
         */
	public CExemplar obterExemplar (int i)
	{
		if (i > obterQtdeLivros ())
		{
			return null;
		}
		return (CExemplar) resultado.elementAt(i);
	}

        /**
         * Realiza a pesquisa. Os atributos usuario e facadeBD devem ter
         * valores validos.
         *
         * @param usu Usuario da biblioteca.
         * @param facadeBD Facade de banco de dados da aplicacao.
         * @return Resultado da consulta de livros emprestados a um usuario.
         */
	public static CConsultaLivrosEmprestados consultar(CUsuarioComum usu, CFacadeBD facadeBD)
	{
		return facadeBD.consultaLivrosEmprestado(usu);
	}
}