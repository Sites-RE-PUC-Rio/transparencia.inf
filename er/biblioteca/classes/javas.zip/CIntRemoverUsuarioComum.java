import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de remocao de usuario comum.
 */
public class CIntRemoverUsuarioComum extends Frame{
	CFacadeInterface	facadeI;
        CRemoverUsuarioComumPanel             removerUsuarioComumPanel ;

    /**
     * Inicializa janela de remocao de usuario comum.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntRemoverUsuarioComum( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[1];
                s[0] = "CPF:";
                removerUsuarioComumPanel = new CRemoverUsuarioComumPanel (this, 1, s, -1, facadeI);
                add(removerUsuarioComumPanel);
    }

}

class CRemoverUsuarioComumPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CRemoverUsuarioComumPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0)
    {
	facadeI.informar("Favor fornecer dados!");
    } else {
	facadeI.efetuarRemocaoUsuarioComum(getFieldText(0));
	owner.dispose();
    }
  }
}

