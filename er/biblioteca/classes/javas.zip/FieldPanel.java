import java.awt.*;
import java.awt.event.*;

class OkClicked extends MouseAdapter
{
  Frame owner;
  Panel panel;

  public OkClicked (Frame newOwner, Panel newPanel)
  {
    owner = newOwner;
    panel = newPanel;
  }

  public void mousePressed (MouseEvent e)
  {
    //panel.action ();
  }
}


/**
 * Classe geradora de janelas de campos. Automatiza o processo de geracao de
 * janelas de campos, gerando um formulario de acordo com as opcoes passadas
 * no construtor.
 */
public class FieldPanel extends Panel implements ActionListener
{
  // Parametros do construtor
  int numNames;
  String names[];
  Frame owner;
  int comboId;

  // Componentes fixos
  FlowLayout buttonFlowLayout = new FlowLayout();
  protected Panel buttonPannel = new Panel(buttonFlowLayout);
  Button okButton = new Button();

  GridLayout gridLayout = new GridLayout();
  Panel gridPanel = new Panel(gridLayout);

  // Componentes variaveis
  Insets border = new Insets (30, 10, 100, 100);
  FlowLayout labelLayout[];
  FlowLayout fieldLayout[];
  Panel labelPanel[];
  Panel fieldPanel[];
  Label label[];
  TextField field[];
  Choice combo = new Choice ();

  /**
  * Construtor da classe FieldPanel. Cria um Panel com uma ou mais caixas de texto,
  * cada uma correspondendo a um campo. No m�ximo uma caixa de texto pode ser
  * substituida por uma caixa de opcoes. Pode haver zero ou mais caixas de texto
  * para senhas (substituicao de caracteres por '*').
  *
  * @param panOwner Frame onde o Panel sera' inserido.
  * @param numPanNames Numero de campos do Panel.
  * @param panNames Vetor de String que contem os nomes do campos.
  * @param panComboId Indica qual campo sera' representado por uma caixa de opcoes.
  */
  public FieldPanel(Frame panOwner, int numPanNames, String [] panNames, int panComboId)
  {
    super (new BorderLayout());
    numNames = numPanNames;
    names = panNames;
    owner = panOwner;
    comboId = panComboId;

    okButton.setLabel ("    OK    ");
    buttonPannel.add(okButton, null);
    okButton.addActionListener (this);

    gridLayout.setColumns (2);
    gridLayout.setHgap(10);
    gridLayout.setVgap(10);

    gridLayout.setRows (numNames+2);
    gridPanel.add (new Panel());
    gridPanel.add (new Panel());
    labelPanel  = new Panel[numNames];
    label       = new Label[numNames];
    labelLayout = new FlowLayout[numNames];
    fieldPanel  = new Panel[numNames];
    field       = new TextField[numNames];
    fieldLayout = new FlowLayout[numNames];
    for (int i = 0; i < numNames; i++)
    {
      label[i] = new Label ();
      field[i] = new TextField (10);
      labelLayout[i] = new FlowLayout ();
      fieldLayout[i] = new FlowLayout ();
      labelLayout[i].setAlignment(FlowLayout.RIGHT);
      labelPanel[i] = new Panel (labelLayout[i]);
      label[i].setText (names[i]);
      labelPanel[i].add (label[i], null);
      fieldLayout[i].setAlignment(FlowLayout.LEFT);
      fieldPanel[i] = new Panel (fieldLayout[i]);
      if (i != comboId)
      {
        field[i].setText ("");
        fieldPanel[i].add (field[i], BorderLayout.NORTH);
      }
      else
      {
        fieldPanel[i].add (combo, BorderLayout.NORTH);
      }
      gridPanel.add (labelPanel[i], border);
      gridPanel.add (fieldPanel[i], border);
    }
    gridPanel.add (new Panel());
    gridPanel.add (new Panel());

    add (buttonPannel, BorderLayout.SOUTH);
    add (gridPanel, BorderLayout.CENTER);
  }

  /**
  * Seleciona um campo como campo de senha. Substitui os caracteres da caixa de
  * texto por '*'.
  *
  * @param i Indice do campo de senha.
  */
  public void setPasswordField (int i)
  {
    field[i].setEchoChar('*');
  }

  /**
  * Fornece o valor de um campo.
  *
  * @param i Indice do campo.
  * @return Retorna o valor do campo de indice i.
  */
  public String getFieldText (int i)
  {
    return field[i].getText();
  }

  /**
  * Adiciona uma opcao `a caixa de opcoes. Se nao existe caixa de opcoes, nao faz
  * nada.
  *
  * @param s String a ser adicionado na caixa de opcoes
  */
  public void addChoice (String s)
  {
    if (comboId == -1)
    {
      return;
    }
    combo.add(s);
  }

  /**
  * Fornece o valor escolhido na caixa de opcoes.
  *
  * @return Retorna o valor escolhido na caixa de opcoes.
  */
  public String getChoice ()
  {
    if (comboId == -1)
    {
      return null;
    }
    return combo.getSelectedItem();
  }


  /**
  * Evento de mouse que ocorre ao pressionar o botao "Ok". Este evento deve ser
  * sobrecarregado nas classes derivadas de FieldPanel.
  *
  * @param e Objeto que encapsula o evento.
  */
  public void actionPerformed (ActionEvent e)
  {
  }
}