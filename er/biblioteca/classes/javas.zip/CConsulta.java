
/**
 * Classe que gerencia as consultas feitas pelos usuarios.
 */
public class CConsulta
{
	private CFacadeBD facadeBD;
	private CFacadeInterface facadeI;

	/**
         * Inicializa as variaveis Facade.
         *
         * @param fBD Facade de banco de dados da aplicacao
         * @param facI Facade de interface da aplicacao
         */
        public CConsulta(CFacadeBD fBD, CFacadeInterface facI)
	{
    facadeBD = fBD;
    facadeI = facI;
	}

	/**
         * Realiza uma consulta a Livros. Pode ser feita por qualquer
         * atributo de Livro.
         *
         * @param ISBN ISBN do livro
         * @param titulo Titulo do livro
         * @param autor Autor do livro
         * @param edicao Edicao do livro
         * @param editora Editora do livro
         * @param areaInteresse Area de interesse do livro
         */
        public void consultarLivro (String ISBN,
								String titulo,
								String autor,
								String edicao,
								String editora,
								String areaInteresse)
	{
		CConsultaLivro consulta = CConsultaLivro.consultar (ISBN, titulo, autor,
                                                        edicao, editora, areaInteresse, facadeBD);

		if (consulta.obterQtdeLivros () == 0)
		{
			facadeI.informar ("Nao foram encontrados livros para esta busca.");
			return;
		}

		facadeI.mostrarConsultaLivro (consulta);
	}

	/**
         * Realiza uma consulta aos livros emprestados a um usuario.
         *
         * @param CPF CPF do usuario
         */
        public void consultarLivrosEmprestados (String CPF)
	{
		CUsuarioComum usu = CUsuarioComum.obterUsuarioComum(CPF, facadeBD);
		if (usu == null)
		{
			facadeI.informar ("Usuario nao cadastrado.");
			return;
		}

		CConsultaLivrosEmprestados consulta = CConsultaLivrosEmprestados.consultar(usu, facadeBD);

		if (consulta.obterQtdeLivros () == 0)
		{
			facadeI.informar ("Nao foram encontrados livros para esta busca.");
			return;
		}

		facadeI.mostrarConsultaLivrosEmprestados (consulta);
	}

        /**
         * Determina qual o ultimo usuario a emprestar o determinado exemplar.
         *
         * @param exemplarId Identificador do exemplar
         */
	public void consultarUltimoUsuario (int exemplarId)
	{
		CExemplar exemp = CExemplar.obterExemplar(exemplarId, facadeBD);
		if (exemp == null)
		{
			facadeI.informar ("Exemplar nao cadastrado.");
			return;
		}

		facadeI.mostrarConsultaUltimoUsuario(exemp);
	}
}
