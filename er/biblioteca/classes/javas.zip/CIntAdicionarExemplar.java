import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de adicao de exemplar.
 */
public class CIntAdicionarExemplar extends Frame{
	CFacadeInterface	facadeI;
        CAdicionarExemplarPanel             adicionarExemplarPanel ;

    /**
     * Inicializa janela de adicao de exemplar.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntAdicionarExemplar( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[1];
                s[0] = "ISBN:";
                adicionarExemplarPanel = new CAdicionarExemplarPanel (this, 1, s, -1, facadeI);
                add(adicionarExemplarPanel);
    }

}

class CAdicionarExemplarPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CAdicionarExemplarPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0)
    {
	facadeI.informar("Favor fornecer Livro que tem novo exemplar!");
    } else {
	facadeI.efetuarAdicaoExemplar(getFieldText(0));
	owner.dispose();
    }
  }
}

