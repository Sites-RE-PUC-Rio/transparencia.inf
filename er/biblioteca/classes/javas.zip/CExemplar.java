import java.util.* ;

/**
 * Class da aplicacao que gerencia exemplares de livros.
 */
public class CExemplar
{
	private int           numeroRegistro;
	private CLivro        livro;
	private CUsuarioComum ultimoUsuario;
	private Date		      dataEmprestimo;
	private boolean       disponivel;

	static int    maxDiasEmprestimo = 7;
	static float  multaPorDia = (float) 1.5;
	static int    novoId = 0;

	/**
         * Construtor que recebe uma instancia de CLivro e inicializa um novo
         * exemplar para este livro.
         *
         * @param l Livro ao qual o exemplar pertence.
         */
        CExemplar (CLivro l)
	{
		livro          = l;
		disponivel     = true;
		ultimoUsuario  = null;
		dataEmprestimo = new Date();
	}

	/**
         * Construtor que recebe todos os dados de um exemplar.
         *
         * @param nReg Numero de registro do exemplar.
         * @param lvr Livro ao qual o exemplar pertence.
         * @param usr Usuario que pegou o exemplar emprestado (<code>null</code> se nenhum).
         * @param dt Data de emprestimo do exemplar.
         * @param disp Flag cujo valor eh <code>true</code> se o exemplar esta disponivel.
         */
        CExemplar ( int nReg,
				CLivro lvr,
				CUsuarioComum usr,
				Date dt,
				boolean disp )
	{
		numeroRegistro = nReg;
		livro          = lvr;
		disponivel     = disp;
		ultimoUsuario  = usr;
		dataEmprestimo = dt;
	}

        /**
         * Obter um exemplar no BD.
         *
         * @param exempId Numero de registro do exemplar
         * @param facadeBD Facade de banco de dados da aplicacao.
         * @return Exemplar com o numero de registro especificado.
         */
	public static CExemplar obterExemplar (int exempId, CFacadeBD facadeBD)
	{
		return facadeBD.obterExemplar (exempId);
	}

        /**
         * Marca um exemplar como emprestado (nao disponivel).
         *
         * @param usu Usuario que esta pegando o exemplar emprestado.
         * @param facadeBD Facade de banco de dados da aplicacao.
         */
      	public void marcarEmprestado (CUsuarioComum usu, CFacadeBD facadeBD)
	{
		ultimoUsuario = usu;
		dataEmprestimo = new Date();
		disponivel = false;
		facadeBD.atualizarExemplar(this);
	}

        /**
         * Marca um exemplar como devolvido (disponivel).
         *
         * @param facadeBD Facade de banco de dados da aplicacao.
         */
	public void marcarDevolvido (CFacadeBD facadeBD)
	{
		disponivel = true;
		facadeBD.atualizarExemplar (this);
	}

	/**
         * Verifica se um exemplar esta disponivel.
         *
         * @return Retorna <code>true</code> se exemplar se encontra disponivel,
         * e <code>false</code> caso esteja emprestado.
         */
        public boolean ehDisponivel ()
	{
		return disponivel;
	}

        /**
         * Calcula a multa devida pelo usuario.
         *
         * @return Valor da multa a ser cobrada do usuario.
         */
	public float calcularMulta ()
	{
		Date hoje = new Date();
		long difMS = hoje.getTime() - dataEmprestimo.getTime();
		long dif = difMS/(1000*60*60*24);
		if (dif > maxDiasEmprestimo)
		{
			dif = dif-maxDiasEmprestimo;
			return (float)dif * multaPorDia;
		}
    return 0;
	}

	/**
         * Obter o numero de registro (gerado automaticamente) de um exemplar.
         *
         * @return Numero de registro do exemplar.
         */
        public int obterNumRegistro ()
	{
		return numeroRegistro;
	}

	/**
         * Adiciona um exemplar ao BD.
         *
         * @param facadeBD Facade de banco de dados da aplicacao.
         */
        public void adicionar(CFacadeBD facadeBD)
	{
		numeroRegistro = facadeBD.salvarExemplar (this);
	}

	/**
         * Remove o exemplar do BD.
         *
         * @param facadeBD Facade de banco de dados da aplicacao.
         */
        public void remover (CFacadeBD facadeBD)
	{
		facadeBD.removerExemplar (this);
	}

	/**
         * Obtem o livro associado ao exemplar.
         *
         * @return Livro associado ao exemplar.
         */
        public CLivro obterLivro ()
	{
		return livro;
	}

	/**
         * Obtem o ultimo usuario a emprestar o exemplar.
         *
         * @return Ultimo usuario a pegar o exemplar emprestado.
         */
        public CUsuarioComum obterUltimoUsuario ()
	{
		return ultimoUsuario;
	}

	/**
         * Obtem a data do ultimo emprestimo do exemplar.
         *
         * @return Data do ultimo emprestimo do exemplar.
         */
        public Date obterDataEmprestimo ()
	{
		return dataEmprestimo;
	}
}
