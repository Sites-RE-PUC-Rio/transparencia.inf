import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de emprestimo.
 */
public class CIntEmprestimo extends Frame{
	CFacadeInterface	facadeI;
        CEmprestimoPanel             emprestimoPanel ;

    /**
     * Inicializa janela de emprestimo.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntEmprestimo( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[2];
                s[0] = "CPF Usuario:";
                s[1] = "ISBN:";
                emprestimoPanel = new CEmprestimoPanel (this, 2, s, -1, facadeI);
                add(emprestimoPanel);
    }

}

class CEmprestimoPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CEmprestimoPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0 || getFieldText(1).length() == 0)
    {
	facadeI.informar("Favor fornecer CPF e ISBN!");
    } else {
	facadeI.efetuarEmprestimo(getFieldText(0), getFieldText(1));
	owner.dispose();
    }
  }
}

