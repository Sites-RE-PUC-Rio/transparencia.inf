/**
 * Classe que gerencia emprestimos e devolucoes.
 */
public class CServico
{
	private CFacadeBD facadeBD;
	private CFacadeInterface facadeI;

	/**
         * Inicializa as variaveis Facade.
         *
         * @param facBD Facade de banco de dados da aplicacao
         * @param facI Facade de interface da aplicacao
         */
  public CServico (CFacadeBD facBD, CFacadeInterface facI)
	{
    facadeBD = facBD;
    facadeI = facI;
	}

	/**
     * Efetua um emprestimo de exemplar a usuario comum.
     *
     * @param CPF CPF do usuario.
     * @param ISBN ISBN do livro que o usuario deseja pegar emprestado.
     */
    public void efetuarEmprestimo (String CPF, String ISBN)
	{
		CUsuarioComum usu = CUsuarioComum.obterUsuarioComum(CPF, facadeBD);
		if (usu == null)
		{
			facadeI.informar ("Identificacao de usuario invalida.");
			return;
		}

		CLivro livro = CLivro.obterLivro (ISBN, facadeBD);
		if (livro == null)
		{
			facadeI.informar ("Identificacao de livro invalida.");
			return;
		}

		CExemplar exemp = livro.obterExemplarDisponivel (facadeBD);
		if (exemp == null)
		{
			facadeI.informar ("Nao ha exemplares disponiveis para o livro solicitado.");
			return;
		}

		int n = usu.obterNumExemplaresEmprestados(facadeBD);
		if (n >= CUsuarioComum.maxExemplaresEmprestados)
		{
			facadeI.informar ("Usuario excedeu maximo de exemplares emprestados.");
			return;
		}

		exemp.marcarEmprestado (usu, facadeBD);
    facadeI.emitirComprovante(exemp);
		facadeI.informar ("Emprestimo realizado com sucesso.");
	}

	/**
     * Efetua uma devolucao de emprestimo. Se necessario, cobra multa do usuario
     * por atraso na devolucao.
     *
     * @param exempId Numero de registro do exemplar a ser devolvido.
     */
    public void efetuarDevolucao (int exempId)
	{
		CExemplar exemp = CExemplar.obterExemplar (exempId, facadeBD);
		if (exemp == null)
		{
			facadeI.informar ("Identificacao de exemplar invalida.");
			return;
		}

		if (exemp.ehDisponivel() == true)
		{
			facadeI.informar ("Exemplar nao se encontra emprestado.");
			return;
		}

		float multa = exemp.calcularMulta ();
		if (multa > 0.0)
		{
			if (facadeI.cobrarMulta(multa) == false)
			{
				facadeI.informar ("A multa deve ser paga para realizacao de devolucao. Devolucao cancelada.");
				return;
			}
		}

		exemp.marcarDevolvido (facadeBD);

		facadeI.emitirComprovante(exemp);
		facadeI.informar ("Devolucao realizada com sucesso.");
	}
}