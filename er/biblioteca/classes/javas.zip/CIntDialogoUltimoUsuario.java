import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de consulta de ultimo usuario.
 */
public class CIntDialogoUltimoUsuario extends Frame{
	CFacadeInterface facadeI;
    CUltimoUsuarioPanel panel;

    /**
     * Inicializa janela de consulta de ultimo usuario.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntDialogoUltimoUsuario ( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[1];
        s[0] = "Numero de Registro:";
        panel = new CUltimoUsuarioPanel (this, 1, s, -1, facadeI);
        add(panel);
    }

}

class CUltimoUsuarioPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CUltimoUsuarioPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0)
    {
    	facadeI.informar("Favor fornecer numero de registro !");
    } else {
        String numReg = getFieldText(0);
        Integer intNumReg;
        try {
            intNumReg = new Integer(numReg);
        } catch (NumberFormatException nfe) {
            facadeI.informar("Favor fornecer um numero.");
            return;
        }
	    facadeI.efetuarConsultaUltimoUsuario(intNumReg.intValue());
	    owner.dispose();
    }
  }
}

