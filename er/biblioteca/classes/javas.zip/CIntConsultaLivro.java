import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de resultado de consulta ao acervo.
 */
public class CIntConsultaLivro extends Frame
{
  CConsultaLivroPanel consultaPanel;

    /**
     * Inicializa janela resultado de de consulta ao acervo.
     *
     * @param numCampos Numero de campos da consulta.
     * @param numResultados Numero de resultados da consulta.
     * @param labels Nome dos campos da consulta.
     * @param consulta Valores dos campos do resultado da consulta.
     */
  public CIntConsultaLivro (int numCampos, int numResultados,
                            String[] labels, String [][] consulta)
  {
          consultaPanel = new CConsultaLivroPanel (this, numCampos, numResultados, labels, consulta);
          add(consultaPanel);
  }
}

class CConsultaLivroPanel extends QueryPanel
{
  CFacadeInterface facadeI;

  CConsultaLivroPanel(Frame panOwner, int numCampos, int numResult,
              String [] labels, String [][] consulta)
  {
    super(panOwner, numCampos, numResult, labels, consulta);
  }

  public void actionPerformed (ActionEvent e)
  {
	  owner.dispose();
  }
}
