/**
 * Classe que representa um usuario empregado.
 */
public class CUsuarioEmpregado
{
	private String CPF;
	private String nome;
	private String senha;

	/**
     * Inicializa um usuario empregado.
     *
     * @param str_nome Nome do usuario.
     * @param str_CPF CPF do usuario.
     * @param str_senha Senha do usuario.
     */
	public CUsuarioEmpregado (String str_nome, String str_CPF, String str_senha)
	{
		CPF = str_CPF;
		nome = str_nome;
		senha = str_senha;
	}

	/**
     * Busca no BD o usuario empregado com o CPF especificado.
     *
     * @param CPFUsuarioEmpregado CPF do usuario.
     * @param facadeBD Facade de BD da aplicacao.
     * @return Usuario empregado com o CPF especificado.
     */
	static public CUsuarioEmpregado obterUsuarioEmpregado(String CPFUsuarioEmpregado, CFacadeBD facadeBD)
	{
		return facadeBD.obterUsuarioEmpregado(CPFUsuarioEmpregado);
	}

	/**
     * Adiciona o usuario empregado no BD.
     *
     * @param facadeBD Facade de BD da aplicacao.
     */
	public void adicionar(CFacadeBD facadeBD)
	{
		facadeBD.salvarUsuarioEmpregado (this);
	}

	/**
     * Remove o usuario empregado do BD.
     *
     * @param facadeBD Facade de BD da aplicacao.
     */
	public void remover(CFacadeBD facadeBD)
	{
		facadeBD.removerUsuarioEmpregado (this);
	}

	/**
     * Obtem o CPF do usuario.
     *
     * @return CPF do usuario.
     */
	public String obterCPF()
	{
		return CPF;
	}

	/**
     * Obtem o nome do usuario.
     *
     * @return Nome do usuario.
     */
	public String obterNome()
	{
		return nome;
	}

	/**
     * Obtem a senha do usuario.
     *
     * @return Senha do usuario.
     */
	public String obterSenha()
	{
		return senha;
	}
}