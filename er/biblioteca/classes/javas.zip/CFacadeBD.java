import java.util.* ;
import JDataLite.sql.*;

/**
* Essa classe fay a comunicacao entra a aplicacao e as classes que utilizam o
* banco de dados. Ela tambem inicializa a conexao com o banco de dados.
*/
public class CFacadeBD
{
	private CExemplarBD     exemplarBD ;
	private CLivroBD	livroBD ;
	private CUsuarioBD	usuarioBD;
	private String		url ;
	private Connection	con;
	private	Statement	stmt;

	/**
         * Inicializa a conexao com o banco de dados e as instancias das classes
         * de manipulacao do BD.
         */
        CFacadeBD (String host)
	{
		String sServerIP = host;    //  For an applet gets the web server's address.
        String sDSN= "biblioteca";   // The name of the database DSN to connect to
        String sConnectStr = "jdbc:JDataConnect://"+sServerIP+"/"+sDSN; // The full connection string


                Driver drvManager = new Driver();
                //url = "jdbc:JDataConnect:biblioteca";

		try {
			con = drvManager.connect(sConnectStr, new Properties());
			stmt = con.createStatement();
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		exemplarBD	= new CExemplarBD(stmt);
		livroBD		= new CLivroBD(stmt);
		usuarioBD	= new CUsuarioBD(stmt);
	}

        /**
         * Obtem uma instancia da classe CLivro a partir de dados do BD. Retorna
         * null se o livro nao foi encontrado.
         *
         * @param ISBN ISBN do livro.
         * @return Livro com o ISBN especificado.
         */
	CLivro obterLivro (String ISBN)
	{
		CLivro retLivro = null ;
		try
		{
			ResultSet rs = livroBD.obterLivro(ISBN);
			if (rs.next())
			{
				retLivro = new 	CLivro ( rs.getString("ISBN"),
										 rs.getString("Titulo"),
										 rs.getString("Autor"),
										 rs.getString("Edicao"),
										 rs.getString("Editora"),
										 rs.getString("Area de Interesse")) ;
			}
			return retLivro;
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
         * Obtem uma instancia da classe CExemplar a partir de dados do BD. Retorna
         * null se o exemplar nao foi encontrado.
         *
         * @param Codigo Numero de registro do exemplar.
         * @return Exemplar com o numero de registro especificado.
         */
        CExemplar obterExemplar (int Codigo)
	{
		CExemplar retExemplar = null;
		try
		{
			ResultSet rs = exemplarBD.obterExemplar(Codigo);
			if (rs.next())
			{
				String usr = rs.getString("Usuario");
				CUsuarioComum Usr;
				java.sql.Date sqlDate = rs.getDate("Data");
				java.util.Date dt = new java.util.Date(sqlDate.getTime());
				if (usr.equals("0"))
				{
					Usr = null;
				} else {
					Usr = obterUsuarioComum(usr);
				}

				retExemplar = new CExemplar(Codigo,
											obterLivro(rs.getString(2)),
											Usr,
											dt,
											!rs.getBoolean(5));
			}
			return retExemplar ;
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
         * Obtem uma instancia da classe CUsuarioComum a partir de dados do BD.
         * Retorna null se o usuario nao foi encontrado.
         *
         * @param CPF CPF do usuario.
         * @return Usuario comum com CPF especificado.
         */
        public CUsuarioComum obterUsuarioComum(String CPF)
	{
		CUsuarioComum retUsuario = null;

		try
		{
			ResultSet rs = usuarioBD.obterUsuarioComum(CPF);

			if (rs.next())
			{
				retUsuario = new CUsuarioComum(	rs.getString("Nome"),
												rs.getString("CPF"),
												rs.getString("Senha"));
			}
			return retUsuario;
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
         * Obtem uma instancia da classe CUsuarioEmpregado a partir de dados do BD.
         * Retorna null se o usuario nao foi encontrado.
         *
         * @param CPF CPF do usuario.
         * @return Usuario empregado com CPF especificado.
         */
        public CUsuarioEmpregado obterUsuarioEmpregado(String CPF)
	{
		CUsuarioEmpregado retUsuario = null;

		try
		{
			ResultSet rs = usuarioBD.obterUsuarioEmpregado(CPF);

			if (rs.next())
			{
				retUsuario = new CUsuarioEmpregado(	rs.getString("Nome"),
													rs.getString("CPF"),
													rs.getString("Senha"));
			}
			return retUsuario;
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
         * Obter um exemplar disponivel de um determinado livro. Retorna null
         * se nao ha exemplar ou nao ha exemplar disponivel.
         *
         * @param ISBN ISBN do livro associado ao exemplar.
         * @return Primeiro exemplar disponivel encontrado associado ao livro
         * com o ISBN especificado.
         */
        public CExemplar obterExemplarDisponivel(CLivro livro)
	{

		try
		{
			ResultSet rs = exemplarBD.obterExemplarDisponivel(livro.obterISBN());
			if (rs.next())
			{
				return obterExemplar(rs.getInt("Codigo"));
			}
				return null ;
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

        /**
         * Obter o numero de exemplares de um determinado livro.
         *
         * @param livro Livro da biblioteca.
         * @return Numero de exemplares associados ao livro especificado na busca.
         */
	public int obterNumExemplares (CLivro livro)
	{
		return exemplarBD.obterNumeroExemplares(livro.obterISBN());
	}

        /**
         * Atualiza os dado do novo exemplar no BD.
         *
         * @param exemp Exemplar com os dados atualizados.
         */
   public void atualizarExemplar (CExemplar exemp) {
      java.util.Date dt = exemp.obterDataEmprestimo();
		  java.sql.Date sqlDate = new java.sql.Date(dt.getTime());
      String strDate = sqlDate.toString();

      exemplarBD.atualizarExemplar(exemp.obterNumRegistro(),
                                    exemp.obterUltimoUsuario().obterCPF(),
                                    strDate,
                                    !exemp.ehDisponivel());
   }
        /**
         * Salva os dado do novo exemplar no BD.
         *
         * @param exemp Exemplar com os dados atualizados.
         */
	 public int salvarExemplar (CExemplar exemp)
	{
		java.util.Date dt = exemp.obterDataEmprestimo();
		java.sql.Date sqlDate = new java.sql.Date(dt.getTime());
		String usr ;
                String strDate = sqlDate.toString();
		if (exemp.obterUltimoUsuario() == null)
		{
			usr = "0";
		} else {
			usr = (exemp.obterUltimoUsuario()).obterCPF();
		}
		return exemplarBD.incluirExemplar( (exemp.obterLivro()).obterISBN(),
									  usr,
									  strDate,
									 !exemp.ehDisponivel());
	}

        /**
         * Salva os dados do novo livro no BD.
         *
         * @param livro Livro com os dados atualizados.
         */
	public void salvarLivro (CLivro livro)
	{
		livroBD.incluirLivro(livro.obterISBN(),
							 livro.obterTitulo(),
							 livro.obterAutor(),
							 livro.obterEditora(),
							 livro.obterEdicao(),
					         livro.obterAreaInteresse());
	}

        /**
         * Salva os dados do novo usuario no BD.
         *
         * @param usu Usuario comum com os dados atualizados.
         */
	public void salvarUsuarioComum (CUsuarioComum usu)
	{
		usuarioBD.incluirUsuarioComum( usu.obterNome(),
									   usu.obterCPF(),
									   usu.obterSenha());
	}

         /**
         * Salva os dados do novo usuario no BD.
         *
         * @param usu Usuario empregado com os dados atualizados.
         */
	public void salvarUsuarioEmpregado (CUsuarioEmpregado usu)
	{
		usuarioBD.incluirUsuarioEmpregado(  usu.obterNome(),
											usu.obterCPF(),
											usu.obterSenha());
	}

	 /**
         * Remove o exemplar do BD.
         *
         * @param exemp Exemplar da biblioteca.
         */
        public void removerExemplar (CExemplar exemp)
	{
		exemplarBD.removerExemplar(exemp.obterNumRegistro());
	}


        /**
         * Remove o livro do BD.
         *
         * @param livro Livro da biblioteca.
         */
	public void removerLivro (CLivro livro)
	{
		livroBD.removerLivro(livro.obterISBN());
	}

        /**
         * Remove o usuario do BD.
         *
         * @param usu Usuario comum da biblioteca.
         */
	public void removerUsuarioComum (CUsuarioComum usu)
    {
		usuarioBD.removerUsuario(usu.obterCPF());
    }


        /**
         * Remove o usuario do BD.
         *
         * @param usu Usuario empregado da biblioteca.
         */
         void removerUsuarioEmpregado (CUsuarioEmpregado usu)
	{
		usuarioBD.removerUsuario(usu.obterCPF());
	}

	/**
         * Obtem o numero de exemplares entresdados a um usuario.
         *
         * @param usu Usuario comum da biblioteca.
         * @return Numero de exemplares emprestados ao usuario comum especificado.
         */
        int obterNumExemplaresEmprestados (CUsuarioComum usu)
	{
		return exemplarBD.obterNumExemplaresEmprestados(usu.obterCPF());
	}

	/**
         * Obtem os Livros que atemdem aos quesitos da procura.
         *
         * @param ISBN ISBN do livro
         * @param titulo Titulo do livro
         * @param autor Autor do livro
         * @param edicao Edicao do livro
         * @param editora Editora do livro
         * @param areaInteresse Area de interesse do livro
         * @return Resultado da consulta.
         */
        CConsultaLivro consultaLivro(String ISBN, String titulo,
                                String autor, String edicao,
                                String editora, String areaInteresse)
	{
		ResultSet rs = livroBD.consultarLivro(ISBN, titulo, autor, edicao, editora, areaInteresse);

		try
		{
			Vector livros = new Vector();
			while (rs.next())
			{
				livros.add(obterLivro(rs.getString("ISBN")));
			}
			return new CConsultaLivro(livros);
		}  catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

        /**
         * Obtem um vetor com os livros emprestados a um determinado usuario
         *
         * @param usu Usuario comum da biblioteca.
         * @return Resultado da consulta.
         */
	public CConsultaLivrosEmprestados consultaLivrosEmprestado(CUsuarioComum usu)
	{
		ResultSet rs = exemplarBD.consultaLivrosEmprestado(usu.obterCPF());

		try
		{
			Vector exemplares = new Vector();
			while (rs.next())
			{
				exemplares.add(obterExemplar(rs.getInt(1)));
			}
			return new CConsultaLivrosEmprestados(exemplares);
		}  catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}
}