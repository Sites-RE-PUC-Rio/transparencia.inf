import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de menu de usuario empregado.
 */
public class CIntMenuUsuarioEmpregado extends Frame {
	CFacadeInterface	facadeI;
        CMenuUsuarioEmpregadoPanel  menuPanel ;

    /**
     * Inicializa janela de menu de usuario empregado.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntMenuUsuarioEmpregado ( CFacadeInterface p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[14];
                s[0] = "Adicionar Usuario Comum";
                s[1] = "Remover Usuario Comum";
                s[2] = "Adicionar Usuario Empregado";
                s[3] = "Remover Usuario Empregado";
                s[4] = "Adicionar Livro";
                s[5] = "Remover Livro";
                s[6] = "Adicionar Exemplar";
                s[7] = "Remover Exemplar";
                s[8] = "Efetuar Emprestimo";
                s[9] = "Efetuar Devolucao";
                s[10] = "Consultar Livros Emprestados";
                s[11] = "Consultar Acervo";
                s[12] = "Consultar Ultimo Usuario";
                s[13] = "Logout";
                String c[] = new String[14];
                c[0] = "AUC";
                c[1] = "RUC";
                c[2] = "AUE";
                c[3] = "RUE";
                c[4] = "AL";
                c[5] = "RL";
                c[6] = "AE";
                c[7] = "RE";
                c[8] = "EE";
                c[9] = "ED";
                c[10] = "CLE";
                c[11] = "CA";
                c[12] = "CUU";
                c[13] = "Logout";
                menuPanel = new CMenuUsuarioEmpregadoPanel (this, 14, s, c, facadeI);
                add(menuPanel);
    }

}

class CMenuUsuarioEmpregadoPanel extends MenuPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CMenuUsuarioEmpregadoPanel(Frame panOwner, int numPanNames,
              String [] panNames, String [] command, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, command);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    String label = e.getActionCommand();
    if (label.equals("AUC")) {
		CIntAdicionarUsuarioComum adicUsuComum = new CIntAdicionarUsuarioComum(facadeI);
		adicUsuComum.setSize(300, 300);
		adicUsuComum.setVisible(true);
    } else if (label.equals("RUC")) {
		CIntRemoverUsuarioComum remUsuComum = new CIntRemoverUsuarioComum(facadeI);
		remUsuComum.setSize(300, 300);
		remUsuComum.setVisible(true);
    } else if (label.equals("AUE")) {
		CIntAdicionarUsuarioEmpregado adicUsuEmpregado = new CIntAdicionarUsuarioEmpregado(facadeI);
		adicUsuEmpregado.setSize(300, 300);
		adicUsuEmpregado.setVisible(true);
    } else if (label.equals("RUE")) {
		CIntRemoverUsuarioEmpregado remUsuEmpregado = new CIntRemoverUsuarioEmpregado(facadeI);
		remUsuEmpregado.setSize(300, 300);
		remUsuEmpregado.setVisible(true);
    } else if (label.equals("AL")) {
		CIntAdicionarLivro adicLivro = new CIntAdicionarLivro(facadeI);
		adicLivro.setSize(500, 300);
		adicLivro.setVisible(true);
    } else if (label.equals("RL")) {
		CIntRemoverLivro remLivro = new CIntRemoverLivro(facadeI);
		remLivro.setSize(300, 300);
		remLivro.setVisible(true);
    }  else if (label.equals("AE")) {
		CIntAdicionarExemplar adicExemplar = new CIntAdicionarExemplar(facadeI);
		adicExemplar.setSize(300, 300);
		adicExemplar.setVisible(true);
    } else if (label.equals("RE")) {
    CIntRemoverExemplar remExemplar = new CIntRemoverExemplar(facadeI);
		remExemplar.setSize(300, 300);
		remExemplar.setVisible(true);
    } else if (label.equals("EE")) {
		CIntEmprestimo emprest = new CIntEmprestimo(facadeI);
		emprest.setSize(300, 300);
		emprest.setVisible(true);
    } else if (label.equals("ED")) {
    CIntDevolucao devol = new CIntDevolucao(facadeI);
		devol.setSize(300, 300);
		devol.setVisible(true);
    } else if (label.equals("CLE")) {
      CIntDialogoConsultaLivrosEmprestaros dlg = new CIntDialogoConsultaLivrosEmprestaros(facadeI);
      dlg.setSize(300 ,300);
      dlg.setVisible(true);
    } else if (label.equals("CA")) {
      CIntDialogoConsultaLivros dlgConsultaLivros = new CIntDialogoConsultaLivros(facadeI);
      dlgConsultaLivros.setSize(400,400);
      dlgConsultaLivros.setVisible(true);
    } else if (label.equals("CUU")) {
      CIntDialogoUltimoUsuario dlgConsulta = new CIntDialogoUltimoUsuario(facadeI);
      dlgConsulta.setSize(300,300);
      dlgConsulta.setVisible(true);
    } else {
      owner.dispose();
      facadeI.efetuarLogout();
    }
  }
}
