/**
* Essa classe faz a comunicacao entre a aplicacao e as classes de interface.
*/
public class CFacadeInterface
{
  CConsulta consulta ;
  CServico servico;
  CControleAcervo cAcervo;
  CControleUsuarios cUsuario;
  CLogin login ;

  /**
   * Inicializa a classe de Facade da interface.
   *
   * @param p_consulta Classe controladora de consultas.
   * @param p_consulta Classe controladora de servicos.
   * @param p_consulta Classe controladora de acervo.
   * @param p_consulta Classe controladora de usuarios.
   * @param p_consulta Classe controladora de login.
   */
  public void init (CConsulta p_consulta, CServico p_servico,
					CControleAcervo p_cAcervo, CControleUsuarios p_cUsuario,
					CLogin p_login) {
	consulta = p_consulta;
	servico = p_servico;
	cAcervo = p_cAcervo;
	cUsuario = p_cUsuario;
	login = p_login;
  }


  /**
   * Exibe uma janela de informacao.
   *
   * @param msg Mensagem a ser exibida.
   */
  public void informar (String msg)
  {
	  CIntInforma informa = new CIntInforma();
	  informa.setMessage(msg);
          informa.setSize(400,200);
          informa.setVisible(true);
  }

  /**
   * Cobra uma multa do usuario
   *
   * @param multa Valor da multa.
   */
 public boolean cobrarMulta (float multa)
  {
    String valor = Float.toString(multa);

    informar("Por favor, cobrar multa de R$ "+valor+".");

    return true;
  }

  /**
   * Emite comprovante de devolucao de exemplar.
   *
   * @param exemp Exemplar a ser devolvido.
   */
  public void emitirComprovante (CExemplar exemp)
  {
    CLivro livro = exemp.obterLivro();
    String s[][] = new String[1][7];
    String f[] = new String[7];

    f[0] = "Numero de Registro";
    f[1] = "ISBN";
    f[2] = "Titulo";
    f[3] = "Autor";
    f[4] = "Edicao";
    f[5] = "Editora";
    f[6] = "Area de Interesse";

    s[0][0] = Integer.toString(exemp.obterNumRegistro());
    s[0][1] = livro.obterISBN();
    s[0][2] = livro.obterTitulo();
    s[0][3] = livro.obterAutor();
    s[0][4] = livro.obterEdicao();
    s[0][5] = livro.obterEditora();
    s[0][6] = livro.obterAreaInteresse();

    CIntConsultaLivro consultaLivro = new CIntConsultaLivro(7, 1, f, s);
    consultaLivro.setSize(300,300);
    consultaLivro.setVisible(true);
  }

  /**
   * Emite cartao de exemplar.
   *
   * @param exemp Exemplar da biblioteca.
   */
  public void emitirCartaoExemplar (CExemplar exemp)
  {
    CLivro livro = exemp.obterLivro();
    String s[][] = new String[1][7];
    String f[] = new String[7];

    f[0] = "Numero de Registro";
    f[1] = "ISBN";
    f[2] = "Titulo";
    f[3] = "Autor";
    f[4] = "Edicao";
    f[5] = "Editora";
    f[6] = "Area de Interesse";

    s[0][0] = Integer.toString(exemp.obterNumRegistro());
    s[0][1] = livro.obterISBN();
    s[0][2] = livro.obterTitulo();
    s[0][3] = livro.obterAutor();
    s[0][4] = livro.obterEdicao();
    s[0][5] = livro.obterEditora();
    s[0][6] = livro.obterAreaInteresse();

    CIntConsultaLivro consultaLivro = new CIntConsultaLivro(7, 1, f, s);
    consultaLivro.setSize(300,300);
    consultaLivro.setVisible(true);
  }

  /**
   * Exibe resultado de uma consulta ao acervo.
   *
   * @param consulta Resultado de uma consulta ao acervo.
   */
  public void mostrarConsultaLivro (CConsultaLivro consulta)
  {
    int n = consulta.obterQtdeLivros();
    CLivro livro;
    String s[][] = new String[n][6];
    String f[] = new String[6];

    f[0] = "ISBN";
    f[0] = "ISBN";
    f[1] = "Titulo";
    f[2] = "Autor";
    f[3] = "Edicao";
    f[4] = "Editora";
    f[5] = "Area de Interesse";

    for (int i = 0; i < n; i++)
    {
      livro = consulta.obterLivro(i);
      s[i][0] = livro.obterISBN();
      s[i][1] = livro.obterTitulo();
      s[i][2] = livro.obterAutor();
      s[i][3] = livro.obterEdicao();
      s[i][4] = livro.obterEditora();
      s[i][5] = livro.obterAreaInteresse();
    }

    CIntConsultaLivro consultaLivro = new CIntConsultaLivro(6, n, f, s);
    consultaLivro.setSize(300,300);
    consultaLivro.setVisible(true);

  }

  /**
   * Exibe resultado de uma consulta de livros emprestados a um usuario.
   *
   * @param consulta Resultado de uma consulta de livros emprestados a um usuario.
   */
  public void mostrarConsultaLivrosEmprestados (CConsultaLivrosEmprestados consulta)
  {
    int n = consulta.obterQtdeLivros();
    CLivro livro;
    CExemplar exemp;
    String s[][] = new String[n][8];
    String f[] = new String[8];

    f[0] = "Numero de Registro";
    f[1] = "Data Emprestimo";
    f[2] = "ISBN";
    f[3] = "Titulo";
    f[4] = "Autor";
    f[5] = "Edicao";
    f[6] = "Editora";
    f[7] = "Area de Interesse";

    for (int i = 0; i < n; i++)
    {
      exemp = consulta.obterExemplar(i);
      livro = exemp.obterLivro();
      s[i][0] = Integer.toString(exemp.obterNumRegistro());
      s[i][1] = exemp.obterDataEmprestimo().toString();
      s[i][2] = livro.obterISBN();
      s[i][3] = livro.obterTitulo();
      s[i][4] = livro.obterAutor();
      s[i][5] = livro.obterEdicao();
      s[i][6] = livro.obterEditora();
      s[i][7] = livro.obterAreaInteresse();
    }

       CIntConsultaLivro consultaLivro = new CIntConsultaLivro(8, n, f, s);
    consultaLivro.setSize(300,300);
    consultaLivro.setVisible(true);
  }

  /**
   * Exibe resultado de uma consulta de ultimo usuario a pegar um exemplar emprestado.
   *
   * @param exemp Exemplar da biblioteca.
   */
  public void mostrarConsultaUltimoUsuario (CExemplar exemp)
  {
    CUsuarioComum usu = exemp.obterUltimoUsuario ();
    if (usu == null)
    {
      informar ("Exemplar nunca foi emprestado.");
      return;
    }
    String msg = new String("Ultimo usuario a pegar exemplar ");
    msg = msg.concat (String.valueOf(exemp.obterNumRegistro()));
    msg = msg.concat (" : ");
    msg = msg.concat (usu.obterNome());
    msg = msg.concat (", CPF ");
    msg = msg.concat (usu.obterCPF());
    informar (msg);
  }

  /**
   * Exibe menu de usuario comum.
   */
  public void mostrarMenuUsuarioComum ()
  {
    CIntMenuUsuarioComum menuUsuarioComum = new CIntMenuUsuarioComum(this);
    menuUsuarioComum.setSize(400,200);
    menuUsuarioComum.setVisible(true);
  }

  /**
   * Exibe menu de usuario empregado.
   */
  public void mostrarMenuUsuarioEmpregado ()
  {
      CIntMenuUsuarioEmpregado menuUsuarioEmpregado = new CIntMenuUsuarioEmpregado(this);
    menuUsuarioEmpregado.setSize(400,600);
    menuUsuarioEmpregado.setVisible(true);
  }

  /**
   * Exibe dialogo de login.
   */
  public void solicitarLogin ()
  {
	  CIntLogin iLogin = new CIntLogin(this);
          iLogin.setSize(400,200);
          iLogin.setVisible(true);
  }

  /**
   * Evento que ocorre ao usuario efetuar o login.
   *
   * @param CPF CPF do usuario.
   * @param senha Senha do usuario.
   */
  public void efetuarLogin(String CPF, String senha) {
	  login.efetuarLogin(CPF, senha);
  }

  /**
   * Evento que ocorre ao usuario efetuar consulta ao acervo.
   *
   * @param ISBN ISBN do livro
   * @param titulo Titulo do livro
   * @param autor Autor do livro
   * @param edicao Edicao do livro
   * @param editora Editora do livro
   * @param areaInteresse Area de interesse do livro
   */
  public void efetuarConsultaLivros (String ISBN,
                              String titulo,
                              String autor,
                              String edicao,
                              String editora,
                              String areaInteresse)
  {
    consulta.consultarLivro (ISBN,
				titulo,
				autor,
				edicao,
				editora,
				areaInteresse);
  }

  /**
   * Evento que ocorre ao usuario comum efetuar consulta a livros emprestados.
   */
  public void efetuarConsultaLivrosEmprestados ()
  {
    consulta.consultarLivrosEmprestados((login.obterUsuarioComum()).obterCPF());
  }

  /**
   * Evento que ocorre ao usuario empregado efetuar consulta a livros emprestados.
   *
   * @param CPF CPF do usuario.
   */
  public void efetuarConsultaLivrosEmprestados (String CPF)
  {
    consulta.consultarLivrosEmprestados(CPF);
  }

  /**
   * Evento que ocorre ao usuario efetuar consulta ultimo usuario a pegar
   * determinado exemplar emprestado.
   */
  public void efetuarConsultaUltimoUsuario (int numReg)
  {
    consulta.consultarUltimoUsuario(numReg);
  }

  /**
   * Evento que ocorre ao usuario efetuar emprestimo.
   *
   * @param CPF CPF do usuario que quer pegar um exemplar emprestado.
   * @param ISBN ISBN do livro que o usuario quer pegar emprestado.
   */
  public void efetuarEmprestimo (String CPF, String ISBN)
  {
    servico.efetuarEmprestimo(CPF, ISBN);
  }

  /**
   * Evento que ocorre ao usuario efetuar devolucao.
   *
   * @param numReg Numero de registro do exemplar a ser devolvido.
   */
  public void efetuarDevolucao (int numReg)
  {
    servico.efetuarDevolucao(numReg);
  }

  /**
   * Evento que ocorre ao usuario efetuar adicao de usuario comum.
   *
   * @param nome Nome do usuario.
   * @param CPF CPF do usuario.
   * @param senha Senha do usuario.
   */
  public void efetuarAdicaoUsuarioComum (String nome, String CPF, String senha)
  {
	  cUsuario.adicionarUsuarioComum( nome,  CPF,  senha);
  }

  /**
   * Evento que ocorre ao usuario efetuar adicao de usuario empregado.
   *
   * @param nome Nome do usuario.
   * @param CPF CPF do usuario.
   * @param senha Senha do usuario.
   */
  public void efetuarAdicaoUsuarioEmpregado (String nome, String CPF, String senha)
  {
    cUsuario.adicionarUsuarioEmpregado( nome,  CPF,  senha);
  }

  /**
   * Evento que ocorre ao usuario efetuar remocao de usuario comum.
   *
   * @param CPF CPF do usuario.
   */
  public void efetuarRemocaoUsuarioComum (String CPF)
  {
    cUsuario.removerUsuarioComum(CPF);
  }

  /**
   * Evento que ocorre ao usuario efetuar remocao de usuario empregado.
   *
   * @param CPF CPF do usuario.
   */
  public void efetuarRemocaoUsuarioEmpregado (String CPF)
  {
    cUsuario.removerUsuarioEmpregado(CPF);
  }

  /**
   * Evento que ocorre ao usuario efetuar adicao de livro.
   *
   * @param ISBN ISBN do livro
   * @param titulo Titulo do livro
   * @param autor Autor do livro
   * @param edicao Edicao do livro
   * @param editora Editora do livro
   * @param areaInteresse Area de interesse do livro
   */
  public void efetuarAdicaoLivro (String ISBN,
                              String titulo,
                              String autor,
                              String edicao,
                              String editora,
                              String areaInteresse)
  {
    cAcervo.adicionarLivro(ISBN,
                              titulo,
                              autor,
                              edicao,
                              editora,
                              areaInteresse);
  }

  /**
   * Evento que ocorre ao usuario efetuar adicao de exemplar.
   *
   * @param ISBN ISBN do livro associado ao exemplar.
   */
  public void efetuarAdicaoExemplar (String ISBN)
  {
    cAcervo.adicionarExemplar(ISBN);
  }

  /**
   * Evento que ocorre ao usuario efetuar remocao de livro.
   *
   * @param ISBN ISBN do livro.
   */
  public void efetuarRemocaoLivro (String ISBN)
  {
    cAcervo.removerLivro(ISBN);
  }

  /**
   * Evento que ocorre ao usuario efetuar remocao de exemplar.
   *
   * @param numReg Numero de registro do exemplar.
   */
  public void efetuarRemocaoExemplar(int numReg)
  {
    cAcervo.removerExemplar(numReg);
  }

  /**
   * Evento que ocorre ao usuario efetuar logout.
   */
  public void efetuarLogout ()
  {
    login.efetuarLogout();
  }

}