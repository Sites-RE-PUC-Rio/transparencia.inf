import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de adicao de usuario empregado.
 */
public class CIntAdicionarUsuarioEmpregado extends Frame{
	CFacadeInterface	facadeI;
        CAdicionarUsuarioEmpregadoPanel             adicionarUsuarioEmpregadoPanel ;

    /**
     * Inicializa janela de adicao de usuario empregado.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntAdicionarUsuarioEmpregado( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[3];
                s[0] = "Nome:";
                s[1] = "CPF:";
                s[2] = "Senha:";
                adicionarUsuarioEmpregadoPanel = new CAdicionarUsuarioEmpregadoPanel (this, 3, s, -1, facadeI);
                adicionarUsuarioEmpregadoPanel.setPasswordField (2);
                add(adicionarUsuarioEmpregadoPanel);
    }

}

class CAdicionarUsuarioEmpregadoPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CAdicionarUsuarioEmpregadoPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0 || getFieldText(1).length() == 0 || getFieldText(2).length() == 0)
    {
	facadeI.informar("Favor fornecer dados!");
    } else {
	facadeI.efetuarAdicaoUsuarioEmpregado(getFieldText(0), getFieldText(1), getFieldText(2));
	owner.dispose();
    }
  }
}

