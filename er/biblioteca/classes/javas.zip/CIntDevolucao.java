
import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de devolucao.
 */
public class CIntDevolucao extends Frame{
	CFacadeInterface	facadeI;
        CDevolucaoPanel             devolucaoPanel ;

    /**
     * Inicializa janela de devolucao.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntDevolucao( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[1];
                s[0] = "Numero de Registro:";
                devolucaoPanel = new CDevolucaoPanel (this, 1, s, -1, facadeI);
                add(devolucaoPanel);
    }

}

class CDevolucaoPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CDevolucaoPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0)
    {
	facadeI.informar("Favor fornecer dados!");
    } else {
	facadeI.efetuarDevolucao(Integer.parseInt(getFieldText(0)));
	owner.dispose();
    }
  }
}

