/**
 * Classe que define um livro da biblioteca.
 */
public class CLivro
{
	private String ISBN;
	private String titulo;
	private String autor;
	private String editora;
	private String areaInteresse;
	private String edicao;

	/**
     * Inicializa os atributos do livro.
     *
     * @param ISBN ISBN do livro
     * @param titulo Titulo do livro
     * @param autor Autor do livro
     * @param edicao Edicao do livro
     * @param editora Editora do livro
     * @param areaInteresse Area de interesse do livro
     */
    public CLivro (String str_ISBN,
			String str_titulo,
			String str_autor,
			String str_edicao,
			String str_editora,
			String str_areaInteresse)
	{
		ISBN          = str_ISBN;
		titulo        = str_titulo;
		autor         = str_autor;
		editora       = str_editora;
		areaInteresse = str_areaInteresse;
		edicao        = str_edicao;
	}

	/**
     * Obtem livro com ISBN especificado.
     *
     * @param ISBN ISBN do livro
     * @param facadeBD Facade de BD da aplicacao.
     * @return Livro com o ISBN especificado.
     */
	static public CLivro obterLivro (String ISBN, CFacadeBD facadeBD)
	{
		return facadeBD.obterLivro (ISBN);
	}

	/**
     * Obtem exemplar disponivel associado ao livro.
     *
     * @param facadeBD Facade de BD da aplicacao.
     * @return Exemplar disponivel associado ao livro.
     */
	public CExemplar obterExemplarDisponivel (CFacadeBD facadeBD)
	{
		return facadeBD.obterExemplarDisponivel (this);
	}

	/**
     * Adiciona um livro no BD.
     *
     * @param facadeBD Facade de BD da aplicacao.
     */
	public void adicionar (CFacadeBD facadeBD)
	{
		facadeBD.salvarLivro (this);
	}

	/**
     * Remove um livro no BD.
     *
     * @param facadeBD Facade de BD da aplicacao.
     */
	public void remover (CFacadeBD facadeBD)
	{
		facadeBD.removerLivro (this);
	}

	/**
     * Obtem numero de exemplares de um livro.
     *
     * @param facadeBD Facade de BD da aplicacao.
     * @return Numero de exemplares de um livro.
     */
	public int obterNumExemplares (CFacadeBD facadeBD)
	{
		return facadeBD.obterNumExemplares (this);
	}

	/**
     * Obtem ISBN de um livro.
     *
     * @return ISBN de um livro.
     */
	public String obterISBN()
	{
		return ISBN;
	}

	/**
     * Obtem titulo de um livro.
     *
     * @return Titulo de um livro.
     */
	public String obterTitulo()
	{
		return titulo;
	}

	/**
     * Obtem autor de um livro.
     *
     * @return Autor de um livro.
     */
	public String obterAutor()
	{
		return autor;
	}

	/**
     * Obtem edicao de um livro.
     *
     * @return Edicao de um livro.
     */
	public String obterEdicao()
	{
		return edicao;
	}

	/**
     * Obtem editora de um livro.
     *
     * @return Editora de um livro.
     */
	public String obterEditora()
	{
		return editora;
	}

	/**
     * Obtem area de interesse de um livro.
     *
     * @return Area de interesse de um livro.
     */
	public String obterAreaInteresse()
	{
		return areaInteresse;
	}
}