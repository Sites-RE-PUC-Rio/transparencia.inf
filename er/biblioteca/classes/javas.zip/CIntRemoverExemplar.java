import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de remocao de exemplar.
 */
public class CIntRemoverExemplar extends Frame{
	CFacadeInterface	facadeI;
        CRemoverExemplarPanel             removerExemplarPanel ;

    /**
     * Inicializa janela de remocao de exemplar.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntRemoverExemplar( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[1];
                s[0] = "Numero de Registro:";
                removerExemplarPanel = new CRemoverExemplarPanel (this, 1, s, -1, facadeI);
                add(removerExemplarPanel);
    }

}

class CRemoverExemplarPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CRemoverExemplarPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0)
    {
	facadeI.informar("Favor fornecer numero de registro !");
    } else {
      String numReg = getFieldText(0);
      Integer intNumReg;
      try {
        intNumReg = new Integer(numReg);
      } catch (NumberFormatException nfe) {
        facadeI.informar("Favor fornecer um numero.");
        return;
      }
	    facadeI.efetuarRemocaoExemplar(intNumReg.intValue());
	    owner.dispose();
    }
  }
}

