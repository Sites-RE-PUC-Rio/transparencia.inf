/**
 * Classe que gerencia de sessao de login.
 */
public class CLogin
{
    CFacadeInterface facadeI;
    CFacadeBD facadeBD;
    boolean   ehUsuarioComum;
    CUsuarioComum usuarioComum;
    CUsuarioEmpregado usuarioEmpregado;

	/**
     * Inicializa uma sessao de login
     *
     * @param p_facadeBD Facade de banco de dados da aplicacao
     * @param p_facadeI Facade de interface da aplicacao
     */
    public CLogin(CFacadeBD p_facadeBD, CFacadeInterface p_facadeI) {
		facadeI = p_facadeI;
		facadeBD = p_facadeBD;
	}

	/**
     * Chama a janela de login.
     */
    public void solicitarLogin ()
    {
        facadeI.solicitarLogin ();
    }

    /**
     * Obtem o usuario comum registrado para uma sessao de login.
     *
     * @return Usuario comum registrado para uma sessao de login.
     */
    public CUsuarioComum obterUsuarioComum() {
      return usuarioComum;
    }

    /**
     * Efetua o login. Confere se a senha do usuario esta' correta, inicializando
     * uma sessao de login.
     *
     * @param CPF CPF do usuario.
     * @param senha Senha do usuario.
     */
    public void efetuarLogin (String CPF, String senha)
    {
        usuarioComum = facadeBD.obterUsuarioComum (CPF);
        if (usuarioComum != null)
        {
            if (!usuarioComum.obterSenha().equals(senha))
            {
                facadeI.informar ("Senha invalida.");
                usuarioComum = null;
                solicitarLogin ();
                return;
            }
            ehUsuarioComum = true;
            facadeI.mostrarMenuUsuarioComum();
            return;
        }

        usuarioEmpregado = facadeBD.obterUsuarioEmpregado(CPF);
        if (usuarioEmpregado != null)
        {
            if (!usuarioEmpregado.obterSenha().equals(senha))
            {
                facadeI.informar ("Senha invalida!");
                usuarioEmpregado = null;
                solicitarLogin ();
                return;
            }
            ehUsuarioComum = false;
            facadeI.mostrarMenuUsuarioEmpregado();
            return;
        }

        facadeI.informar ("Usuario invalido.");
        solicitarLogin ();
    }

    /**
     * Encerra uma sessao de login.
     */
    public void efetuarLogout ()
    {
        usuarioComum = null;
        usuarioEmpregado = null;
        solicitarLogin ();
    }

    /**
     * Indica se usuario registrado em sessao eh comum ou empregado.
     *
     * @return Retorna <code>true</code> usuario registrado em sessao eh usuario
     * comum, e <code>false</code> caso seja usuario empregado.
     */
    public boolean ehUsuarioComum() {
      return ehUsuarioComum;
    }
}

