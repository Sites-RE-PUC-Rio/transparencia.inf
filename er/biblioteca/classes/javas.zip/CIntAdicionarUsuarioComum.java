import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de adicao de usuario comum.
 */
public class CIntAdicionarUsuarioComum extends Frame{
	CFacadeInterface	facadeI;
        CAdicionarUsuarioComumPanel             adicionarUsuarioComumPanel ;

    /**
     * Inicializa janela de adicao de usuario comum.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntAdicionarUsuarioComum( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[3];
                s[0] = "Nome:";
				s[1] = "CPF:";
                s[2] = "Senha:";
                adicionarUsuarioComumPanel = new CAdicionarUsuarioComumPanel (this, 3, s, -1, facadeI);
                adicionarUsuarioComumPanel.setPasswordField (2);
                add(adicionarUsuarioComumPanel);
    }

}

class CAdicionarUsuarioComumPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CAdicionarUsuarioComumPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0 || getFieldText(1).length() == 0 || getFieldText(2).length() == 0)
    {
	facadeI.informar("Favor fornecer dados!");
    } else {
	facadeI.efetuarAdicaoUsuarioComum(getFieldText(0), getFieldText(1), getFieldText(2));
	owner.dispose();
    }
  }
}

