import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de consulta de livros emprestados.
 */
public class CIntDialogoConsultaLivrosEmprestaros extends Frame{
	CFacadeInterface	facadeI;
        CDialogoConsultaLivrosEmprestarosPanel             dialogoConsultaLivrosEmprestarosPanel ;

    /**
     * Inicializa janela de consulta de livros emprestados.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntDialogoConsultaLivrosEmprestaros( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[1];
                s[0] = "CPF:";
                dialogoConsultaLivrosEmprestarosPanel = new CDialogoConsultaLivrosEmprestarosPanel (this, 1, s, -1, facadeI);
                add(dialogoConsultaLivrosEmprestarosPanel);
    }

}

class CDialogoConsultaLivrosEmprestarosPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CDialogoConsultaLivrosEmprestarosPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0)
    {
	facadeI.informar("Favor fornecer CPF !");
    } else {
	    facadeI.efetuarConsultaLivrosEmprestados(getFieldText(0));
	    owner.dispose();
    }
  }
}

