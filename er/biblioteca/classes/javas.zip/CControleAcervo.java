/**
 * Classe para controle do acervo da biblioteca.
 */
public class CControleAcervo
{
	private CFacadeBD facadeBD;
	private CFacadeInterface facadeI;

        /**
         * Inicializa as variaveis Facade.
         *
         * @param facBD Facade de banco de dados da aplicacao.
         * @param facI Facade de interface da aplicacao.
         */
  public CControleAcervo (CFacadeBD facBD, CFacadeInterface facI)
	{
    facadeBD = facBD;
    facadeI = facI;
	}

        /**
         * Adiciona um novo livro ao acervo. Deve receber todos os dados do
         * livro.
         *
         * @param ISBN ISBN do livro
         * @param titulo Titulo do livro
         * @param autor Autor do livro
         * @param edicao Edicao do livro
         * @param editora Editora do livro
         * @param areaInteresse Area de interesse do livro
         */
	public void adicionarLivro (String ISBN,
                              String titulo,
                              String autor,
                              String edicao,
                              String editora,
                              String areaInteresse)
	{
		CLivro livro = CLivro.obterLivro (ISBN, facadeBD);
		if (livro != null)
		{
			facadeI.informar ("Livro ja se encontra cadastrado.");
			return;
		}

		livro = new CLivro (ISBN, titulo, autor, edicao, editora, areaInteresse);
		livro.adicionar (facadeBD);
		facadeI.informar ("Livro adicionado com sucesso.");
	}

	/**
         * Remove um livro do acervo da biblioteca. O livro nao deve ter
         * exemplares associados a ele (estes devem ser removidos
         * antes do livro.
         *
         * @param ISBN ISBN do livro
         */
        public void removerLivro (String ISBN)
	{
		CLivro livro = CLivro.obterLivro (ISBN, facadeBD);
		if (livro == null)
		{
			facadeI.informar ("Livro nao se encontra cadastrado.");
			return;
		}

		if (livro.obterNumExemplares(facadeBD) > 0)
		{
			facadeI.informar ("Nao eh permitido remover livro com exemplares cadastrados.");
      return;
		}

		livro.remover (facadeBD);
		facadeI.informar ("Livro removido com sucesso.");
	}

	/**
         * Adiciona um exemplar a um livro. Gera automaticamente um id
         * para o exemplar.
         *
         * @param ISBN ISBN do livro
         */
        public void adicionarExemplar (String ISBN)
	{
		CLivro livro = CLivro.obterLivro (ISBN, facadeBD);
		if (livro == null)
		{
			facadeI.informar ("Livro nao se encontra cadastrado.");
      return;
		}

		CExemplar exemp = new CExemplar (livro);
		exemp.adicionar (facadeBD);
		facadeI.emitirCartaoExemplar (exemp);
		facadeI.informar ("Exemplar adicionado com sucesso.");
	}

	/**
         * Remove um exemplar.
         *
         * @param numRegistro Numero de registro do exemplar.
         */
        public void removerExemplar (int numRegistro)
	{
		CExemplar exemp = CExemplar.obterExemplar (numRegistro, facadeBD);
		if (exemp == null)
		{
			facadeI.informar ("Exemplar nao se encontra cadastrado.");
			return;
		}

		exemp.remover (facadeBD);
		facadeI.informar ("Exemplar removido com sucesso.");
	}
}