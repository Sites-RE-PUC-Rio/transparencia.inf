import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de informacoes.
 */
public class CIntInforma extends Frame  implements ActionListener {
	Panel msg		= new Panel(new FlowLayout());
	Panel buttons	= new Panel(new FlowLayout());
	Panel header	= new Panel(new FlowLayout());
	Button	b_ok	= new Button("OK");
	Label l_msg;



    /**
     * Inicializa janela de informacoes.
     */
	public CIntInforma( ) {
		setSize(200,200);
		setTitle("Mensagem!");
		setLayout(new GridLayout(3,1));
		header.add(new Label("Mensagem!!"));
		add(header);
		l_msg = new Label("");
		msg.add(l_msg);
		add(msg);
		b_ok.addActionListener(this);
		buttons.add(b_ok);
		add(buttons);
	}

    /**
     * Define mensagem da janela de informacoes.
     *
     * @param s_msg Messagem exibida na janela de informacoes.
     */
	public void setMessage(String s_msg) {
		l_msg.setText(s_msg);
	}

    /**
     * Evento que ocorre ao usuario apertar o botao de "Ok".
     *
     * @param ev Evento que ocorre na janela.
     */
	public void actionPerformed(ActionEvent ev) {
		dispose();
	}
};

