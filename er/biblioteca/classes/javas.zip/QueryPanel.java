import java.lang.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Classe geradora de janelas de consulta. Automatiza o processo de geracao de
 * janelas de consulta, com uma caixa de texto que eh preenchida
 * com os dados passados pelo construtor.
 */
public class QueryPanel extends Panel implements ActionListener
{
    // Parametros do construtor
    Frame owner;

    // Componentes fixos
    FlowLayout buttonFlowLayout = new FlowLayout();
    Panel buttonPannel = new Panel(buttonFlowLayout);
    Button okButton = new Button();
    TextArea textArea = new TextArea("", 0, 0, TextArea.SCROLLBARS_VERTICAL_ONLY);

    /**
    * Construtor da classe QueryPanel. Cria um Panel com uma caixa de texto,
    * preenchida com os campos e valores passados pelo construtor.
    *
    * @param panOwner Frame onde o Panel sera' inserido.
    * @param numFields Numero de campos do resultado da consulta.
    * @param numValues Numero de resultados da busca.
    * @param fields Vetor de String que contem os nomes do campos da consulta.
    * @param values Vetor de String que contem os valores a serem retornados na consulta.
    */
    public QueryPanel (Frame panOwner, int numFields, int numValues, String [] fields, String [][] values)
    {
        super (new BorderLayout());
        owner = panOwner;

        okButton.setLabel ("    OK    ");
        buttonPannel.add(okButton, null);
        okButton.addActionListener (this);

        String text = new String("Resultado da Pesquisa: \n");

        for (int i = 0; i < numValues; i++)
        {
            for (int j = 0; j < numFields; j++)
            {
                text = text.concat ("\n");
                text = text.concat (fields[j]);
                text = text.concat (": ");
                text = text.concat (values[i][j]);
            }
            text = text.concat ("\n");
        }
        textArea.setText(text);
        textArea.setEditable(false);

        add (buttonPannel, BorderLayout.SOUTH);
        add (textArea, BorderLayout.CENTER);
    }

    /**
    * Evento de mouse que ocorre ao pressionar o botao "Ok". Este evento deve ser
    * sobrecarregado nas classes derivadas de QueryPanel.
    *
    * @param e Objeto que encapsula o evento.
    */
    public void actionPerformed (ActionEvent e)
    {
    }
}
