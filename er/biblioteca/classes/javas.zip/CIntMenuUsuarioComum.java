import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de menu de usuario comum.
 */
public class CIntMenuUsuarioComum extends Frame {
	CFacadeInterface	facadeI;
        CMenuUsuarioComumPanel  menuPanel ;

    /**
     * Inicializa janela de menu de usuario comum.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntMenuUsuarioComum ( CFacadeInterface p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[3];
                s[0] = "Consultar Livros Emprestados";
                s[1] = "Consultar Acervo";
                s[2] = "Logout";
                String c[] = new String[3];
                c[0] = "CLE";
                c[1] = "CA";
                c[2] = "Logout";
                menuPanel = new CMenuUsuarioComumPanel (this, 3, s, c, facadeI);
                add(menuPanel);
    }

}

class CMenuUsuarioComumPanel extends MenuPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CMenuUsuarioComumPanel(Frame panOwner, int numPanNames,
              String [] panNames, String [] command, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, command);
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    String label = e.getActionCommand();
    if (label.equals("CLE")) {
      facadeI.efetuarConsultaLivrosEmprestados();
    } else if (label.equals("CA")) {
      CIntDialogoConsultaLivros dlgConsultaLivros = new CIntDialogoConsultaLivros(facadeI);
      dlgConsultaLivros.setSize(400,400);
      dlgConsultaLivros.setVisible(true);
    } else {
      owner.dispose();
      facadeI.efetuarLogout();
    }
  }
}

