/**
 * Classe geral da aplicacao. Inicializa as classes da aplicacao e as classes
 * Facade.
 */
class CAplicacao
{
	CFacadeBD facadeBD ;
        CFacadeInterface facadeI ;
        CConsulta consulta  ;
        CServico servico ;
        CControleAcervo cAcervo  ;
        CControleUsuarios cUsuario ;
        CLogin login  ;

        /**
         * Inicializa as classes da aplicacao, as classes Facade e chama o
         * dialogo de login.
         *
         * @param host Servidor da aplicacao.
         */
        public CAplicacao(String host)
	{
		CFacadeBD facadeBD        = new CFacadeBD(host);
		CFacadeInterface facadeI   = new CFacadeInterface();
        CConsulta consulta        = new CConsulta(facadeBD, facadeI);
        CServico servico          = new CServico(facadeBD, facadeI);
        CControleAcervo cAcervo   = new CControleAcervo(facadeBD, facadeI);
        CControleUsuarios cUsuario = new CControleUsuarios(facadeBD, facadeI);
        CLogin login              = new CLogin(facadeBD, facadeI);
        facadeI.init (consulta, servico, cAcervo, cUsuario, login);
        login.solicitarLogin ();
	}
}