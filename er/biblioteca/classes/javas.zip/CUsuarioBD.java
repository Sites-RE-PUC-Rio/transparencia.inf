import JDataLite.sql.* ;

/**
 * Classe que representa um usuario no BD.
 */
public class  CUsuarioBD
{
	private Statement stmt;

	/**
     * Inicializa um registro do usuario no BD.
     *
     * @param nstmt Tratador de banco de dados.
     */
	public CUsuarioBD(Statement nstmt)
	{
		stmt = nstmt;
	}

	/**
     * Obtem o usuario comum com o CPF especificado no BD.
     *
     * @param CPF CPF do usuario.
     * @return Consulta SQL com o usuario especificado.
     */
	public ResultSet obterUsuarioComum(String CPF)
	{
		String qry = "SELECT * FROM Usuario WHERE "+
						"Empregado = 0 AND CPF = '" +
						CPF + "'";
		try
		{
			return stmt.executeQuery(qry);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
     * Obtem o usuario empregado com o CPF especificado no BD.
     *
     * @param CPF CPF do usuario.
     * @return Consulta SQL com o usuario especificado.
     */
	public ResultSet obterUsuarioEmpregado(String CPF)
	{
		String qry = "SELECT * FROM Usuario WHERE "+
						"Empregado = 1 AND CPF = '" +
						CPF + "'";
		try
		{
			return stmt.executeQuery(qry);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
     * Inclui um usuario comum no BD.
     *
     * @param nome Nome do usuario.
     * @param CPF CPF do usuario.
     * @param senha Senha do usuario.
     */
	public void incluirUsuarioComum(String nome, String CPF, String senha)
	{
		String ins = "INSERT INTO Usuario VALUES(" +
					 "'" + nome + "'," +
					 "'" + CPF + "'," +
					 "0," +
					 "'" + senha + "')" ;
		try
		{
			stmt.executeUpdate(ins);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}

	/**
     * Inclui um usuario empregado no BD.
     *
     * @param nome Nome do usuario.
     * @param CPF CPF do usuario.
     * @param senha Senha do usuario.
     */
	public void incluirUsuarioEmpregado(String nome, String CPF, String senha)
	{
		String ins = "INSERT INTO Usuario VALUES(" +
					 "'" + nome + "'," +
					 "'" + CPF + "'," +
					 "1," +
					 "'" + senha  + "')" ;
		try
		{
			stmt.executeUpdate(ins);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}

	/**
     * Remove um usuario no BD.
     *
     * @param CPF CPF do usuario.
     */
	public void removerUsuario(String CPF)
	{
		String rem = "DELETE FROM Usuario WHERE CPF = '" + CPF + "'";
		try
		{
			stmt.executeUpdate(rem);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}
}