import java.util.* ;

/**
 * Classe para consultas a livros. Contem um vetor com a resposta da consulta
 * (em instancias da classe CLivro).
 */
public class CConsultaLivro
{
	Vector resultado;  // vetor de CLivro

	/**
         * Construtor para o resultado de uma pesquisa.
         *
         * @param livros Vetor de livros, obtidos como resultado de uma consulta.
         */
        CConsultaLivro (Vector livros)
	{
		resultado = livros;
	}

        /**
         * Obtem a quantidade de livros obtidos na consulta.
         *
         * @return Quantidade de livros obtida em uma consulta.
         */
	public int obterQtdeLivros ()
	{
		return resultado.size();
	}

	/**
         * Obtem o livro da resposta da consulta na posicao i do vetor de resultados.
         *
         * @param i Indice do livro
         * @return Livro que ocupa a posicao especificada pelo indice i.
         */
        public CLivro obterLivro (int i)
	{
		if (i > obterQtdeLivros ())
		{
			return null;
		}
		return (CLivro) resultado.elementAt(i);
	}

	/**
         * Realiza a pesquisa no banco de dado. Os parametros da consulta sao uma ou
         * mais caracteristicas do livro. Caracteristicas nulas ("") sao desprezadas.
         *
         * @param ISBN ISBN do livro
         * @param titulo Titulo do livro
         * @param autor Autor do livro
         * @param edicao Edicao do livro
         * @param editora Editora do livro
         * @param areaInteresse Area de interesse do livro
         * @param facadeBD Facade de banco de dados da aplicacao.
         * @return Retorna o resultado de uma consulta.
         */
        public static CConsultaLivro consultar (String ISBN,
                              String titulo,
                              String autor,
                              String edicao,
                              String editora,
                              String areaInteresse,
                              CFacadeBD facadeBD)
	{
		return facadeBD.consultaLivro (ISBN, titulo, autor, edicao, editora, areaInteresse);
	}
}
