import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de adicao de livro.
 */
public class CIntAdicionarLivro extends Frame{
	CFacadeInterface	facadeI;
        CAdicionarLivroPanel             adicionarLivroPanel ;
        int numAreas;
        String areasInteresse[];

    /**
     * Inicializa janela de adicao de livro.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntAdicionarLivro( CFacadeInterface	p_facadeI ) {
		int i;
                facadeI = p_facadeI;
                numAreas = 4;
                areasInteresse = new String[numAreas];
                areasInteresse[0] = "Dicionarios";
                areasInteresse[1] = "Engenharia de Software";
                areasInteresse[2] = "Matematica";
                areasInteresse[3] = "Fisica";
		String s[] = new String[6];
                s[0] = "ISBN:";
                s[1] = "Titulo:";
                s[2] = "Autor:";
                s[3] = "Edicao:";
                s[4] = "Editora:";
                s[5] = "Area de Interesse:";
                adicionarLivroPanel = new CAdicionarLivroPanel (this, 6, s, 5, facadeI, areasInteresse);
                for (i=0; i<numAreas; i++)
                  adicionarLivroPanel.addChoice(areasInteresse[i]);
                add(adicionarLivroPanel);
    }

}

class CAdicionarLivroPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;
  String[] areasInteresse;

  CAdicionarLivroPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI, String[] p_areasInteresse)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
    areasInteresse = p_areasInteresse;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0 || getFieldText(1).length() == 0 || getFieldText(2).length() == 0 ||
        getFieldText(3).length() == 0 || getFieldText(4).length() == 0)
    {
	facadeI.informar("Favor fornecer dados!");
    } else {
	facadeI.efetuarAdicaoLivro(getFieldText(0), getFieldText(1), getFieldText(2),
                                    getFieldText(3), getFieldText(4),
                                    getChoice());
	owner.dispose();
    }
  }
}

