import JDataLite.sql.* ;

/**
 * Classe que gerencia os exemplares guardados no banco de dados.
 */
public class  CExemplarBD
{
	private Statement stmt;

	/**
         * Construtor que recebe um Statement da conexao com o BD.
         *
         * @param nstmt Statement da conexao com o BD.
         */
        public CExemplarBD(Statement nstmt)
	{
		stmt = nstmt;
	}

	/**
         * Obtem um exemplar a partir de seu numero de Registro.
         *
         * @param Codigo Numero de registro do Exemplar
         * @return Exemplar com o numero de registro especificado.
         */
        public ResultSet obterExemplar(int Codigo)
	{
		String qry = "SELECT * FROM Exemplar WHERE Codigo = " + Codigo;
		try
		{
			return stmt.executeQuery(qry);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
         * Obter um exemplar disponivel para um determinado livro.
         *
         * @param ISBN ISBN do livro.
         * @return Exemplares disponiveis associados ao livro especificado por seu ISBN.
         */
        public ResultSet obterExemplarDisponivel(String ISBN)
	{
		String qry = "SELECT * FROM Exemplar WHERE " +
					 "Emprestado = 0 AND " +
					 "ISBN = '" + ISBN + "'";
		try
		{
			return stmt.executeQuery(qry);
		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

        /**
         * Obtem o numero de exemplares associados a um livro.
         *
         * @param ISBN ISBN do livro.
         * @return Numero de exemplares associados ao livro especificado por seu ISBN.
         */
	public int obterNumeroExemplares(String ISBN)
	{
		String qry = "SELECT COUNT(*) FROM Exemplar WHERE ISBN = '" +
						ISBN + "'";
		try
		{
			ResultSet rs = stmt.executeQuery(qry);
			int num = 0;
			if (rs.next())
			{
				num = rs.getInt(1);
			}
			return num;

		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return 0;
	}

	/**
         * Inclui um novo exemplar no banco de dados.
         *
         * @param ISBN ISBN do livro associado ao exemplar.
         * @param usuario Usuario que pegou o livro emprestado (<code>null</code> se nenhum).
         * @param data Data do ultimo emprestimo do exemplar.
         * @param emprestado Flag cujo valor eh <code>true</code> se o exemplar se encontra emprestado.
         * @return Numero de registro do exemplar.
         */
        public int incluirExemplar(String ISBN, String usuario, String data, boolean emprestado)
	{
		try
		{
			String qry = "SELECT MAX(Codigo) FROM Exemplar";
      ResultSet rs = stmt.executeQuery(qry);
      if (rs.next()) {
        int num = rs.getInt(1);
        num++;
        String ins = "INSERT INTO Exemplar VALUES("+
  							num  + ",  '" +
  							ISBN    + "', '" +
  							usuario + "', '" +
  							data  + "', " +
  							emprestado       + ")";
  			stmt.executeUpdate(ins);
        return num;
      } else {
        return 0;
      }
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
      return -1;
	}

	/**
         * Atualiza informacoes de emprestimo do exemplar.
         *
         * @param usuario Usuario que pegou o livro emprestado (<code>null</code> se nenhum).
         * @param data Data do ultimo emprestimo do exemplar.
         * @param emprestado Flag cujo valor eh <code>true</code> se o exemplar se encontra emprestado.
         */
  public void atualizarExemplar(int codigo,
                                String usuario,
                                String data,
                                boolean emprestado){

    try
		{
      String upd = "UPDATE Exemplar SET "+
                    "Usuario = '" + usuario +
                    "', Data = '" + data +
                    "', Emprestado = " + emprestado +

                    " WHERE Codigo = " + codigo;
  			stmt.executeUpdate(upd);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
  }
	/**
         * Remove um exemplar do BD.
         *
         * @param Codigo Numero de registro do Exemplar
         */
        public void removerExemplar(int Codigo)
	{
		try
		{
			String del = "DELETE FROM Exemplar WHERE Codigo = " + Codigo;
			stmt.executeUpdate(del);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}

	/**
         * Obtem o numero de exemplares emprestados a um usuario.
         *
         * @param CPF CPF do usuario.
         * @return Numero de exemplares emprestados a um usuario.
         */
        public int obterNumExemplaresEmprestados( String CPF)
	{
		String qry = "SELECT COUNT(*) FROM Exemplar WHERE Usuario = '" +
						CPF + "' AND EMPRESTADO = 1" ;
		try
		{
			ResultSet rs = stmt.executeQuery(qry);
			int num = 0;
			if (rs.next())
			{
				num = rs.getInt(1);
			}
			return num;

		} catch (SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return 0;
	}

	/**
         * Obtem os exemplares emprestados a um usuario.
         *
         * @param CPF CPF do usuario.
         * @return Exemplares emprestados a um usuario.
         */
  	public ResultSet consultaLivrosEmprestado(String CPF)
	{
		try
		{
			String qry = "SELECT * FROM Exemplar WHERE Usuario = '" +
						CPF + "' AND EMPRESTADO = 1" ;
			return stmt.executeQuery(qry);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}
}
