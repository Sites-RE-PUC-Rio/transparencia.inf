import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de login.
 */
public class CIntLogin extends Frame{
	CFacadeInterface	facadeI;
        CLoginPanel             loginPanel ;

    /**
     * Inicializa janela de login.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntLogin( CFacadeInterface	p_facadeI ) {
		facadeI = p_facadeI;
		String s[] = new String[2];
                s[0] = "CPF Usuario:";
                s[1] = "Senha:";
                loginPanel = new CLoginPanel (this, 2, s, -1, facadeI);
                loginPanel.setPasswordField (1);
                add(loginPanel);
    }

}

class CLoginPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;

  CLoginPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    Button fecharBt = new Button("Fechar");
    buttonPannel.add (fecharBt);
    fecharBt.addActionListener(new CloseListener(panOwner));
    facadeI = fI;
  }


  public void actionPerformed (ActionEvent e)
  {
    if (getFieldText(0).length() == 0 || getFieldText(1).length() == 0)
    {
	facadeI.informar("Favor fornecer CPF e Senha!");
    } else {
	facadeI.efetuarLogin(getFieldText(0), getFieldText(1));
	owner.dispose();
    }
  }
}

class CloseListener implements ActionListener
{
  Frame owner;
  public CloseListener (Frame panOwner)
  {
    owner = panOwner;
  }
  public void actionPerformed (ActionEvent e)
  {
    owner.dispose();
  }
}