import java.awt.*;
import java.awt.event.*;
import java.applet.*;

/**
 * Classe que gerencia o applet.
 */
public class CBiblioteca extends Applet{

    /**
     * Inicializa o applet do arquivo html.
     */
    public void init() {
        String sServerIP = getCodeBase().getHost();

		CAplicacao aplicacao = new CAplicacao(sServerIP);
	}

    /**
     * Destroi o applet do arquivo html.
     */
    public void destroy() {
    }

    /**
     * Executa o applet do arquivo html.
     */
    public void start() {
    }

    /**
     * Termina execucao do applet do arquivo html.
     */
    public void stop() {
    }

    /**
     * Processa eventos do applet.
     */
    public void processEvent(AWTEvent e) {
        if (e.getID() == Event.WINDOW_DESTROY) {
            System.exit(0);
        }
    }

    public static void main(String args[]) {
	//Frame f = new Frame("Biblioteca");
	CBiblioteca	bib = new CBiblioteca();

	bib.init();
	bib.start();

	//f.add("Center", bib);
	//f.setSize(300, 300);
	//f.show();
    }

    public String getAppletInfo() {
        return "An interactive test of the Graphics.drawArc and \nGraphics.fillArc routines. Can be run \neither as a standalone application by typing 'java ArcTest' \nor as an applet in the AppletViewer.";
    }

}

