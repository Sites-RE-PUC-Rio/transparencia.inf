import JDataLite.sql.* ;

/**
 * Classe que representa um livro no BD.
 */
public class CLivroBD
{
	private Statement stmt;

	/**
     * Inicializa um registro do livro no BD.
     *
     * @param nstmt Tratador de banco de dados.
     */
    public CLivroBD(Statement nstmt)
	{
		stmt = nstmt;
	}

	/**
     * Obtem o livro com o ISBN especificado no BD.
     *
     * @param ISBN ISBN do livro.
     * @return Consulta SQL com o livro especificado.
     */
    public ResultSet obterLivro(String ISBN)
	{
		try
		{
			String qry = "SELECT * FROM Livro WHERE ISBN = '"+ISBN+"'";
			return stmt.executeQuery(qry);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

	/**
     * Inclui um livro no BD.
     *
     * @param ISBN ISBN do livro.
     * @param titulo Titulo do livro.
     * @param autor Autor do livro.
     * @param edicao Edicao do livro.
     * @param editora Editora do livro.
     * @param areaInteresse Area de interesse do livro.
     */
	public void incluirLivro(String ISBN,
							 String titulo,
							 String autor,
							 String editora,
							 String edicao,
					         String areaInteresse)
	{
		String ins = "INSERT INTO Livro VALUEs(" +
					 "'" + ISBN + "'," +
					 "'" + titulo + "'," +
					 "'" + autor + "'," +
					 "'" + editora + "'," +
					 "'" + edicao + "'," +
					 "'" + areaInteresse + "')" ;
		try
		{
			stmt.executeUpdate(ins);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}

	/**
     * Remove o livro com o ISBN especificado no BD.
     *
     * @param ISBN ISBN do livro.
     */
	public void removerLivro(String ISBN)
	{
		String rem = "DELETE FROM Livro WHERE ISBN = '" + ISBN + "'";
		try
		{
			stmt.executeUpdate(rem);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
	}

	/**
     * Inclui um livro no BD.
     *
     * @param ISBN ISBN do livro
     * @param titulo Titulo do livro
     * @param autor Autor do livro
     * @param edicao Edicao do livro
     * @param editora Editora do livro
     * @param areaInteresse Area de interesse do livro
     * @return Consulta SQL com zero ou mais livros.
     */
	public ResultSet consultarLivro(String ISBN, String titulo,
                                String autor, String edicao,
                                String editora, String areaInteresse)
	{
		String qry = "SELECT ISBN FROM Livro ";
		boolean primeiro = true;

		if (ISBN.length() != 0)
		{
			qry = qry + "WHERE ISBN = '" + ISBN + "' ";
			primeiro = false;
		}
		if (titulo.length() != 0)
		{
			if (primeiro)
			{
				qry += "WHERE " ;
				primeiro = false;
			} else {
				qry += "AND " ;
			}
			qry = qry + "Titulo = '" + titulo + "' ";
		}
		if (autor.length() != 0)
		{
			if (primeiro)
			{
				qry += "WHERE " ;
				primeiro = false;
			} else {
				qry += "AND " ;
			}
			qry = qry + "Autor = '" + autor + "' ";
		}
		if (edicao.length() != 0)
		{
			if (primeiro)
			{
				qry += "WHERE " ;
				primeiro = false;
			} else {
				qry += "AND " ;
			}
			qry = qry + "Edicao = '" + edicao + "' ";
		}
		if (editora.length() != 0)
		{
			if (primeiro)
			{
				qry += "WHERE " ;
				primeiro = false;
			} else {
				qry += "AND " ;
			}
			qry = qry + "Editora = '" + editora + "' ";
		}
		if (areaInteresse.length() != 0)
		{
			if (primeiro)
			{
				qry += "WHERE " ;
				primeiro = false;
			} else {
				qry += "AND " ;
			}
			qry = qry + "[Area de Interesse] = '" + areaInteresse + "' ";
		}

		try
		{
			return stmt.executeQuery(qry);
		} catch(SQLException ex) {
			System.err.println("SQLException: " + ex.getMessage());
		}
		return null;
	}

}
