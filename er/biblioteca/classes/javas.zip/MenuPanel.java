import java.awt.*;
import java.awt.event.*;

/**
 * Classe geradora de janelas de menu. Automatiza o processo de geracao de
 * janelas de menu, gerando um botao para cada item de menu.
 */
public class MenuPanel extends Panel implements ActionListener
{
  // Parametros do construtor
  int numNames;
  String names[];
  Frame owner;

  GridLayout gridLayout = new GridLayout ();

  // Componentes variaveis
  BorderLayout buttonLayout[];
  Panel buttonPanel[];
  Button button[];
  String command[];


  /**
  * Construtor da classe MenuPanel. Cria um Panel com um ou mais itens de menu,
  * cada um com um botao correspondente.
  *
  * @param panOwner Frame onde o Panel sera' inserido.
  * @param numPanNames Numero de itens de menu.
  * @param panNames Vetor de String que contem os nomes dos itens de menu.
  * @param comm Vetor de String que contem os nomes dos comandos correspondentes a cada item de menu.
  */
  public MenuPanel(Frame panOwner, int numPanNames, String [] panNames, String [] comm)
  {
    super ();
    setLayout (gridLayout);
    numNames = numPanNames;
    names = panNames;
    command = comm;
    owner = panOwner;

    gridLayout.setColumns (1);
    gridLayout.setHgap(10);
    gridLayout.setVgap(10);

    gridLayout.setRows (numNames);
    buttonPanel  = new Panel[numNames];
    button       = new Button[numNames];
    buttonLayout = new BorderLayout[numNames];
    for (int i = 0; i < numNames; i++)
    {
      button[i] = new Button (names[i]);
      button[i].addActionListener(this);
      button[i].setActionCommand(command[i]);
      buttonLayout[i] = new BorderLayout ();
      buttonPanel[i] = new Panel (buttonLayout[i]);
      buttonPanel[i].add (button[i], BorderLayout.CENTER);
      add (buttonPanel[i]);
    }
  }

  /**
  * Evento de mouse que ocorre ao pressionar um botao. Este evento deve ser
  * sobrecarregado nas classes derivadas de QueryPanel, sendo que uma acao deve
  * ser tomada para cada comando.
  *
  * @param e Objeto que encapsula o evento.
  */
  public void actionPerformed (ActionEvent e)
  {
  }
}