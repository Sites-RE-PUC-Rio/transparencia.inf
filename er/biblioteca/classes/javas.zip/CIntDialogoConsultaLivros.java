import java.awt.*;
import java.awt.event.*;

/**
 * Classe da janela de consulta ao acervo.
 */
public class CIntDialogoConsultaLivros extends Frame{
	CFacadeInterface	facadeI;
        CDialogoConsultaLivrosPanel             dialogoConsultaLivrosPanel ;
        int numAreas;
        String areasInteresse[];

    /**
     * Inicializa janela de consulta ao acervo.
     *
     * @param p_facadeI Facade de interface da aplicacao.
     */
    public CIntDialogoConsultaLivros( CFacadeInterface	p_facadeI ) {
		int i;
                facadeI = p_facadeI;
                numAreas = 5;
                areasInteresse = new String[numAreas];
                areasInteresse[0] = "Nao escolhida";
                areasInteresse[1] = "Dicionarios";
                areasInteresse[2] = "Engenharia de Software";
                areasInteresse[3] = "Matematica";
                areasInteresse[4] = "Fisica";
		String s[] = new String[6];
                s[0] = "ISBN:";
                s[1] = "Titulo:";
                s[2] = "Autor:";
                s[3] = "Edicao:";
                s[4] = "Editora:";
                s[5] = "Area de Interesse:";
                dialogoConsultaLivrosPanel = new CDialogoConsultaLivrosPanel (this, 6, s, 5, facadeI, areasInteresse);
                for (i=0; i<numAreas; i++)
                  dialogoConsultaLivrosPanel.addChoice(areasInteresse[i]);
                add(dialogoConsultaLivrosPanel);
    }

}

class CDialogoConsultaLivrosPanel extends FieldPanel implements ActionListener
{
  CFacadeInterface facadeI;
  String[] areasInteresse;

  CDialogoConsultaLivrosPanel(Frame panOwner, int numPanNames,
              String [] panNames, int panComboId, CFacadeInterface fI, String[] p_areasInteresse)
  {
    super(panOwner, numPanNames, panNames, panComboId);
    facadeI = fI;
    areasInteresse = p_areasInteresse;
  }


  public void actionPerformed (ActionEvent e)
  {
    String area = getChoice();
    if (area.equals("Nao escolhida"))
      area = "";

    if (getFieldText(0).length() == 0 && getFieldText(1).length() == 0 && getFieldText(2).length() == 0 &&
        getFieldText(3).length() == 0 && getFieldText(4).length() == 0 && area.length() == 0)
    {
	facadeI.informar("Favor fornecer algum dado para pesquisa");
    } else {
	facadeI.efetuarConsultaLivros(getFieldText(0), getFieldText(1), getFieldText(2),
                                    getFieldText(3), getFieldText(4),
                                    area);
	owner.dispose();
    }
  }
}

