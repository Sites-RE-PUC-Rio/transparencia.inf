/**
 * Classe que controla os usuarios da biblioteca.
 */
public class CControleUsuarios
{
	private CFacadeBD facadeBD;
	private CFacadeInterface facadeI;

  /**
   * Inicializa as variaveis facade.
   *
   * @param facBD Facade de banco de dados da aplicacao.
   * @param facI Facade de interface da aplicacao.
   */
  public CControleUsuarios (CFacadeBD facBD, CFacadeInterface facI)
	{
    facadeBD = facBD;
    facadeI = facI;
	}

        /**
         * Adiciona um usuario comum a biblioteca.
         *
         * @param nome Nome do usuario.
         * @param CPF CPF do usuario.
         * @param senha Senha do usuario.
         */
	public void adicionarUsuarioComum (String nome, String CPF, String senha)
	{
		CUsuarioComum usu = CUsuarioComum.obterUsuarioComum (CPF, facadeBD);
		if (usu != null)
		{
			facadeI.informar ("Usuario ja se encontra cadastrado.");
			return;
		}

		usu = new CUsuarioComum (nome, CPF, senha);
		usu.adicionar (facadeBD);
		facadeI.informar ("Usuario comum adicionado com sucesso.");
	}

        /**
         * Remove um usuario comum da biblioteca.
         *
         * @param CPF CPF ome do usuario.
         */
	public void removerUsuarioComum (String CPF)
	{
		CUsuarioComum usu = CUsuarioComum.obterUsuarioComum (CPF, facadeBD);
		if (usu == null)
		{
			facadeI.informar ("Usuario nao se encontra cadastrado.");
			return;
		}

		usu.remover (facadeBD);
		facadeI.informar ("Usuario removido com sucesso.");
	}

        /**
         * Adiciona um usuario empregado a bilbioteca.
         *
         * @param nome Nome do usuario.
         * @param CPF CPF ome do usuario.
         * @param senha Senha do usuario.
         */
	public void adicionarUsuarioEmpregado (String nome, String CPF, String senha)
	{
		CUsuarioEmpregado usu = CUsuarioEmpregado.obterUsuarioEmpregado (CPF, facadeBD);
		if (usu != null)
		{
  		facadeI.informar ("Usuario ja se encontra cadastrado.");
	  	return;
		}

		usu = new CUsuarioEmpregado (nome, CPF, senha);
		usu.adicionar (facadeBD);
		facadeI.informar ("Usuario empregado adicionado com sucesso.");
	}

	/**
         * Remove um usuario empregado da bilbioteca.
         *
         * @param CPF CPF ome do usuario.
         */
        public void removerUsuarioEmpregado (String CPF)
	{
		CUsuarioEmpregado usu = CUsuarioEmpregado.obterUsuarioEmpregado (CPF, facadeBD);
		if (usu == null)
		{
			facadeI.informar ("Usuario nao se encontra cadastrado.");
			return;
		}

		usu.remover (facadeBD);
		facadeI.informar ("Usuario removido com sucesso.");
	}
}